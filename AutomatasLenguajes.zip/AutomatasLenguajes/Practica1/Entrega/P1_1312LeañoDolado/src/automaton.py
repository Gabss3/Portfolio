"""
    Equipo docente de Autómatas y Lenguajes Curso 2024-25
    Última modificación: 26 de septiembre de 2024

    Implementación de un autómata. Para ello, se van a definir las siguientes clases:
        - State: Clase que define un estado del autómata.
        - Transitions: Clase que define el conjunto de transiciones del autómata.
        - FiniteAutomaton: Clase que define el autómata finito.
        - REParser: Clase que parsea de expresión regular a autómata.
"""

from src.state import State
from src.transitions import Transitions
from src.utils import is_deterministic
from collections import deque


class FiniteAutomaton():
    """
        Define un autómata finito.
    """

    def __init__(self, initial_state: State, states: set, symbols: set, transitions: Transitions):

        if initial_state not in states:
            raise ValueError(
                f"Initial state {initial_state.name} "
                f"is not in the set of states",
            )

        self.initial_state = initial_state
        self.states = states
        self.symbols = symbols
        self.transitions = transitions
        

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return NotImplemented

        return (
            self.initial_state == other.initial_state
            and self.states == other.states
            and self.symbols == other.symbols
            and self.transitions == other.transitions
        )

    def __repr__(self):
        return (
            f"{type(self).__name__}("
            f"initial_state={self.initial_state!r}, "
            f"states={self.states!r}, "
            f"symbols={self.symbols!r}, "
            f"transitions={self.transitions!r})"
        )

    # BEGIN Funciones relacionadas con las transiciones

    def add_transition(self, start_state: State, symbol: str, end_state: State):
        self.transitions.add_transition(start_state, symbol, end_state)
        
    def add_transitions(self, transitions: list):
        self.transitions.add_transitions(transitions)

    def has_transition(self, state: State, symbol: str):
        return self.transitions.state_has_any_transition_with_symbol(state, symbol)
        
    def get_transition(self, state: State, symbol: str):
        return self.transitions.goes_to(state, symbol)
        
    def get_all_transitions(self):
        return self.transitions.get_all_transitions()

    # END Funciones relacionadas con las transiciones


    # BEGIN Funciones relacionadas con el procesamiento de una cadena

    def reset(self):
        """
            Esta función resetea el autómata, volviendo al estado inicial

            Args: No args

            Returns: No return
        """
        current_states = {self.initial_state}
        self.current_states = self._complete_lambdas(current_states)

    def process_symbol(self, symbol: str):
        """
            Esta función procesa un símbolo

            Args:
                symbol: símbolo a consumir

            Returns: No return
        """

        """Aquí lo que hay q hacer es actualizar el current_states. 
        Es como si estuviésemos en un conjunto de estados (q0, q1, q4..) 
        del grafo y tuviesemos que analizar los posibles estados siguientes 
        a partir de un símbolo. Esos estados siguientes son los q se 
        actualizan poniendolos como si fueran nuevos current_states"""
        
        estados_nuevos= set()
        estados_actuales=self.current_states

        for start_state in estados_actuales:
            end_states= self.get_transition(start_state, symbol)

            if end_states is not None:
                estados_nuevos.update(end_states)

        if estados_nuevos is not None:
            self.current_states= self._complete_lambdas(estados_nuevos)

        else:
            self.current_states= self._complete_lambdas(self.current_states)
                



    def accepts(self, string: str):
        """
            Esta función procesa una cadena y comprueba si debe ser aceptada
              o no.

            Args:
                string: cadena a procesar

            Returns:
                True si la cadena debe ser aceptada
                False otherwise
        """
        self.reset()
        for symbol in string:
            self.process_symbol(symbol)
        
        for state in self.current_states:
            if state.is_final:
                return True
                
        return False



    def _complete_lambdas(self, raw_current_states: set):
        """
            Esta función añade al conjunto de estados actuales todos aquellos
              estados que pueden ser alcanzados con el símbolo lambda.

            Args:
                raw_current_states: conjunto de estados actuales al que hay
                  que añadir todos aquellos estados a los que se puede transitar
                  con el símbolo lambda

            Return:
                Conjunto de estados actualizado

            Observación:
                - Recomendable utilizar el método get_lambda_transitions de Transitions
                
        """

        """Hay que devolver todos los posibles estados a los q se puede ir con lambda. 
        se crean dos listas la que se va a devolver y sobre la q se va a iterar. Se hace 
        un bucle vaciando la lista y se analiza estado por estado si son posibles estados 
        siguientes. si lo son, se agregan a la otra lista"""

        estados_posibles= set(raw_current_states)
        estados_no_agregados= []
        for estado in raw_current_states:
            estados_no_agregados.append(estado)

        while len(estados_no_agregados) != 0:
            estado_nuevo= estados_no_agregados.pop()

            #Devuelve en transiciones el conjunto de estados a los que puedes llegar mediante lambda desde estado_nuevo
            transiciones= self.transitions.get_lambda_transitions().get(estado_nuevo, set())

            for siguiente_estado in transiciones:
                if siguiente_estado not in estados_posibles:
                    
                    estados_posibles.add(siguiente_estado)
                    estados_no_agregados.append(siguiente_estado)
        
        return estados_posibles
        
    # END Funciones relacionadas con el procesamiento de una cadena


    # BEGIN Funciones relacionadas con generar el AFD

    def to_deterministic(self):
        """
            Esta función construye un Autómata Finito Determinista a partir del
              automata original.

            Args: No args

            Return:
                Un autómata finito determinista
        """
        #--------------------------------------------------
        self.reset()
        estados_visitados = []
        cola = deque()
        
        estado_join = State("+".join([s.name for s in self.current_states]), any(s.is_final for s in self.current_states))
        cola.append((self.current_states, estado_join))
        transitions = Transitions()
        simbols = self.symbols
        
        while len(cola) > 0:
            #donde_estoy es el set de estados , donde_estoy_join es el nuevo estado (union de los nombres de los estados de donde_estoy) del automata determinista.
            donde_estoy, donde_estoy_join  = cola.pop()      
            
            if donde_estoy_join not in estados_visitados:
                estados_visitados.append(donde_estoy_join) #añadimos el estado donde_estoy_join para no volverlo a analizar
                for s in simbols: 
                    self.current_states = donde_estoy #para que process simbols coja los estados que nos interesan, actualizamos manualmente current_states
                    self.process_symbol(s) #actualiza current_states con los estados a los que transitamos con el simbolo s
                    donde_voy=self.current_states #tenemos en current_states el nuevo set de estados que vamos a añadir en la cola
                    donde_voy_join = State("+".join([s.name for s in donde_voy]), any(s.is_final for s in donde_voy)) #creamos el nuevo estado con la union de los estados de donde_voy

                    transitions.add_transition(donde_estoy_join, s, donde_voy_join)
                        
                    cola.append((donde_voy, donde_voy_join))                    
        #--------------------------------------------------
        return FiniteAutomaton(self.initial_state, estados_visitados, simbols, transitions)

    # END Funciones relacionadas con generar el AFD

    # BEGIN Funciones relacionadas con minimizar el AFD

    def to_minimized(self):
        """
            Esta función minimiza un Autómata Finito Determinista"

            Args: No args

            Return:
                Un autómata finito determinista mínimo
        """
        if not is_deterministic(self):
            raise ValueError("The automaton must be deterministic")

        #-------------------------------------------------
        #Funcion para eliminar estados inaccesibles.
        def get_accesibles(self):
            pendientes = deque()
            pendientes.append(self.initial_state)
            
            visitados = []
            
            while pendientes:
                state = pendientes.pop()
                if state not in visitados:
                    visitados.append(state)

                    for s in self.symbols:
                        self.current_states = {state}
                        self.process_symbol(s)
                        pendientes.append(self.current_states.pop())
            
            return visitados
        
        states = get_accesibles(self)
        vector_old = []
        vector_new = []
        for state in states:    
            if state.is_final:
                vector_old.append(1)
            else:
                vector_old.append(0)
        
            vector_new.append(-1)
        
        salir = False
        contador = 0
        
        #Bucle para crear el vector que contiene los estados del nuevo automata.
        while not salir:
            for i in range(len(vector_old)):
                if vector_new[i] == -1:
                    vector_new[i] = contador
                    for j in range(i+1, len(vector_old)):
                       
                        if vector_old[i] == vector_old[j]:
                            coinciden = True
                            for s in self.symbols:
                                estado_i = self.get_transition(states[i], s)
                                estado_j = self.get_transition(states[j], s)
                                                              
                                for l in range(len(states)):
                                    if states[l] == next(iter(estado_i), None):
                                        valor_estado_i = vector_old[l]
                                    if states[l] == next(iter(estado_j), None):
                                        valor_estado_j = vector_old[l]

                                if valor_estado_i != valor_estado_j:
                                    coinciden = False
                                    break   
                            
                            if coinciden:
                                vector_new[j] = contador                       
                    contador+=1
                               

                                
            if vector_old == vector_new:
                salir = True    

            else:
                for m in range(len(states)):
                    vector_old[m] = vector_new[m]
                contador=0
               
                for m in range(len(states)):
                    vector_new[m] = -1
        
        #Creacion de los nuevos estados del automata a partir del vector obtenido en el bucle anterior.
        #Creación de tupla para facilitar la asignacion de transiciones.
        self.state_counter = contador
        aux = 0
        new_states=[]
        tupla_estados= {}
        for aux in range(contador+1):
            for l in range(len(states)):
                if vector_new[l] == aux:
                    new_states.append(State(str(aux)))
                    if aux not in tupla_estados:
                        tupla_estados[aux] = []
                    for r in range(len(states)):    
                        if vector_new[r] == aux:        
                            tupla_estados[aux].append(states[r])
                    break 
                
        for nombre_estado, estados in tupla_estados.items():
            for est in estados:
                if est.is_final == True:
                    for nuevos in new_states:
                        if str(nuevos.name) == str(nombre_estado):
                            for o in range(len(new_states)):
                                if new_states[o] == nuevos:
                                    new_states[o].is_final = True
        
        #Bucle para asignar las transiciones al nuevo automata    
        transitions = Transitions()
        for aux in range(contador+1):
            for l in range(len(states)):
                if vector_new[l] == aux:
                    estado = states[l]
                    for s in self.symbols:
                        estado_siguiente = self.get_transition(estado, s)
                        for i in range(len(states)):
                                for aux2, lista_estados2 in tupla_estados.items():
                                        for h in lista_estados2:
                                            if h == next(iter(estado_siguiente), None):
                                                if vector_new[i] == aux2 and not self.has_transition(new_states[aux], s):                                               
                                                    self.add_transition(new_states[aux], s, new_states[aux2])
                                                    transitions.add_transition(new_states[aux], s, new_states[aux2])
        #-------------------------------------------------
        return FiniteAutomaton(new_states[0], new_states, self.symbols, transitions)
    
    # END Funciones relacionadas con minimizar el AFD