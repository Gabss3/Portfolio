import re

"""
Esta es la expresion regular para el ejercicio 0, que se facilita
a modo de ejemplo:
"""
RE0 = "[ab]*a"

"""
Completa a continuacion las expresiones regulares para los
ejercicios 1-6:
"""
RE1 = "(a|b|c)*a(a|b|c)*b(a|b|c)*" + "|" + "((a|b|c)*b(a|b|c)*a(a|b|c)*)"
RE2 = "-?[.][0-9][0-9]*" + "|" + "-?[1-9][0-9]*[.]?[0-9]*" + "|" + "0[.][0-9]*"
RE3 = "(www.uam.es/" + "|" + "moodle.uam.es/)" + "([a-z][a-z]*/?)*" 
RE4 = "([1-9][1-9]*)" + "(\+" + "|" + "-" + "|" + "/" + "|" + "\*)" + "([1-9][1-9]*)"
RE5 = ""

"""
Recuerda que puedes usar el fichero test_p0.py para probar tus
expresiones regulares.
"""

