#!/usr/bin/env python

import re
import unittest

from regular_expressions import RE0, RE1, RE2, RE3, RE4, RE5


class TestP0(unittest.TestCase):
    """Tests of assignment 0."""

    def check_expression(self, expr: str, string: str, expected: bool) -> None:
        with self.subTest(string=string):
            match = re.fullmatch(expr, string)
            self.assertEqual(bool(match), expected)

    def test_exercise_0(self) -> None:
        self.check_expression(RE0, "a", True)
        self.check_expression(RE0, "bbbbaba", True)
        self.check_expression(RE0, "abbab", False)
        self.check_expression(RE0, "b", False)

    def test_exercise_1(self) -> None:
        self.check_expression(RE1, "acbbaccab", True)
        self.check_expression(RE1, "ab", True)
        self.check_expression(RE1, "aabc", True)

        self.check_expression(RE1, "bcc", False)
        self.check_expression(RE1, "cacaa", False)


    def test_exercise_2(self) -> None:
        self.check_expression(RE2, "-1", True)
        self.check_expression(RE2, "-.50", True)
        self.check_expression(RE2, "-2.5", True)

        self.check_expression(RE2, "2", True)
        self.check_expression(RE2, "2.", True)
        self.check_expression(RE2, "2.5", True)
        self.check_expression(RE2, "0.5", True)
        
        self.check_expression(RE2, "05", False)
        self.check_expression(RE2, "2.5.3", False)
        self.check_expression(RE2, "-", False)




    def test_exercise_3(self) -> None:
        self.check_expression(RE3, "www.uam.es/", True)
        self.check_expression(RE3, "moodle.uam.es/", True)
        self.check_expression(RE3, "moodle.uam.es/hola/quetal", True)
        self.check_expression(RE3, "www.uam.es/eps", True)
        self.check_expression(RE3, "moodle.uam.es/uam/", True)
        
        self.check_expression(RE3, "moodle.uam/", False)
        self.check_expression(RE3, "www.uam.es/hola//", False)
        self.check_expression(RE3, "www.uam.es//eps/", False)
        

    def test_exercise_4(self) -> None:
        self.check_expression(RE4, "33/2", True)
        self.check_expression(RE4, "23-28", True)
        self.check_expression(RE4, "25589*121", True)
        self.check_expression(RE4, "45+957", True)

        self.check_expression(RE4, "-1+3", False)
        self.check_expression(RE4, "3.33*55", False)
        self.check_expression(RE4, "20/6", False)
        self.check_expression(RE4, "9-", False)



    def test_exercise_5(self) -> None:
        self.check_expression(RE5, "a", True)
        self.check_expression(RE5, "aa", True)
        self.check_expression(RE5, "abaa", True)

        self.check_expression(RE5, "aabaaaa", False)
        self.check_expression(RE5, "bbaabaabaa", False)

if __name__ == '__main__':
    unittest.main()
