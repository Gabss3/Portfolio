import unittest
from roman_parser import *

class TestRomanGrammar(unittest.TestCase):
    def _check_analyze(self, input_string, int_value, valid):
        print(f"\nProbando: '{input_string}'")
        print(f"Se espera que el valor numérico sea {int_value} y que la validez sea {valid}")
        result = parser.parse(input_string)
        print("Resultado obtenido: ", result)
        
        if not result["valid"]:
            assert (not valid)
        else:
            assert (result["val"] == int_value)

    def test_cases_1(self):
        print("\nTest 1: Comprobando 'XX' que debería dar 20 (válido)")
        self._check_analyze("XX", 20, True)

    def test_cases_2(self):
        print("\nTest 2: Comprobando 'IX' que debería dar 9 (válido)")
        self._check_analyze("IX", 9, True)

    def test_cases_3(self):
        print("\nTest 3: Comprobando 'XII' que debería dar 12 (válido)")
        self._check_analyze("XII", 12, True)

    def test_cases_4(self):
        print("\nTest 4: Comprobando 'XIIII' que debería ser inválido (debería ser XIII)")
        self._check_analyze("XIIII", 13, False)

    def test_cases_5(self):
        print("\nTest 5: Comprobando 'V' que debería dar 5 (válido)")
        self._check_analyze("V", 5, True)

    def test_cases_6(self):
        print("\nTest 6: Comprobando 'IIII' que debería ser inválido (debería ser IV)")
        self._check_analyze("IIII", 4, False)

    def test_cases_7(self):
        print("\nTest 7: Comprobando 'XXI' que debería dar 21 (válido)")
        self._check_analyze("XXI", 21, True)

    def test_cases_8(self):
        print("\nTest 8: Comprobando 'XXX' que debería dar 30 (válido)")
        self._check_analyze("XXX", 30, True)

    def test_cases_9(self):
        print("\nTest 9: Comprobando 'XXXI' que debería ser inválido (más de 3 X)")
        self._check_analyze("XXXI", 31, False)

    def test_cases_10(self):
        print("\nTest 10: Comprobando 'IV' que debería dar 4 (válido)")
        self._check_analyze("IV", 4, True)

    def test_cases_11(self):
        print("\nTest 11: Comprobando 'XXVV' que debería ser inválido (secuencia incorrecta)")
        self._check_analyze("XXVV", 0, False)

    def test_cases_12(self):
        print("\nTest 12: Comprobando 'MMMM' que debería dar 4000 (válido)")
        self._check_analyze("MMMM", 4000, True)

    def test_cases_13(self):
        print("\nTest 13: Comprobando 'IIIIII' que debería ser inválido (demasiadas I)")
        self._check_analyze("IIIIII", 6, False)

    def test_cases_14(self):
        print("\nTest 14: Comprobando 'XC' que debería dar 90 (válido)")
        self._check_analyze("XC", 90, True)

    def test_cases_15(self):
        print("\nTest 15: Comprobando 'CD' que debería dar 400 (válido)")
        self._check_analyze("CD", 400, True)

    def test_cases_16(self):
        print("\nTest 16: Comprobando 'MCMXCIV' que debería dar 1994 (válido)")
        self._check_analyze("MCMXCIV", 1994, True)

    def test_cases_17(self):
        print("\nTest 17: Comprobando 'IIII' que debería ser inválido (debería ser IV)")
        self._check_analyze("IIII", 4, False)

    def test_cases_18(self):
        print("\nTest 18: Comprobando 'VIX' que debería ser inválido ('IX' no puede estar después de 'V')")
        self._check_analyze("VIX", 14, False)

if __name__ == '_main_':
    unittest.main()