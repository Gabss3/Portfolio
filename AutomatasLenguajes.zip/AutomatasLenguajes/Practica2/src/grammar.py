from __future__ import annotations

from collections import deque
from inspect import stack
from typing import AbstractSet, Collection, MutableSet, Optional, Dict, List, Optional

class RepeatedCellError(Exception):
    """Exception for repeated cells in LL(1) tables."""

class SyntaxError(Exception):
    """Exception for parsing errors."""

class Grammar:
    """
    Class that represents a grammar.

    Args:
        terminals: Terminal symbols of the grammar.
        non_terminals: Non terminal symbols of the grammar.
        productions: Dictionary with the production rules for each non terminal
          symbol of the grammar.
        axiom: Axiom of the grammar.

    """

    def __init__(
        self,
        terminals: AbstractSet[str],
        non_terminals: AbstractSet[str],
        productions: Dict[str, List[str]],
        axiom: str,
    ) -> None:
        if terminals & non_terminals:
            raise ValueError(
                "Intersection between terminals and non terminals "
                "must be empty.",
            )

        if axiom not in non_terminals:
            raise ValueError(
                "Axiom must be included in the set of non terminals.",
            )

        if non_terminals != set(productions.keys()):
            raise ValueError(
                f"Set of non-terminals and productions keys should be equal."
            )
        
        for nt, rhs in productions.items():
            if not rhs:
                raise ValueError(
                    f"No production rules for non terminal symbol {nt} "
                )
            for r in rhs:
                for s in r:
                    if (
                        s not in non_terminals
                        and s not in terminals
                    ):
                        raise ValueError(
                            f"Invalid symbol {s}.",
                        )

        self.terminals = terminals
        self.non_terminals = non_terminals
        self.productions = productions
        self.axiom = axiom

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"terminals={self.terminals!r}, "
            f"non_terminals={self.non_terminals!r}, "
            f"axiom={self.axiom!r}, "
            f"productions={self.productions!r})"
        )


    def compute_first(self, sentence: str) -> AbstractSet[str]:
        """
        Method to compute the first set of a string.

        Args:
            str: string whose first set is to be computed.

        Returns:
            First set of str.
        """
        vector_old={}
        vector_new={}
        nuevas_producciones=[]
        iguales=False
                
        if not sentence:
            return {""}
        
        symbols = list(sentence)

        #se parte del string inicial E -> TX para obtener los datos en la funcion en forma de diccionario lado_izquierdo -> lado_derecho
        for lado_izquierdo, producciones in self.productions.items():
            
            for produccion in producciones:
                # División del lado derecho en los símbolos de la producción.
                trozos = list(produccion)  
                             
                # Guardamos las producciones en la forma (lado izquierdo, lado derecho)
                nuevas_producciones.append((lado_izquierdo, trozos))

        for non_terminal in self.non_terminals:
            vector_old[non_terminal]=[]
            vector_new[non_terminal]=[]

        while iguales==False:
            iguales=True
            #vamos analizando las producciones una a una
            for lado_izquierdo, lado_derecho in nuevas_producciones:
            
                if not lado_derecho: 
                    if "" not in vector_new[lado_izquierdo]:
                        vector_new[lado_izquierdo].append("") 
                    continue
                
                first_right= lado_derecho[0]
                
                #en el caso de que P(E) sea P(T) ej: E->T 
                if first_right not in self.terminals:
                # Necesitamos propagar el FIRST de los no terminales recursivamente
                    first_set = set()
                    for lhs, rhs in nuevas_producciones:
                        if lhs == first_right:
                            if rhs is None:
                                break
                            for prod_symbol in rhs:
                                # Si el símbolo es un terminal, lo agregamos directamente
                                if prod_symbol in self.terminals:
                                    first_set.add(prod_symbol)
                                    break
                                # Si el símbolo es un no terminal, calculamos su FIRST
                                elif prod_symbol in self.non_terminals:
                                    # Revisamos si el FIRST de este no terminal ya contiene lambda
                                    for elem in vector_old[prod_symbol]:
                                        first_set.add(elem)
                                        if elem != '':  # Si no es lambda, terminamos
                                            break
                                    # Si contiene lambda, seguimos con el siguiente símbolo
                                    if '' in first_set:
                                        continue
                                    break
                    for elem in first_set:
                        if elem not in vector_new[lado_izquierdo]:
                            vector_new[lado_izquierdo].append(elem)

                    
                #en el caso de que E-> !
                elif first_right in self.terminals:
                    if first_right not in vector_new[lado_izquierdo]:
                        vector_new[lado_izquierdo].append(first_right)

            for non_terminal in self.non_terminals:
                first_old = [elem for elem in vector_old[non_terminal] if elem != '']
                first_new = [elem for elem in vector_new[non_terminal] if elem != '']

                if sorted(first_old) != sorted(first_new):
                    iguales = False
                    break

            # Si hubo cambios, actualizamos vector_old con los valores de vector_new
            if not iguales:       
                for non_terminal in self.non_terminals:
                    vector_old[non_terminal] = vector_new[non_terminal].copy()
                    
        first_set_result = set()

        if len(symbols) == 1:
            return set(vector_new[sentence])
        
        for i, symbol in enumerate(symbols):
            if symbol in self.terminals:
                first_set_result.add(symbol)
                if '' in first_set_result:
                    first_set_result.remove("")
                break  # Si es un terminal, no necesitamos más símbolos.
            else:
                # Si es un no terminal, tomamos su conjunto FIRST
                first_set_result.update(vector_new[symbol])
                if '' not in vector_new[symbol]:
                    first_set_result.remove("")
                    break  # Si no contiene lambda, paramos aquí
        return first_set_result


    def compute_follow(self, symbol: str) -> AbstractSet[str]:
        """
        Method to compute the follow set of a non-terminal symbol.

        Args:
            symbol: non-terminal whose follow set is to be computed.

        Returns:
            Follow set of symbol.
        """
        if symbol not in self.non_terminals:
            return ValueError
        
        vector_old={}
        vector_new={}
        nuevas_producciones=[]
        iguales=False
                
        #se parte del string inicial E -> TX para obtener los datos en la funcion en forma de diccionario lado_izquierdo -> lado_derecho
        for lado_izquierdo, producciones in self.productions.items():
            
            for produccion in producciones:
                # División del lado derecho en los símbolos de la producción.
                trozos = list(produccion)  
                             
                # Guardamos las producciones en la forma (lado izquierdo, lado derecho)
                nuevas_producciones.append((lado_izquierdo, trozos))
            
        #inicializamos los vectores. 
        for non_terminal in self.non_terminals:
            vector_old[non_terminal]=[]
            vector_new[non_terminal]=[]
            
        #El primer simbolo siempre tendra el simbolo de fin de cadena en su conjunto de siguientes. 
        vector_old[self.axiom].append('$')
        vector_new[self.axiom].append('$')    
        
        while iguales==False:
            iguales=True
            #lado_izquierdo es el no terminal del cual estamos buscando los siguientes
            for lado_izquierdo, lado_derecho in nuevas_producciones:
                
                #hay que iterar por el lado derecho de todas las producciones en busca del no terminal lado_izquierdo para analizar lo que hay despues
                for izq, derecho in nuevas_producciones:
                    
                    #caso en el que el lado derecho no contiene nada
                    if derecho is None:
                        continue
                    
                    #iteramos sobre los simbolos del lado derecho buscando el no terminal lado_izquierdo
                    for i in range(len(derecho)):
                        if derecho[i] == lado_izquierdo:
                            
                            #caso en el que es el ultimo simbolo del lado derecho -> hay que coger los siguientes del lado izquierdo de la produccion
                            if i == (len(derecho)-1):
                                
                                vector_new[lado_izquierdo].extend(vector_old[izq])
                            
                            #caso en el que el simbolo que le sigue es un no terminal -> hay que coger los primeros de ese no terminal, teniendo en cuenta que si tiene lambda entonces hay que coger los siguientes
                            elif derecho[i+1] in self.non_terminals:
                                                                
                                primeros = self.compute_first(derecho[i+1])
                                                                
                                #verificamos si lambda forma parte del conjunto, en cuyo caso agregamos tambien los siguientes del simbolo terminal
                                if '' in primeros:
                                    vector_new[lado_izquierdo].extend(vector_old[derecho[i+1]])
                                    
                                    #eliminamos lambda del conjunto primeros ya que el conjunto de siguientes no debe llevar lambdas
                                    primeros.remove("") 
                                
                                vector_new[lado_izquierdo].extend(primeros)
                            
                            #caso en el que el simbolo que le sigue es un terminal
                            elif derecho[i+1] in self.terminals:                                
                                vector_new[lado_izquierdo].append(derecho[i+1])
               
            dict1_sets = {key: set(value) for key, value in vector_old.items()}
            dict2_sets = {key: set(value) for key, value in vector_new.items()}

            if dict1_sets != dict2_sets:
                iguales = False
                for non_terminal in self.non_terminals:
                    vector_old[non_terminal] = vector_new[non_terminal].copy()
        
        return set(vector_new[symbol])          

    def get_ll1_table(self) -> Optional[LL1Table]:
        """
        Method to compute the LL(1) table.

        Returns:
            LL(1) table for the grammar, or None if the grammar is not LL(1).
        """

        terminales = self.terminals.union('$')
        tabla_L1 = LL1Table(self.non_terminals, terminales)
        
        nuevas_producciones = []
        
        for lado_izquierdo, producciones in self.productions.items():
            
            for produccion in producciones:      
                if produccion:  #Ignoramos producciones vacías
                    nuevas_producciones.append((lado_izquierdo, produccion))                                          
                    
        for lado_izquierdo, lado_derecho in nuevas_producciones:
            
            if not lado_derecho:
                continue
                        
            #si el primer elemento del lado derecho de la produccion es un no terminal ej: E -> TX, el primer elemento en este caso seria T
            if lado_derecho[0] in self.non_terminals:
                
                primeros_der = self.compute_first(lado_derecho[0])
                
                #miramos si el conjutno de primeros obtenido contiene lambda
                if '' in primeros_der:
                    siguientes_izq = self.compute_follow(lado_izquierdo)
                    
                    #como contiene lambda se miran los siguientes
                    for siguientes in siguientes_izq:
                        try:
                            tabla_L1.add_cell(lado_izquierdo, siguientes, "")
                        except ValueError:
                            return None
                
                    primeros_der.remove("")
                
                for primero in primeros_der:
                    try:
                        tabla_L1.add_cell(lado_izquierdo, primero, lado_derecho)
                    except RepeatedCellError:
                        return None
                        
            #si el primer elemento del lado derecho de la produciion es un terminal ej T -> (E), el primer elemento en este caso seria (
            elif lado_derecho[0] in self.terminals:
                try:
                    tabla_L1.add_cell(lado_izquierdo, lado_derecho[0], lado_derecho)
                except RepeatedCellError:
                    return None
                
                primeros_izq =  self.compute_first(lado_izquierdo)
                
                #miramos si el lado izquierdo de la produccion contiene lambda en su conjunto de primeros
                if '' in primeros_izq:
                    siguientes_izq = self.compute_follow(lado_izquierdo)
                    
                    #como contiene lambda se miran los siguientes
                    for siguientes in siguientes_izq:
                        try:
                            tabla_L1.add_cell(lado_izquierdo, siguientes, "")
                        except ValueError:
                            return None
        return tabla_L1                   

    def is_ll1(self) -> bool:
        return self.get_ll1_table() is not None


class LL1Table:
    """
    LL1 table. Initially all cells are set to None (empty). Table cells
    must be filled by calling the method add_cell.

    Args:
        non_terminals: Set of non terminal symbols.
        terminals: Set of terminal symbols.

    """

    def __init__(
        self,
        non_terminals: AbstractSet[str],
        terminals: AbstractSet[str],
    ) -> None:

        if terminals & non_terminals:
            raise ValueError(
                "Intersection between terminals and non terminals "
                "must be empty.",
            )

        self.terminals: AbstractSet[str] = terminals
        self.non_terminals: AbstractSet[str] = non_terminals
        self.cells: Dict[str, Dict[str, Optional[str]]] = {nt: {t: None for t in terminals} for nt in non_terminals}

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"terminals={self.terminals!r}, "
            f"non_terminals={self.non_terminals!r}, "
            f"cells={self.cells!r})"
        )

    def add_cell(self, non_terminal: str, terminal: str, cell_body: str) -> None:
        """
        Adds a cell to an LL(1) table.

        Args:
            non_terminal: Non termial symbol (row)
            terminal: Terminal symbol (column)
            cell_body: content of the cell 

        Raises:
            RepeatedCellError: if trying to add a cell already filled.
        """
        if non_terminal not in self.non_terminals:
            raise ValueError(
                "Trying to add cell for non terminal symbol not included "
                "in table.",
            )
        if terminal not in self.terminals:
            raise ValueError(
                "Trying to add cell for terminal symbol not included "
                "in table.",
            )
        if not all(x in self.terminals | self.non_terminals for x in cell_body):
            raise ValueError(
                "Trying to add cell whose body contains elements that are "
                "not either terminals nor non terminals.",
            )            
        if self.cells[non_terminal][terminal] is not None:
            raise RepeatedCellError(
                f"Repeated cell ({non_terminal}, {terminal}).")
        else:
            self.cells[non_terminal][terminal] = cell_body

    def analyze(self, input_string: str, start: str) -> ParseTree:
        """
        Method to analyze a string using the LL(1) table.

        Args:
            input_string: string to analyze.
            start: initial symbol.

        Returns:
            ParseTree object with either the parse tree (if the elective exercise is solved)
            or an empty tree (if the elective exercise is not considered).

        Raises:
            SyntaxError: if the input string is not syntactically correct.
        """

        parseTree = ParseTree(start, [])
        pila = deque([ParseTree("$"), parseTree])
    

        if input_string[-1] != "$":
            raise SyntaxError("Error de sintaxis: cadena no termina con $")

        while len(input_string) != 0:
            elemento_root = pila.pop()
            elemento = elemento_root.root
          

            if elemento == "$" and input_string[0] == "$":
                break

            if input_string[0] not in self.terminals:
                raise SyntaxError("Error de sintaxis: símbolo inesperado en la entrada")

            if elemento in self.terminals:
                if elemento == input_string[0]:
                    input_string = input_string[1:]
                    continue
                else:
                    raise SyntaxError("Error de sintaxis: terminal no coincide")

            if elemento not in self.non_terminals:
                raise SyntaxError("Error de sintaxis: elemento desconocido")

            if elemento in self.non_terminals:
                nuevo_elemento = self.cells[elemento][input_string[0]]
                if nuevo_elemento is None:
                    raise SyntaxError("Error de sintaxis: producción no encontrada")

                if nuevo_elemento == "":
                    elemento_root.add_children([ParseTree("λ")])
                    continue
                
                nuevo_elemento = list(nuevo_elemento)

                # Crear nodos hijos para el árbol de análisis
                new_children = [ParseTree(sym, []) for sym in nuevo_elemento]

            
                # Añadir los hijos a la producción actual
                elemento_root.add_children(new_children)
                
                for i in range(len(nuevo_elemento) - 1, -1, -1):
                    pila.append(new_children[i])

        if len(input_string) > 0 and input_string != "$":
            raise SyntaxError("Error de sintaxis: cadena restante no procesada")

        return parseTree
    
class ParseTree():
    """
    Parse Tree.

    Args:
        root: root node of the tree.
        children: list of children, which are also ParseTree objects.
    """
    def __init__(self, root: str, children: Collection[ParseTree] = []) -> None:
        self.root = root
        self.children = children

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}({self.root!r}: {self.children})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return (
            self.root == other.root
            and len(self.children) == len(other.children)
            and all([x.__eq__(y) for x, y in zip(self.children, other.children)])
        )

    def add_children(self, children: Collection[ParseTree]) -> None:
        self.children = children
