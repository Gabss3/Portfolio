import ply.yacc as yacc
from roman_lexer import tokens

flag=False

roman_values = {
    "I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000,
    "IV": 4, "IX": 9, "XL": 40, "XC": 90, "CD": 400, "CM": 900
}

#Hemos creado una función para informar del error en concreto cuando valid es False
def report_error(msg):
    print(f"Error: {msg}")

# Gramática

def p_romanNumber(p):
    """romanNumber : thousand hundred ten digit"""
    global flag
    if flag==True:
        p[0] = {"val": 0, "valid": False}   
    else:
        p[0] = {
            "val": p[1]["val"] + p[2]["val"] + p[3]["val"] + p[4]["val"],
            "valid": p[1]["valid"] and p[2]["valid"] and p[3]["valid"] and p[4]["valid"]
        }
    
    flag = False

def p_thousand(p):
    """thousand : M thousand
                | lambda"""
    if len(p) == 3:
        p[0] = {"val": roman_values["M"] + p[2]["val"], "valid": p[2]["valid"]}
    else:
        p[0] = {"val": 0, "valid": True}

def p_hundred(p):
    """hundred : small_hundred
               | D small_hundred
               | C D
               | C M"""
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 3 and isinstance(p[2], dict):
        p[0] = {"val": roman_values["D"] + p[2]["val"], "valid": p[2]["valid"]}
    elif len(p) == 3:
        key = p[1] + p[2]
        if key in roman_values:
            p[0] = {"val": roman_values[key], "valid": True}
        else:
            report_error(f"Secuencia inválida en centenas: {key}")
            p[0] = {"val": 0, "valid": False}
    else:
        p[0] = {"val": 0, "valid": True}

def p_small_hundred(p):
    """small_hundred : C small_hundred
                     | lambda"""
    if len(p) == 3:
        p[0] = {"val": roman_values["C"] + p[2]["val"], "valid": p[2]["valid"]}
    else:
        p[0] = {"val": 0, "valid": True}

def p_ten(p):
    """ten : small_ten
           | X L
           | L small_ten
           | X C"""
    if len(p) == 2:
        p[0] = p[1] if isinstance(p[1], dict) else {"val": 0, "valid": False}
    elif len(p) == 3:
        key = p[1] + p[2] if isinstance(p[1], str) and isinstance(p[2], str) else None
        if key in roman_values:
            p[0] = {"val": roman_values[key], "valid": True}
        elif isinstance(p[2], dict): #para el caso recursivo
            p[0] = {"val": roman_values[p[1]] + p[2]["val"], "valid": p[2]["valid"]}
        else:
            p[0] = {"val": 0, "valid": False}


def p_small_ten(p):
    """small_ten : X small_ten
                 | lambda"""
    if len(p) == 3:
        if p[2]["val"] // roman_values["X"] < 3:
            p[0] = {"val": roman_values["X"] + p[2]["val"], "valid": p[2]["valid"]}
        else:
            p[0] = {"val": 0, "valid": False}
            report_error("Demasiados 'X' consecutivos.")
    else:
        p[0] = {"val": 0, "valid": True}


def p_small_digit(p):
    """small_digit : I small_digit
                   | lambda"""
    if len(p) == 3:
        if p[2]["val"] // roman_values["I"] < 3:
            p[0] = {"val": roman_values["I"] + p[2]["val"], "valid": p[2]["valid"]}
        else:
            p[0] = {"val": 0, "valid": False}
            report_error("Demasiados 'I' consecutivos.")
    else:
        p[0] = {"val": 0, "valid": True}


def p_digit(p):
    """digit : I V
             | V small_digit
             | I X
             | small_digit"""
    if len(p) == 3:
        key = p[1] + p[2] if isinstance(p[1], str) and isinstance(p[2], str) else None
        if key in roman_values:
            p[0] = {"val": roman_values[key], "valid": True}
        elif isinstance(p[2], dict):
            p[0] = {"val": roman_values[p[1]] + p[2]["val"], "valid": p[2]["valid"]}
        else:
            p[0] = {"val": 0, "valid": False}
            report_error(f"Combinación inválida: {p[1]}{p[2]}")
    else:
        p[0] = p[1] if isinstance(p[1], dict) else {"val": 0, "valid": False}


def p_empty(p):
    'lambda :'
    p[0] = {"val": 0, "valid": True}

def p_roman(p):
    """roman : romanNumber"""
    if p[1]["valid"]:
        p[0] = p[1]
    else:
        p[0] = {"val": 0, "valid": False}
        report_error("Número romano inválido en la estructura final.")

def p_error(p):
    global flag
    flag=True
    if p:
        print(f"Error de sintaxis en '{p.value}'")
    else:
        print("Error inesperado o EOF")
    
        p[0] = {"val": 0, "valid": False}

parser = yacc.yacc()

if __name__ == "__main__":
    while True:
        try:
            s = input("Ingrese un número romano: ")
        except EOFError:
            break
        if not s:
            continue
        result = parser.parse(s)
        if result is None:
            print("Número romano inválido")
        else:
            print(f"El valor numérico es: {result}")
