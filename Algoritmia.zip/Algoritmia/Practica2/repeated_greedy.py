import numpy as np

def dist_matrix(n_nodes: int, w_max=10) -> np.ndarray: 
    
    m = np.random.randint(1, w_max+1, (n_nodes, n_nodes))
    m = (m + m.T) // 2
    np.fill_diagonal(m, 0)
    
    return m

def greedy_tsp(dist_m: np.ndarray, node_ini=0) -> list:
    
    num_cities = dist_m.shape[0]
    circuit = [node_ini]
    
    while len(circuit) < num_cities:
        current_city = circuit[-1]
        
    # sort cities in ascending distance from current
        options = np.argsort(dist_m[ current_city ])
        
    # add first city in sorted list not visited yet
        for city in options:
            if city not in circuit:
                circuit.append(city)
                break
            
    return circuit + [node_ini]

def len_circuit(circuit: list, dist_m: np.ndarray)-> int:
    length = 0
    n_inicio = 0
    n_fin = 0
    
    for i in range(len(circuit)-1):
        n_inicio = circuit[i]
        n_fin = circuit[i+1]
        
        length += dist_m[n_inicio][n_fin]
    
    return length

def repeated_greedy_tsp(dist_m: np.ndarray)-> list:
    
    len = dist_m.shape[0]

    least_len = 0
    actual_len = 0
    
    least_circuit = []
    circuit = []
    
    least_circuit = greedy_tsp(dist_m, 0)
    least_len = float('inf')
    print(least_len)
    for i in range(len-1):
        circuit = greedy_tsp(dist_m, i)
        
        actual_len = len_circuit(circuit, dist_m)
        
        if actual_len < least_len:
            least_len = actual_len
            least_circuit = circuit
            
    return least_circuit
        
matrix = dist_matrix(5, 10)

print(matrix)

l_v = repeated_greedy_tsp(matrix)

print(l_v)

len = len_circuit(l_v, matrix)

print(len)   
    