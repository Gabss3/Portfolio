import random
from typing import List, Tuple

def complete_graph(n_nodes: int, max_weight=50) -> Tuple[int, List]:
    l_g = []  # Almacenará las aristas del grafo

    for u in range(n_nodes):
        for v in range(u + 1, n_nodes):
            peso = random.randint(1, max_weight)
            l_g.append((u, v, peso))

    return n_nodes, l_g

# Ejemplo de uso
n_nodos = 5  # Número de nodos en el grafo completo
max_weight = 50  # Peso máximo de las aristas

n, l_g = complete_graph(n_nodos, max_weight)
print("Número de nodos en el grafo:", n)
print("Aristas del grafo completo:")
for arista in l_g:
    print(arista)
        