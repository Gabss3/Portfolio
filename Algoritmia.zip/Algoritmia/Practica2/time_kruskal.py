import random
import time
from typing import List, Tuple
import numpy as np

def find(ind: int, p_cd: np.ndarray) -> int:
  z = ind

  while p_cd[z] >= 0:
      z = p_cd[z]

  while p_cd[ind] >= 0:
      y = p_cd[ind]
      p_cd[ind] = z
      ind = y
  return z

def union(rep_1: int, rep_2: int, p_cd: np.ndarray) -> int:
  if p_cd[rep_2] < p_cd[rep_1]:
      p_cd[rep_1] = rep_2
      return rep_2
  elif p_cd[rep_2] > p_cd[rep_1]:
      p_cd[rep_2] = rep_1
      return rep_1
  else:
      p_cd[rep_2] = rep_1
      p_cd[rep_1] -= 1
      return rep_1

def create_pq(n: int, l_g: list)-> queue.PriorityQueue:
  cola = PriorityQueue()
  i = 0
  l = len(l_g) 
  while i< l:
      cola.put((l_g[i][2], l_g[i]))
      i = i + 1
  return cola



def kruskal(n: int, l_g: List) -> Tuple[int, List]:
  ramas = []  
  peso_tot = 0  

  l_g = create_pq(n, l_g)

  p_cd = np.full(n, -1, dtype=int)

  while not l_g.empty():
      peso, arista = l_g.get() 
      u, v, _ = arista

      raiz_u = find(u, p_cd)
      raiz_v = find(v, p_cd)
      if raiz_u != raiz_v:
          ramas.append((u, v, peso))
          peso_tot += peso
          union(raiz_u, raiz_v, p_cd)

  if len(ramas) == n - 1:
      return peso_tot, ramas
  else:
      return None

def complete_graph(n_nodes: int, max_weight=50) -> Tuple[int, List]:
    l_g = []  # Almacenará las aristas del grafo

    for u in range(n_nodes):
        for v in range(u + 1, n_nodes):
            weight = random.randint(1, max_weight)
            l_g.append((u, v, weight))

    return n_nodes, l_g

def time_kruskal(n_graphs: int, n_nodes_ini: int, n_nodes_fin: int, step: int) -> List[float]:
    times = []  # Almacenará los tiempos medios de ejecución

    for n_nodes in range(n_nodes_ini, n_nodes_fin + 1, step):
        total_time = 0

        for _ in range(n_graphs):
            # Generar un grafo completo aleatorio
            n, l_g = complete_graph(n_nodes)

            # Medir el tiempo de ejecución de kruskal
            start_time = time.time()
            result = kruskal(n, l_g)
            end_time = time.time()

            # Calcular el tiempo transcurrido y sumarlo al tiempo total
            execution_time = end_time - start_time
            total_time += execution_time

        # Calcular el tiempo medio y agregarlo a la lista de tiempos
        average_time = total_time / n_graphs
        times.append(average_time)

    return times

# Ejemplo de uso
n_graphs = 10  # Número de grafos aleatorios para cada número de nodos
n_nodes_ini = 5  # Número inicial de nodos
n_nodes_fin = 20  # Número final de nodos
step = 5  # Incremento de nodos

average_times = time_kruskal(n_graphs, n_nodes_ini, n_nodes_fin, step)
print("Tiempos medios de ejecución para cada número de nodos:")
for i, time in enumerate(average_times):
    print(f"{n_nodes_ini + i * step} nodos: {time:.6f} segundos")
