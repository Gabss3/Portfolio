import numpy as np

def union(rep_1: int, rep_2: int, p_cd: np.ndarray)-> int:
    
    if p_cd[rep_2] < p_cd[rep_1]:
        p_cd[rep_1] = rep_2; return rep_2
    elif p_cd[rep_2] > p_cd[rep_1]: 
        p_cd[rep_2] = rep_1; return rep_1
    else: 
        p_cd[rep_2] = rep_1; p_cd[rep_1] -= 1; 
        return rep_1