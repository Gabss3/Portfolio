import numpy as np

def dist_matrix(n_nodes: int, w_max=10) -> np.ndarray: 
    
    m = np.random.randint(1, w_max+1, (n_nodes, n_nodes))
    m = (m + m.T) // 2
    np.fill_diagonal(m, 0)
    
    return m

def greedy_tsp(dist_m: np.ndarray, node_ini=0) -> list:
    
    num_cities = dist_m.shape[0]
    print(num_cities)
    circuit = [node_ini]
    
    while len(circuit) < num_cities:
        current_city = circuit[-1]
        
    # sort cities in ascending distance from current
        options = np.argsort(dist_m[ current_city ])
        print(options)
    # add first city in sorted list not visited yet
        for city in options:
            if city not in circuit:
                circuit.append(city)
                break
            
    return circuit + [node_ini]

matrix = dist_matrix(5, 10)

print(matrix)

l_v = greedy_tsp(matrix, 0)

print(l_v)
