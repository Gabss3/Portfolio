import numpy as np
import queue
import random
import time
from typing import List, Tuple
from queue import PriorityQueue
from itertools import permutations

def init_cd(n: int) -> np.ndarray:
    """
    Inicializa un array de compresión de caminos de longitud n.
    
    Args:
    - n (int): Longitud del array.

    Returns:
    - np.ndarray: Array de compresión de caminos inicializado.
    """
    array = np.full(n, -1, dtype=int)
    return array

def find(ind: int, p_cd: np.ndarray) -> int:
    """
    Encuentra la raíz del conjunto al que pertenece el índice ind.

    Args:
    - ind (int): Índice para encontrar la raíz.
    - p_cd (np.ndarray): Array de compresión de caminos.

    Returns:
    - int: Raíz del conjunto al que pertenece el índice.
    """
    z = ind
    while p_cd[z] >= 0:
        z = p_cd[z]

    while p_cd[ind] >= 0:
        y = p_cd[ind]
        p_cd[ind] = z
        ind = y
    return z

def union(rep_1: int, rep_2: int, p_cd: np.ndarray) -> int:
    """
    Realiza la unión de dos conjuntos dados sus representantes.

    Args:
    - rep_1 (int): Representante del primer conjunto.
    - rep_2 (int): Representante del segundo conjunto.
    - p_cd (np.ndarray): Array de compresión de caminos.

    Returns:
    - int: Representante del conjunto resultante después de la unión.
    """
    if p_cd[rep_2] < p_cd[rep_1]:
        p_cd[rep_1] = rep_2
        return rep_2
    elif p_cd[rep_2] > p_cd[rep_1]:
        p_cd[rep_2] = rep_1
        return rep_1
    else:
        p_cd[rep_2] = rep_1
        p_cd[rep_1] -= 1
        return rep_1

def create_pq(n: int, l_g: List) -> queue.PriorityQueue:
    """
    Crea y devuelve una cola de prioridad a partir de una lista de aristas.

    Args:
    - n (int): Número de nodos en el grafo.
    - l_g (List): Lista de aristas con pesos.

    Returns:
    - queue.PriorityQueue: Cola de prioridad con las aristas.
    """
    if n < 0 or l_g is None:
        return None

    cola = PriorityQueue()
    i = 0
    l = len(l_g)

    while i < l:
        cola.put((l_g[i][2], l_g[i]))
        i += 1

    return cola

def kruskal(n: int, l_g: List) -> Tuple[int, List]:
    """
    Implementa el algoritmo de Kruskal para encontrar el árbol de expansión mínima.

    Args:
    - n (int): Número de nodos en el grafo.
    - l_g (List): Lista de aristas con pesos.

    Returns:
    - Tuple[int, List]: Peso total del árbol de expansión mínima y las aristas que lo componen.
    """
    ramas = []
    peso_tot = 0

    l_g.sort(key=lambda x: x[2])

    p_cd = np.full(n, -1, dtype=int)

    for arista in l_g:
        u, v, peso = arista

        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)

        if raiz_u != raiz_v:
            ramas.append((u, v, peso))
            peso_tot += peso
            union(raiz_u, raiz_v, p_cd)

    if len(ramas) == n - 1:
        return peso_tot, ramas
    else:
        return None

def kruskal2(n: int, l_g: List) -> Tuple[int, List]:
    """
    Implementa una variante de Kruskal usando una cola de prioridad.

    Args:
    - n (int): Número de nodos en el grafo.
    - l_g (List): Lista de aristas con pesos.

    Returns:
    - Tuple[int, List]: Peso total del árbol de expansión mínima y las aristas que lo componen.
    """
    ramas = []
    peso_tot = 0
    total_time = 0

    l_g = create_pq(n, l_g)

    p_cd = np.full(n, -1, dtype=int)

    while not l_g.empty():
        peso, arista = l_g.get()
        u, v, _ = arista

        start_time = time.time()
        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)
        if raiz_u != raiz_v:
            ramas.append((u, v, peso))
            peso_tot += peso
            union(raiz_u, raiz_v, p_cd)
        end_time = time.time()
        execution_time = end_time - start_time
        total_time += execution_time

    return peso_tot, ramas

def complete_graph(n_nodes: int, max_weight=50) -> Tuple[int, List[Tuple[int, int, int]]]:
    """
    Genera un grafo completo aleatorio con pesos de hasta max_weight.

    Args:
    - n_nodes (int): Número de nodos en el grafo.
    - max_weight (int): Peso máximo para las aristas (por defecto 50).

    Returns:
    - Tuple[int, List[Tuple[int, int, int]]]: Número de nodos y lista de aristas con pesos.
    """
    l_g = []

    for u in range(n_nodes):
        for v in range(u + 1, n_nodes):
            peso = random.randint(1, max_weight)
            l_g.append((u, v, peso))

    return n_nodes, l_g

def time_kruskal_2(n_graphs: int, n_nodes_ini: int, n_nodes_fin: int, step: int) -> List[float]:
    """
    Mide el tiempo promedio de ejecución de kruskal para grafos completos aleatorios.

    Args:
    - n_graphs (int): Número de grafos a generar y evaluar.
    - n_nodes_ini (int): Número inicial de nodos en el grafo.
    - n_nodes_fin (int): Número final de nodos en el grafo.
    - step (int): Incremento en el número de nodos entre grafos.

    Returns:
    - List[float]: Lista de tiempos medios de ejecución.
    """
    times = []

    for n_nodes in range(n_nodes_ini, n_nodes_fin + 1, step):
        total_time = 0

        for _ in range(n_graphs):
            n, l_g = complete_graph(n_nodes)
            result = kruskal(n, l_g)
            total_time += result[2]

        average_time = total_time / n_graphs
        times.append(average_time)

    return times

def time_kruskal(n_graphs: int, n_nodes_ini: int, n_nodes_fin: int, step: int) -> List[float]:
    """
    Mide el tiempo promedio de ejecución de kruskal para grafos completos aleatorios.

    Args:
    - n_graphs (int): Número de grafos a generar y evaluar.
    - n_nodes_ini (int): Número inicial de nodos en el grafo.
    - n_nodes_fin (int): Número final de nodos en el grafo.
    - step (int): Incremento en el número de nodos entre grafos.

    Returns:
    - List[float]: Lista de tiempos medios de ejecución.
    """
    times = []

    for n_nodes in range(n_nodes_ini, n_nodes_fin + 1, step):
        total_time = 0

        for _ in range(n_graphs):
            # Generar un grafo completo aleatorio
            n, l_g = complete_graph(n_nodes)

            # Medir el tiempo de ejecución de kruskal
            start_time = time.time()
            result = kruskal(n, l_g)
            end_time = time.time()

            # Calcular el tiempo transcurrido y sumarlo al tiempo total
            execution_time = end_time - start_time
            total_time += execution_time

        # Calcular el tiempo medio y agregarlo a la lista de tiempos
        average_time = total_time / n_graphs
        times.append(average_time)

    return times

def dist_matrix(n_nodes: int, w_max=10) -> np.ndarray:
    """
    Genera una matriz de distancias aleatorias entre nodos.

    Args:
    - n_nodes (int): Número de nodos en el grafo.
    - w_max (int): Valor máximo para las distancias (por defecto 10).

    Returns:
    - np.ndarray: Matriz de distancias entre nodos.
    """
    m = np.random.randint(1, w_max + 1, (n_nodes, n_nodes))
    m = (m + m.T) // 2
    np.fill_diagonal(m, 0)

    return m

def greedy_tsp(dist_m: np.ndarray, node_ini=0) -> List[int]:
    """
    Implementa el algoritmo de búsqueda del vecino más cercano para el Problema del Viajante de Comercio.

    Args:
    - dist_m (np.ndarray): Matriz de distancias entre nodos.
    - node_ini (int): Nodo inicial para el recorrido (por defecto 0).

    Returns:
    - List[int]: Circuito resultante del TSP.
    """
    num_cities = dist_m.shape[0]
    circuit = [node_ini]

    while len(circuit) < num_cities:
        current_city = circuit[-1]

        # Ordenar ciudades en orden ascendente por distancia desde la actual
        options = np.argsort(dist_m[current_city])

        # Añadir la primera ciudad en la lista ordenada que aún no ha sido visitada
        for city in options:
            if city not in circuit:
                circuit.append(city)
                break

    return circuit + [node_ini]

def len_circuit(circuit: List[int], dist_m: np.ndarray) -> int:
    """
    Calcula la longitud total de un circuito dado la matriz de distancias.

    Args:
    - circuit (List[int]): Circuito para calcular su longitud.
    - dist_m (np.ndarray): Matriz de distancias entre nodos.

    Returns:
    - int: Longitud total del circuito.
    """
    length = 0
    n_inicio = 0
    n_fin = 0

    for i in range(len(circuit)-1):
        n_inicio = circuit[i]
        n_fin = circuit[i+1]

        length += dist_m[n_inicio][n_fin]

    return length

def repeated_greedy_tsp(dist_m: np.ndarray) -> List[int]:
    """
    Implementa el algoritmo de búsqueda del vecino más cercano repetido para el Problema del Viajante de Comercio.

    Args:
    - dist_m (np.ndarray): Matriz de distancias entre nodos.

    Returns:
    - List[int]: Circuito resultante del TSP.
    """
    num_cities = dist_m.shape[0]

    least_len = np.inf
    least_circuit = []

    for i in range(num_cities):
        circuit = greedy_tsp(dist_m, i)
        actual_len = len_circuit(circuit, dist_m)

        if actual_len < least_len:
            least_len = actual_len
            least_circuit = circuit

    return least_circuit

def exhaustive_tsp(dist_m: np.ndarray) -> List[int]:
    """
    Implementa la búsqueda exhaustiva para el Problema del Viajante de Comercio.

    Args:
    - dist_m (np.ndarray): Matriz de distancias entre nodos.

    Returns:
    - List[int]: Circuito resultante del TSP.
    """
    least_circuit = []
    circuit = list(range(dist_m.shape[0]))

    least_length = np.inf
    circuit_list = permutations(circuit)

    for i in circuit_list:
        i = list(i)
        i.append(i[0])

        actual_length = len_circuit(i, dist_m)

        if actual_length < least_length:
            least_length = actual_length
            least_circuit = list(i)

    return least_circuit
