import queue
from queue import PriorityQueue

def create_pq(n: int, l_g: list)-> queue.PriorityQueue:
    
    if n<0 or l_g==None:
        return None
    
    cola = PriorityQueue()
    i = 0
    l = len(l_g)
    print(l) 
    
    while i < l:
        cola.put((l_g[i][2], l_g[i]))
        i=i+1   
        
    return cola


l_g = [[0,1,5], [0,2,3], [0,3,2], [1,3,4], [1,4,1], [3,4,2]]

cola = create_pq(5, l_g)

while cola:
    print(cola.get())
    

