import numpy as np
import queue
import time
from queue import PriorityQueue
from typing import List, Tuple

def init_cd(n: int) -> np.ndarray:
    # Crear un array de tamaño n, inicializado con -1, que servirá como estructura de conjuntos disjuntos.
    array = np.full(n, -1, dtype=int)
    # Retornar la estructura inicializada.
    return array

def create_pq(n: int, l_g: List) -> queue.PriorityQueue:
    # Verificar condiciones de entrada.
    if n < 0 or l_g is None:
        return None
    # Inicializar una cola de prioridad.
    cola = PriorityQueue()
    i = 0
    l = len(l_g)
    # Agregar las aristas a la cola de prioridad con el peso como clave.
    while i < l:
        cola.put((l_g[i][2], l_g[i]))
        i += 1
    # Retornar la cola de prioridad.
    return cola

def find(ind: int, p_cd: np.ndarray) -> int:
    z = ind

    while p_cd[z] >= 0:
        z = p_cd[z]

    while p_cd[ind] >= 0:
        y = p_cd[ind]
        p_cd[ind] = z
        ind = y
    return z

def union(rep_1: int, rep_2: int, p_cd: np.ndarray) -> int:
    if p_cd[rep_2] < p_cd[rep_1]:
        p_cd[rep_1] = rep_2
        return rep_2
    elif p_cd[rep_2] > p_cd[rep_1]:
        p_cd[rep_2] = rep_1
        return rep_1
    else:
        p_cd[rep_2] = rep_1
        p_cd[rep_1] -= 1
        return rep_1

def kruskal(n: int, l_g: List) -> Tuple[int, List]:
    ramas = []  
    peso_tot = 0  

    cola  = create_pq(n, l_g)

    p_cd = init_cd(n)

    while not cola.empty():
        peso, arista = cola.get()
        u, v, _ = arista

        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)

        if raiz_u != raiz_v:
            ramas.append((u, v, peso))
            peso_tot += peso
            union(raiz_u, raiz_v, p_cd)


    if len(ramas) == n - 1:
        return peso_tot, ramas
    else:
        return None
    
    
def kruskal2(n: int, l_g: List) -> Tuple[int, List]:
    # Inicializar listas para almacenar las aristas del árbol y el peso total.
    ramas = []
    peso_tot = 0
    total_time = 0
    # Crear cola de prioridad a partir de la lista de aristas.
    l_g = create_pq(n, l_g)
    # Inicializar estructura Union-Find.
    p_cd = np.full(n, -1, dtype=int)
    # Iterar sobre las aristas en orden de menor a mayor peso.
    while not l_g.empty():
        peso, arista = l_g.get()
        u, v, _ = arista
        # Medir el tiempo de ejecución de find y union.
        start_time = time.time()
        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)
        # Verificar si la adición de la arista crea un ciclo en el árbol.
        if raiz_u != raiz_v:
            # Agregar la arista al árbol y actualizar el peso total.
            ramas.append((arista))
            peso_tot += peso
            # Realizar la unión de los conjuntos.
            union(raiz_u, raiz_v, p_cd)
        end_time = time.time()
        # Acumular el tiempo de ejecución.
        execution_time = end_time - start_time
        total_time += execution_time
    # Retornar el peso total y las aristas del árbol.
    return peso_tot, ramas



n = 4  
l_g = [(0, 1, 1), (0, 2, 2), (1, 2, 3), (1, 3, 4), (2, 3, 5)]

result = kruskal(n, l_g)
if result is not None:
    weight, l_t = result
    print("Peso total del AAM:", weight)
    print("Ramas del AAM:", l_t)
else:
    print("No se encontró un AAM para el grafo dado.")