import numpy as np

def init_cd(n: int)-> np.ndarray:
    array=[]
    i=0
    while i<n:
        array[i]=-1
        i = i+1

    