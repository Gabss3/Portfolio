
from queue import PriorityQueue
from itertools import permutations
import queue
import random
import time
from typing import List, Tuple
import numpy as np

# Función: init_cd
# Autores: [Nombres de los autores]
# Descripción: Inicializa una estructura de conjuntos disjuntos (Union-Find).
# Parámetros de entrada:
# - n: Número de elementos en la estructura.
# Parámetros de salida:
# - array: Estructura inicializada con representantes para cada conjunto.
def init_cd(n: int) -> np.ndarray:
    # Crear un array de tamaño n, inicializado con -1, que servirá como estructura de conjuntos disjuntos.
    array = np.full(n, -1, dtype=int)
    # Retornar la estructura inicializada.
    return array


# Función: find
# Autores: [Autores]
# Descripción: Encuentra el representante del conjunto al que pertenece un elemento en la estructura Union-Find.
# Parámetros de entrada:
# - ind: Elemento cuyo representante se busca.
# - p_cd: Estructura de conjuntos disjuntos.
# Parámetros de salida:
# - z: Representante del conjunto al que pertenece el elemento.
def find(ind: int, p_cd: np.ndarray) -> int:
    # Inicializar z con el índice actual.
    z = ind
    # Encontrar el representante del conjunto mediante la búsqueda hacia arriba en la estructura.
    while p_cd[z] >= 0:
        z = p_cd[z]
    # Realizar compresión de camino para optimizar futuras búsquedas.
    while p_cd[ind] >= 0:
        y = p_cd[ind]
        p_cd[ind] = z
        ind = y
    # Retornar el representante del conjunto.
    return z


# Función: union
# Autores: [Autores]
# Descripción: Realiza la operación de unión en la estructura Union-Find.
# Parámetros de entrada:
# - rep_1: Representante del primer conjunto.
# - rep_2: Representante del segundo conjunto.
# - p_cd: Estructura de conjuntos disjuntos.
# Parámetros de salida:
# - rep_1 o rep_2: Nuevo representante después de la unión.
def union(rep_1: int, rep_2: int, p_cd: np.ndarray) -> int:
    # Comparar alturas de los conjuntos y realizar la unión adecuada.
    if p_cd[rep_2] < p_cd[rep_1]:
        p_cd[rep_1] = rep_2
        return rep_2
    if p_cd[rep_2] > p_cd[rep_1]:
        p_cd[rep_2] = rep_1
        return rep_1
    # En caso de igualdad de alturas, elegir uno como padre y decrementar la altura.
    p_cd[rep_2] = rep_1
    p_cd[rep_1] -= 1
    # Retornar el representante después de la unión.
    return rep_1


# Función: create_pq
# Autores: [Nombres de los autores]
# Descripción: Crea una cola de prioridad (PriorityQueue) a partir de una lista de aristas con pesos.
# Parámetros de entrada:
# - n: Número de nodos en el grafo.
# - l_g: Lista de aristas con pesos (u, v, peso).
# Parámetros de salida:
# - cola: Cola de prioridad inicializada con las aristas.
def create_pq(n: int, l_g: List) -> queue.PriorityQueue:
    # Verificar condiciones de entrada.
    if n < 0 or l_g is None:
        return None
    # Inicializar una cola de prioridad.
    cola = PriorityQueue()
    i = 0
    l = len(l_g)
    # Agregar las aristas a la cola de prioridad con el peso como clave.
    while i < l:
        cola.put((l_g[i][2], l_g[i]))
        i += 1
    # Retornar la cola de prioridad.
    return cola



# Función: kruskal
# Autores: [Nombres de los autores]
# Descripción: Implementa el algoritmo de Kruskal para encontrar un árbol de expansión mínima en un grafo.
# Parámetros de entrada:
# - n: Número de nodos en el grafo.
# - l_g: Lista de aristas con pesos (u, v, peso).
# Parámetros de salida:
# - peso_tot: Peso total del árbol de expansión mínima.
# - ramas: Lista de aristas que forman el árbol de expansión mínima.
def kruskal(n: int, l_g: List) -> Tuple[int, List]:
    # Inicializar listas para almacenar las aristas del árbol y el peso total.
    ramas = []
    peso_tot = 0
    # Ordenar las aristas por peso.
    l_g.sort(key=lambda x: x[2])
    # Inicializar estructura Union-Find.
    p_cd = np.full(n, -1, dtype=int)
    # Iterar sobre las aristas.
    for arista in l_g:
        u, v, peso = arista
        # Encontrar los representantes de los conjuntos a los que pertenecen los nodos.
        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)
        # Verificar si la adición de la arista crea un ciclo en el árbol.
        if raiz_u != raiz_v:
            # Agregar la arista al árbol y actualizar el peso total.
            ramas.append((u, v, peso))
            peso_tot += peso
            # Realizar la unión de los conjuntos.
            union(raiz_u, raiz_v, p_cd)
    # Verificar si se encontraron suficientes aristas para formar un árbol de expansión mínima.
    if len(ramas) == n - 1:
        return peso_tot, ramas
    return None


# Función: kruskal2
# Autores: [Nombres de los autores]
# Descripción: Implementa el algoritmo de Kruskal utilizando una cola de prioridad para las aristas.
# Parámetros de entrada:
# - n: Número de nodos en el grafo.
# - l_g: Lista de aristas con pesos (u, v, peso).
# Parámetros de salida:
# - peso_tot: Peso total del árbol de expansión mínima.
# - ramas: Lista de aristas que forman el árbol de expansión mínima.
def kruskal2(n: int, l_g: List) -> Tuple[int, List]:
    # Inicializar listas para almacenar las aristas del árbol y el peso total.
    ramas = []
    peso_tot = 0
    total_time = 0
    # Crear cola de prioridad a partir de la lista de aristas.
    l_g = create_pq(n, l_g)
    # Inicializar estructura Union-Find.
    p_cd = np.full(n, -1, dtype=int)
    # Iterar sobre las aristas en orden de menor a mayor peso.
    while not l_g.empty():
        peso, arista = l_g.get()
        u, v, _ = arista
        # Medir el tiempo de ejecución de find y union.
        start_time = time.time()
        raiz_u = find(u, p_cd)
        raiz_v = find(v, p_cd)
        # Verificar si la adición de la arista crea un ciclo en el árbol.
        if raiz_u != raiz_v:
            # Agregar la arista al árbol y actualizar el peso total.
            ramas.append((u, v, peso))
            peso_tot += peso
            # Realizar la unión de los conjuntos.
            union(raiz_u, raiz_v, p_cd)
        end_time = time.time()
        # Acumular el tiempo de ejecución.
        execution_time = end_time - start_time
        total_time += execution_time
    # Retornar el peso total y las aristas del árbol.
    return peso_tot, ramas


# Función: complete_graph
# Autores: [Nombres de los autores]
# Descripción: Genera un grafo completo con pesos aleatorios entre nodos.
# Parámetros de entrada:
# - n_nodes: Número de nodos en el grafo.
# - max_weight: Peso máximo para las aristas (por defecto, 50).
# Parámetros de salida:
# - n_nodes: Número de nodos en el grafo.
# - l_g: Lista de aristas con pesos generadas aleatoriamente.
def complete_graph(n_nodes: int, max_weight=50) -> Tuple[int, List[Tuple[int, int, int]]]:
    # Inicializar lista de aristas.
    l_g = []
    # Generar aristas entre todos los pares de nodos distintos.
    for u in range(n_nodes):
        for v in range(u + 1, n_nodes):
            peso = random.randint(1, max_weight)
            l_g.append((u, v, peso))
    # Retornar el número de nodos y la lista de aristas.
    return n_nodes, l_g


# Función: time_kruskal_2
# Autores: [Nombres de los autores]
# Descripción: Calcula el tiempo promedio de ejecución del algoritmo de Kruskal con cola de prioridad.
# Parámetros de entrada:
# - n_graphs: Número de grafos a generar y procesar.
# - n_nodes_ini: Número inicial de nodos en los grafos.
# - n_nodes_fin: Número final de nodos en los grafos.
# - step: Incremento en el número de nodos entre grafos.
# Parámetros de salida:
# - times: Lista de tiempos promedio de ejecución para cada número de nodos.
def time_kruskal_2(n_graphs: int, n_nodes_ini: int, n_nodes_fin: int, step: int) -> List[float]:
    # Inicializar lista de tiempos.
    times = []
    # Iterar sobre diferentes tamaños de grafos.
    for n_nodes in range(n_nodes_ini, n_nodes_fin + 1, step):
        total_time = 0
        # Generar y procesar varios grafos para obtener un promedio de tiempos.
        for _ in range(n_graphs):
            n, l_g = complete_graph(n_nodes)
            result = kruskal2(n, l_g)
            total_time += result[2]
        # Calcular el tiempo promedio.
        average_time = total_time / n_graphs
        # Agregar el tiempo promedio a la lista.
        times.append(average_time)
    # Retornar la lista de tiempos.
    return times


# Función: time_kruskal
# Autores: [Nombres de los autores]
# Descripción: Calcula el tiempo promedio de ejecución del algoritmo de Kruskal sin cola de prioridad.
# Parámetros de entrada:
# - n_graphs: Número de grafos a generar y procesar.
# - n_nodes_ini: Número inicial de nodos en los grafos.
# - n_nodes_fin: Número final de nodos en los grafos.
# - step: Incremento en el número de nodos entre grafos.
# Parámetros de salida:
# - times: Lista de tiempos promedio de ejecución para cada número de nodos.
def time_kruskal(n_graphs: int, n_nodes_ini: int, n_nodes_fin: int, step: int) -> List[float]:
    # Inicializar lista de tiempos.
    times = []
    # Iterar sobre diferentes tamaños de grafos.
    for n_nodes in range(n_nodes_ini, n_nodes_fin + 1, step):
        total_time = 0
        # Generar y procesar varios grafos para obtener un promedio de tiempos.
        for _ in range(n_graphs):
            n, l_g = complete_graph(n_nodes)
            # Medir el tiempo de ejecución de Kruskal.
            start_time = time.time()
            kruskal(n, l_g)
            end_time = time.time()
            # Calcular el tiempo de ejecución.
            execution_time = end_time - start_time
            total_time += execution_time
        # Calcular el tiempo promedio.
        average_time = total_time / n_graphs
        # Agregar el tiempo promedio a la lista.
        times.append(average_time)
    # Retornar la lista de tiempos.
    return times



# Función: dist_matrix
# Autores: [Nombres de los autores]
# Descripción: Genera una matriz de distancias aleatorias entre nodos.
# Parámetros de entrada:
# - n_nodes: Número de nodos en el grafo.
# - w_max: Valor máximo para las distancias (por defecto, 10).
# Parámetros de salida:
# - m: Matriz de distancias entre nodos.
def dist_matrix(n_nodes: int, w_max=10) -> np.ndarray:
    # Generar matriz de distancias aleatorias.
    m = np.random.randint(1, w_max + 1, (n_nodes, n_nodes))
    m = (m + m.T) // 2  # Hacer la matriz simétrica.
    np.fill_diagonal(m, 0)  # Establecer distancias diagonales como cero.
    # Retornar la matriz de distancias.
    return m

# Función: greedy_tsp
# Autores: [Nombres de los autores]
# Descripción: Implementa el algoritmo Greedy para el Problema del Viajante.
# Parámetros de entrada:
# - dist_m: Matriz de distancias entre nodos.
# - node_ini: Nodo de inicio para el circuito (por defecto, 0).
# Parámetros de salida:
# - circuit: Circuito resultante del algoritmo.
def greedy_tsp(dist_m: np.ndarray, node_ini=0) -> List[int]:
    # Inicializar variables.
    num_cities = dist_m.shape[0]
    circuit = [node_ini]
    # Construir el circuito visitando el nodo más cercano en cada paso.
    while len(circuit) < num_cities:
        current_city = circuit[-1]
        options = np.argsort(dist_m[current_city])
        for city in options:
            if city not in circuit:
                circuit.append(city)
                break
    # Agregar el nodo inicial al final para cerrar el circuito.
    return circuit + [node_ini]



# Función: len_circuit
# Autores: [Nombres de los autores]
# Descripción: Calcula la longitud total de un circuito dado.
# Parámetros de entrada:
# - circuit: Circuito para calcular la longitud.
# - dist_m: Matriz de distancias entre nodos.
# Parámetros de salida:
# - length: Longitud total del circuito.
def len_circuit(circuit: List[int], dist_m: np.ndarray) -> int:
    # Inicializar variables.
    length = 0
    n_inicio = 0
    n_fin = 0
    # Calcular la longitud sumando las distancias entre nodos consecutivos.
    for i in range(len(circuit) - 1):
        n_inicio = circuit[i]
        n_fin = circuit[i + 1]
        length += dist_m[n_inicio][n_fin]
    # Retornar la longitud total del circuito.
    return length

# Función: repeated_greedy_tsp
# Autores: [Nombres de los autores]
# Descripción: Aplica el algoritmo Greedy TSP repetidamente para encontrar el circuito más corto.
# Parámetros de entrada:
# - dist_m: Matriz de distancias entre nodos.
# Parámetros de salida:
# - least_circuit: Circuito más corto encontrado.
def repeated_greedy_tsp(dist_m: np.ndarray) -> List[int]:
    # Inicializar variables.
    num_cities = dist_m.shape[0]
    least_len = np.inf
    least_circuit = []
    # Aplicar Greedy TSP desde cada nodo como punto de inicio.
    for i in range(num_cities):
        circuit = greedy_tsp(dist_m, i)
        actual_len = len_circuit(circuit, dist_m)
        # Actualizar el circuito más corto si es necesario.
        if actual_len < least_len:
            least_len = actual_len
            least_circuit = circuit
    # Retornar el circuito más corto encontrado.
    return least_circuit

# Función: exhaustive_tsp
# Autores: [Nombres de los autores]
# Descripción: Implementa la búsqueda exhaustiva para el Problema del Viajante.
# Parámetros de entrada:
# - dist_m: Matriz de distancias entre nodos.
# Parámetros de salida:
# - least_circuit: Circuito más corto encontrado.
def exhaustive_tsp(dist_m: np.ndarray) -> List[int]:
    # Inicializar variables.
    least_circuit = []
    circuit = list(range(dist_m.shape[0]))
    least_length = np.inf
    # Generar todas las permutaciones posibles para encontrar el circuito más corto.
    circuit_list = permutations(circuit)
    for i in circuit_list:
        i = list(i)
        i.append(i[0])  # Agregar el primer nodo al final para cerrar el circuito.
        actual_length = len_circuit(i, dist_m)
        # Actualizar el circuito más corto si es necesario.
        if actual_length < least_length:
            least_length = actual_length
            least_circuit = list(i)
    # Retornar el circuito más corto encontrado.
    return least_circuit
