import numpy as np
import itertools as it

def dist_matrix(n_nodes: int, w_max=10) -> np.ndarray: 
    
    m = np.random.randint(1, w_max+1, (n_nodes, n_nodes))
    m = (m + m.T) // 2
    np.fill_diagonal(m, 0)
    
    return m

def greedy_tsp(dist_m: np.ndarray, node_ini=0) -> list:
    
    num_cities = dist_m.shape[0]
    circuit = [node_ini]
    
    while len(circuit) < num_cities:
        current_city = circuit[-1]
        
    # sort cities in ascending distance from current
        options = np.argsort(dist_m[ current_city ])
        
    # add first city in sorted list not visited yet
        for city in options:
            if city not in circuit:
                circuit.append(city)
                break
            
    return circuit + [node_ini]

def len_circuit(circuit: list, dist_m: np.ndarray)-> int:
    length = 0
    n_inicio = 0
    n_fin = 0
    
    for i in range(len(circuit)-1):
        n_inicio = circuit[i]
        n_fin = circuit[i+1]
        
        length += dist_m[n_inicio][n_fin]
    
    return length


def exhaustive_tsp(dist_m: np.ndarray)-> list:
    
    least_circuit =[]
    circuit = list(range(dist_m.shape[0]))
    print(circuit)
    
    actual_lenght = 0
    least_lenght = np.inf
    
    circuit_list = it.permutations(circuit)
    
    for perm in circuit_list:
        print(perm)
    
    for i in circuit_list:
        i = list(i)
        i.append(i[0])
    
        actual_lenght = len_circuit(i, dist_m)
        
        if actual_lenght < least_lenght:
            least_lenght = actual_lenght
            least_circuit = list(i)
      
    return least_circuit
             
matrix = np.array([[0, 1, 2, 1],[1, 0, 1, 2],[2, 1, 0, 1],[1, 2, 1, 0]])

print(matrix)

l_v = exhaustive_tsp(matrix)

print(l_v)

len = len_circuit(l_v, matrix)

print(len)