import numpy as np

def find(ind: int, p_cd: np.ndarray)-> int:

    z = ind
   
    while p_cd[z] >= 0:
        z = p_cd[z]

    while p_cd[ind] >= 0:
        y = p_cd[ind]
        p_cd[ind] = z
        ind = y
    return z