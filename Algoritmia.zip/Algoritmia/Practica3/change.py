import numpy as np
from typing import List

def change(c: int, l_coins: list) -> dict:

    d_change = {}
    for coin in sorted(l_coins)[ : : -1]:
        d_change[ coin ] = c // coin
        c = c % coin
    return d_change


def change_pd(c: int, l_coins: List[int]) -> np.ndarray:
    n = len(l_coins)
    # Creamos una matriz para almacenar los resultados intermedios
    dp = np.zeros((n + 1, c + 1), dtype=int)

    # Inicializamos la primera fila con infinito, ya que no se puede hacer cambio para cero con monedas
    dp[0, 1:] = float('inf')

    for i in range(1, n + 1):
        for j in range(1, c + 1):
            # Si la moneda actual es mayor que el cambio requerido, no la incluimos
            if l_coins[i - 1] > j:
                dp[i, j] = dp[i - 1, j]
            else:
                # Tomamos el mínimo entre no incluir la moneda y usar la moneda actual
                dp[i, j] = min(dp[i - 1, j], 1 + dp[i, j - l_coins[i - 1]])

    return dp

# Ejemplo de uso:
cantidad = 11
monedas = [1, 2, 5]
resultado = change_pd(cantidad, monedas)
print("Matriz generada por el algoritmo de programación dinámica:")
print(resultado)

from typing import List, Dict
from collections import OrderedDict
import numpy as np

def optimal_change_pd(c: int, l_coins: List[int]) -> Dict:
    n = len(l_coins)
    dp = np.zeros((n + 1, c + 1), dtype=int)

    # Llenar la matriz utilizando programación dinámica (como en la función anterior)
    for i in range(1, n + 1):
        for j in range(1, c + 1):
            if l_coins[i - 1] > j:
                dp[i, j] = dp[i - 1, j]
            else:
                dp[i, j] = min(dp[i - 1, j], 1 + dp[i, j - l_coins[i - 1]])

    # Inicializar el diccionario para almacenar el cambio óptimo
    optimal_change = {}

    # Backtracking para encontrar las monedas utilizadas
    i, j = n, c
    while i > 0 and j > 0:
        if dp[i, j] == dp[i - 1, j]:
            # No se está utilizando la moneda actual
            i -= 1
        else:
            # Se está utilizando la moneda actual
            coin_value = l_coins[i - 1]
            optimal_change[coin_value] = optimal_change.get(coin_value, 0) + 1
            j -= coin_value

    # Ordenar el diccionario por sus claves
    optimal_change = dict(OrderedDict(sorted(optimal_change.items())))

    return optimal_change

# Ejemplo de uso:
cantidad = 11
monedas = [1, 2, 5]
resultado = optimal_change_pd(cantidad, monedas)
print("Cambio óptimo:")
print(resultado)
