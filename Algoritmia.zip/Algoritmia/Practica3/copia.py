import numpy as np
from typing import Union
from typing import List, Dict
from collections import OrderedDict


def split(t: np.ndarray) -> tuple[np.ndarray, int, np.ndarray]:
    """
    Divide el array 't' en dos subarrays y devuelve una tupla con el subarray izquierdo, 
    el elemento del medio y el subarray derecho.

    Parameters:
    - t (np.ndarray): Array a dividir.

    Returns:
    tuple[np.ndarray, int, np.ndarray]: Tupla con el subarray izquierdo, el elemento medio y el subarray derecho.
    """

    mid = t[0]
    t_l = [u for u in t if u < mid]
    t_r = [u for u in t if u > mid]
    return t_l, mid, t_r

def qsel(t: np.ndarray, k: int) -> Union[int, None]:
    """
    Implementación del algoritmo QuickSelect para encontrar el k-ésimo elemento más pequeño en un array.

    Parameters:
    - t (np.ndarray): Array de entrada.
    - k (int): Índice del elemento que se desea encontrar.

    Returns:
    Union[int, None]: El k-ésimo elemento más pequeño o None si k está fuera de rango.
    """

    if k < 0 or k >= len(t):
        return None

    if len(t) == 1 and k == 0:
        return t[0]

    t_l, mid, t_r = split(t)
    m = len(t_l)

    if k == m:
        return mid
    elif k < m:
        return qsel(t_l, k)
    elif k > m:
        return qsel(t_r, k - m - 1)
    else:
        return None

def qsel_nr(t: np.ndarray, k: int) -> Union[int, None]:
    """
    Versión no recursiva del algoritmo QuickSelect.

    Parameters:
    - t (np.ndarray): Array de entrada.
    - k (int): Índice del elemento que se desea encontrar.

    Returns:
    Union[int, None]: El k-ésimo elemento más pequeño o None si k está fuera de rango.
    """

    if len(t) == 1 and k == 0:
        return t[0]

    while len(t) > 0:

        t_l, mid, t_r = split(t)
        m = len(t_l)

        if k == m:
            return mid

        if k < m:
            t = t_l

        elif k > m:
            k = k - m - 1
            t = t_r
        else:
            return None

    return mid

def split_pivot(t: np.ndarray, mid: int) -> tuple[np.ndarray, int, np.ndarray]:
    """
    Divide el array 't' en dos subarrays usando un valor 'mid' como pivote.

    Parameters:
    - t (np.ndarray): Array a dividir.
    - mid (int): Valor pivote.

    Returns:
    tuple[np.ndarray, int, np.ndarray]: Tupla con el subarray izquierdo, el elemento medio y el subarray derecho.
    """

    t_l = [u for u in t if u < mid]
    t_r = [u for u in t if u > mid]
    return t_l, mid, t_r

def pivot5(t: np.ndarray) -> int:
    """
    Selecciona un pivote para el algoritmo QuickSelect usando el método de la mediana de medianas.

    Parameters:
    - t (np.ndarray): Array de entrada.

    Returns:
    int: Pivote seleccionado.
    """

    tam = len(t)

    if(tam < 5):
        if len(t) == 0:
            return None
        else:
            return int(np.median(t))

    grupos_5 = [t[i:i+5] for i in range(0, tam, 5)]
    medianas = [int(np.median(grupo_5)) for grupo_5 in grupos_5]

    if None in medianas:
        return int(np.median(medianas))
    else:
        return qsel5_nr(medianas, len(medianas) // 2)

def qsel5_nr(t: np.ndarray, k: int) -> Union[int, None]:
    """
    Versión no recursiva del algoritmo QuickSelect que utiliza el método de la mediana de medianas para seleccionar el pivote.

    Parameters:
    - t (np.ndarray): Array de entrada.
    - k (int): Índice del elemento que se desea encontrar.

    Returns:
    Union[int, None]: El k-ésimo elemento más pequeño o None si k está fuera de rango.
    """

    while True:
        m = pivot5(t)
        t_l, mid, t_r = split_pivot(t, m)

        if k < len(t_l):
            t = t_l
        elif k > len(t_l):
            k = k - len(t_l) - 1
            t = t_r 
        elif k == len(t_l):
            return mid

def qsort_5(t: np.ndarray) -> np.ndarray:
    """
    Implementación del algoritmo QuickSort que utiliza el método de la mediana de medianas para seleccionar el pivote.

    Parameters:
    - t (np.ndarray): Array a ordenar.

    Returns:
    np.ndarray: Array ordenado.
    """

    if len(t) <= 1:
        return t

    if len(t) == 2:
        if t[0] <= t[1]:
            m = t[0]
        else:
            m = t[1]
    else:
        m = int(pivot5(t))

    t_l, _, t_r = split_pivot(t, m)

    tizq_ordenada = qsort_5(t_l)
    tdre_ordenada = qsort_5(t_r)

    return np.concatenate([tizq_ordenada, np.array([int(m)]), tdre_ordenada]).astype(int)

def change_pd(c: int, l_coins: list[int]) -> np.array:
    """
    Implementación de un algoritmo de cambio de monedas utilizando programación dinámica.

    Parameters:
    - c (int): Monto de cambio a devolver.
    - l_coins (list[int]): Lista de denominaciones de monedas disponibles.

    Returns:
    np.array: Array que representa el cambio óptimo a devolver.
    """

    dp = np.full((len(l_coins) + 1, c + 1), fill_value=np.inf, dtype=float)
    dp[0, 0] = 0

    for i in range(1, len(l_coins)+1):
        coin = l_coins[i-1]
        for j in range(c+1):
            dp[i, j] = dp[i - 1, j] 
            if j >= coin:
                dp[i, j] = min(dp[i, j], 1 + dp[i, j - coin])
            elif i == 1 and j == coin:
                dp[i, j] = 1

    return dp

def optimal_change_pd(c: int, l_coins: list[int]) -> Dict:
    """
    Encuentra la combinación óptima de monedas para un cambio utilizando programación dinámica.

    Parameters:
    - c (int): Monto de cambio a devolver.
    - l_coins (list[int]): Lista de denominaciones de monedas disponibles.

    Returns:
    Dict: Diccionario que representa la combinación óptima de monedas.
    """

    n = len(l_coins)

    dp = np.full((len(l_coins) + 1, c + 1), fill_value=np.inf, dtype=float)
    dp[0, 0] = 0

    for i in range(1, len(l_coins)+1):
        coin = l_coins[i-1]
        for j in range(c+1):
            dp[i, j] = dp[i - 1, j] 
            if j >= coin:
                dp[i, j] = min(dp[i, j], 1 + dp[i, j - coin])
            elif i == 1 and j == coin:
                dp[i, j] = 1

    optimal_change = OrderedDict()

    i, j = n, c
    while i > 0 and j > 0:
        if dp[i, j] != dp[i - 1, j]:
            if l_coins[i - 1] not in optimal_change:
                optimal_change[l_coins[i - 1]] = 0
            optimal_change[l_coins[i - 1]] += 1
            j -= l_coins[i - 1]
        else:
            i -= 1

    for coin in l_coins:
        if coin not in optimal_change:
            optimal_change[coin] = 0

    return optimal_change

def knapsack_fract_greedy(l_weights: List[int], l_values: List[int], bound: int) -> dict:
    """
    Resuelve el problema de la mochila fraccionaria utilizando un algoritmo greedy.

    Parameters:
    - l_weights (List[int]): Lista de pesos de los elementos.
    - l_values (List[int]): Lista de valores de los elementos.
    - bound (int): Peso máximo que la mochila puede llevar.

    Returns:
    dict: Diccionario que representa la cantidad de cada elemento incluido en la mochila.
    """

    n = len(l_weights)
    peso = bound 

    v_w = [(i, l_values[i] / l_weights[i]) for i in range(n)]

    v_w.sort(key=lambda x: x[1], reverse=True)

    w_dict = {}

    for i, ratio in v_w:
        if peso > 0:
            if l_weights[i] <= peso:
                w_dict[i] = l_weights[i]
                peso -= l_weights[i]
            else:
                w_dict[i] = peso
                peso = 0
        else:
            w_dict[i] = peso

    return w_dict

def knapsack_01_pd(l_weights: List[int], l_values: List[int], bound: int) -> int:
    """
    Resuelve el problema de la mochila 0-1 utilizando programación dinámica.

    Parameters:
    - l_weights (List[int]): Lista de pesos de los elementos.
    - l_values (List[int]): Lista de valores de los elementos.
    - bound (int): Peso máximo que la mochila puede llevar.

    Returns:
    int: Valor máximo que se puede obtener en la mochila.
    """

    n = len(l_weights)

    dp = [[0] * (bound + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(bound + 1):
            if l_weights[i - 1] <= w:
                dp[i][w] = max(dp[i - 1][w], l_values[i - 1] + dp[i - 1][w - l_weights[i - 1]])
            else:
                dp[i][w] = dp[i - 1][w]

    return dp[n][bound]