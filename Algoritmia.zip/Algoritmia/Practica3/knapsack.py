from typing import List, Dict

def knapsack_fract_greedy(l_weights: List[int], l_values: List[int], bound: int) -> dict:
    
    n = len(l_weights)
    peso = bound 

    v_w = [(i, l_values[i] / l_weights[i]) for i in range(n)]
    
    v_w.sort(key=lambda x: x[1], reverse=True)
    
    w_dict = {}
    
    for i, ratio in v_w:
        if peso>0:
            if l_weights[i] <= peso:
                w_dict[i] = l_weights[i]
                peso -= l_weights[i]
            
            else:
                w_dict[i] = peso
                peso = 0
        else:
            w_dict[i] = peso
            
    return w_dict


def knapsack_fract_greedy_optValue(l_weights: List[int], l_values: List[int], bound: int) -> int:
    
    n = len(l_weights)
    peso = bound
    valor_optimo = 0
    flag = 0
    
    l_weights = list(map(float, l_weights))
    l_values = list(map(float, l_values))

    v_w = [(i, l_values[i] / l_weights[i]) for i in range(n)]
    
    v_w.sort(key=lambda x: x[1], reverse=True)
    
    w_dict = {}
    
    for i, ratio in v_w:
        if flag == 0:

            if l_weights[i] <= peso:
                w_dict[i] = 1 
                peso -= l_weights[i]
            
            else:
                w_dict[i] = peso/l_weights[i]
                peso = 0
                flag = 1  
        else:
            w_dict[i] = peso
    
    for i, ratio in w_dict.items():
       
        valor_optimo = valor_optimo + l_values[i]*ratio
    
            
    return valor_optimo
    
l_weights = [4, 4, 5]
l_values = [10, 11, 15]
capacity = 4
"""""
weights = [4, 3, 5, 2]
values = [10, 40, 30, 20]
capacity = 8
"""
result = knapsack_fract_greedy(l_weights, l_values, capacity)
print("Resultado greedy : ")
print(result)

result = knapsack_fract_greedy_optValue(l_weights, l_values, capacity)

print("Resultado greedy valor optimo: ")
print(result)

def knapsack_01_pd(l_weights: List[int], l_values: List[int], bound: int)-> int:
    
    n = len(l_weights)
    peso = bound
    flag = 0
    valor_optimo = 0
    
    v_w = [(i, l_values[i] / l_weights[i]) for i in range(n)]
  
    v_w.sort(key=lambda x: x[1], reverse=True)
    
    w_dict = {}
   
    for i, ratio in v_w:
        
        if flag == 0:
        
            if l_weights[i] <= peso:
                w_dict[i] = l_weights[i]  
                peso -= l_weights[i]
            else:
                w_dict[i] = 0
                flag = 1
        else:
            w_dict[i] = 0
        
    
    for i, ratio in w_dict.items():
        if ratio == l_weights[i]:
            valor_optimo = valor_optimo + l_values[i]
    
            
    return valor_optimo

weights = [4, 3, 5, 2]
values = [10, 40, 30, 20]
capacity = 8

result = knapsack_01_pd(weights, values, capacity)
print("Resultado pd: ")
print(result)

    
    
    
