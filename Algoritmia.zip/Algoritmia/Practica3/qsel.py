import numpy as np
from typing import Union

def split(t: np.ndarray)-> tuple[np.ndarray, int, np.ndarray]:
    
    mid = t[0]
    t_l = [u for u in t if u < mid]
    t_r = [u for u in t if u > mid]
    return t_l, mid, t_r

def qsel(t: np.ndarray, k: int)-> Union[int, None]:
    
    if len(t) == 1 and k == 0:
        return t[0]
    
    t_l, mid, t_r = split(t)
    m = len(t_l)
    
    if k == m:
        return mid
    elif k < m:
        return qsel(t_l, k)
    elif k>m:
        return qsel(t_r, k-m-1)
    else:
        return None
    
def qsel_nr(t: np.ndarray, k: int)-> Union[int, None]:
    
    if len(t) == 1 and k == 0:
        return t[0]
    
    while len(t)>0:
        
        t_l, mid, t_r = split(t)
        m = len(t_l)
        
        if k == m:
            return mid
    
        if k < m:
            t = t_l
      
        elif k>m:
            k = k-m-1
            t = t_r
        else:
            return None
    
    return mid

t = np.array([3,1,4,5,9,2,6,10,12,11]) 
print("Array original: ",t)
print("Array Ordenado: ", np.sort(t))
k_value = 8
print("Indice: ",k_value)


result_original = qsel(t, k_value)
print(f"Resultado usando qsel: {result_original}")


result_nr = qsel_nr(t, k_value)
print(f"Resultado usando qsel_nr: {result_nr}")


            
        
    
        