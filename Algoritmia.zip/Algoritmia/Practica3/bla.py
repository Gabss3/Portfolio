from typing import List

def knapsack_01_pd(l_weights: List[int], l_values: List[int], bound: int) -> int:
   
    n = len(l_weights)

    dp = [[0] * (bound + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(bound + 1):
            if l_weights[i - 1] <= w:
                dp[i][w] = max(dp[i - 1][w], l_values[i - 1] + dp[i - 1][w - l_weights[i - 1]])
            else:
                dp[i][w] = dp[i - 1][w]

    return dp[n][bound]

weights = [4, 4, 5]
values = [10, 11, 15]
capacity = 4

valor_optimo = knapsack_01_pd(weights, values, capacity)
print("Valor óptimo de la mochila 0-1:", valor_optimo)


