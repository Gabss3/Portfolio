import numpy as np
from typing import Union

def split_pivot(t: np.ndarray, mid: int)-> tuple[np.ndarray, int, np.ndarray]:

    t_l = [u for u in t if u < mid]
    t_r = [u for u in t if u > mid]
    return t_l, mid, t_r

def pivot5(t: np.ndarray)-> int:
    
    tam = len(t)
    
    if(tam<5):
        if len(t) == 0:
            return None
        else:
            return int(np.median(t))
    
    grupos_5 = [t[i:i+5] for i in range(0, tam, 5)]
    
    medianas = [int(np.median(grupo_5)) for grupo_5 in grupos_5]
    
    if None in medianas:
        return int(np.median(medianas))
    else:
        return  qsel5_nr(medianas, len(medianas) // 2)

def qsel5_nr(t: np.ndarray, k: int)-> Union[int, None]:
      
    while(True):
   
        m = pivot5(t)
    
    
        t_l, mid, t_r = split_pivot(t, m)
        
        if k< len(t_l):
            t = t_l
        
        elif k > len(t_l):
            k = k- len(t_l) - 1
            t = t_r 
        
        elif k == len(t_l):
            return mid   

t = np.array([8, 9, 10, 1, 6, 3, 7, 0, 4, 5, 2])
resultado = qsel5_nr(t, 6)
print("Elemento en la posicion k=6: ", resultado)
        
def qsort_5(t: np.ndarray)-> np.ndarray:
    
    if len(t) <= 1:
        return t
    
    if len(t) ==2:
        if t[0] <= t[1]:
            m = t[0]
        else:
            m = t[1]
    
    else:
        m = int(pivot5(t))
    
    t_l, _, t_r = split_pivot(t, m)
    
    tizq_ordenada = qsort_5(t_l)
    tdre_ordenada = qsort_5(t_r)
    
    return np.concatenate([tizq_ordenada, np.array([int(m)]), tdre_ordenada]).astype(int)

t = np.array([5, 3, 8, 2, 7, 1])
k_value = 2
result = qsel5_nr(t, k_value)
print(f"Elemento en el índice {k_value} de la ordenación: {result}")


t = np.array([5, 3, 8, 2, 7, 1])
sorted_array = qsort_5(t)
print("Array original:", t)
print("Array ordenado:", sorted_array)

                
        
        
    
            
