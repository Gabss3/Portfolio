import numpy as np
from typing import Tuple

# Función: insert_min_heap
# Autores: [Nombre de los autores]
# Descripción: Inserta un elemento en un min-heap representado por un array NumPy y ajusta el heap para mantener la propiedad de min-heap.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# - k: valor a insertar en el min-heap.
# Parámetros de salida: Retorna el array NumPy modificado después de insertar el elemento.

def insert_min_heap(h: np.ndarray, k: int) -> np.ndarray:
    # Añadir el nuevo elemento al final del array
    h = np.append(h, k)
    i = len(h) - 1
    
    # Bucle para ajustar el min-heap después de la inserción
    while i > 0:
        # Comparar el elemento actual con su padre
        if h[i] < h[(i - 1) // 2]:
            # Intercambiar valores si el elemento es menor que su padre
            aux = h[i]
            h[i] = h[(i - 1) // 2]
            h[(i - 1) // 2] = aux
            i = (i - 1) // 2
        else:
            # Romper el bucle si el elemento es mayor o igual que su padre
            break
    
    # Retornar el array modificado
    return h
  

def pq_ini():
  return np.empty (shape=0)

def pq_insert(h: np.ndarray, k: int)-> np.ndarray:
    
    p_queue = insert_min_heap(h, k)
    
    return p_queue
  
  
# Ejemplo de Uso:

# Crear un array NumPy vacío para representar la cola de prioridad (min-heap)
priority_queue = pq_ini()

# Insertar elementos en la cola de prioridad utilizando pq_insert
priority_queue = pq_insert(priority_queue, 5)
priority_queue = pq_insert(priority_queue, 3)
priority_queue = pq_insert(priority_queue, 8)
priority_queue = pq_insert(priority_queue, 1)

# Resultado esperado:
# El array priority_queue debería representar un min-heap después de las inserciones.

print("Cola de Prioridad (Min-Heap):", priority_queue)

  
