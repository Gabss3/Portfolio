import numpy as np

# Función: min_heapify
# Autores: [Nombre de los autores]
# Descripción: Implementa el algoritmo de min-heapify en un min-heap representado por un array NumPy.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# - i: índice del nodo que se ajustará para mantener la propiedad de min-heap.
# Parámetros de salida: Realiza cambios en el array 'h' para mantener la propiedad de min-heap.
def min_heapify(h:np.ndarray, i: int):
  
  # Bucle principal
  while 2*i+1 < len(h):
    # Inicialización de 'next_i' con el valor actual de 'i' 
    next_i = i
    
    # Comparación con el hijo izquierdo
    if h[next_i] > h[2*i+1]:
      next_i = 2*i+1
    
    # Verificación del hijo derecho y comparación
    if 2*i+2 < len(h) and h[next_i] > h[2*i+2]:
      next_i = 2*i+2
    
    # Ajuste de posición si se encontró un hijo con un valor menor
    if next_i > i:
      h[i], h[next_i] = h[next_i], h[i]
      i = next_i
    
    # Retorno si no se realizó ningún intercambio
    elif i == next_i:
      return
    


min_heap = [50,30,20,15,10,8,16]

min_heapify(min_heap, 0)

print(min_heap)
                 