import numpy as np

def matrix_multiplication(m_1, m_2):

    n_rows, n_interm, n_columns = m_1.shape[0], m_2.shape[0], m_2.shape[1]
    
    m_product = np.zeros( (n_rows, n_columns) )
    
    for p in range(n_rows):
        for q in range(n_columns):
            for r in range(n_interm):
                m_product[p, q] += m_1[p, r] * m_2[r, q]
    return m_product


m_1 = np.array([[3,4], [1,2], [0,3]])

m_2 = np.array([[2,0], [1,4]])

m_3 = matrix_multiplication(m_1, m_2)


print(f"Matriz 1:\n {m_1}")
print(f"Matriz 2:\n {m_2}")
print(f"Producto de la matriz 1 y 2:\n {m_3}")


    