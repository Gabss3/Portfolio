import numpy as np
from typing import Tuple

def matrix_multiplication(m_1 : np.ndarray, m_2: np.ndarray) -> np.ndarray:

    n_rows, n_interm, n_columns = m_1.shape[0], m_2.shape[0], m_2.shape[1]
    
    m_product = np.zeros( (n_rows, n_columns) )
    
    for p in range(n_rows):
        for q in range(n_columns):
            for r in range(n_interm):
                m_product[p, q] += m_1[p, r] * m_2[r, q]
    return m_product

def  rec_bb(t: list, f: int, l: int, key: int) -> int: 
 
    while f <= l:
        res = (f +l)/2
        res = int(res)
        
        if t[res] == key:
            return res
        elif t[res] < key:
            f = res +1
            return rec_bb(t, f, l, key)
        elif t[res] > key:
            l = res -1
            return rec_bb(t, f, l, key)
    
    return None

def bb(t: list, first: int, last: int, key: int)-> int:

  while first <= last:
    
    res = (first + last)/2
    res = int(res)
    
    if t[res] == key:
      return res
    
    elif t[res] < key:
      first = res+1
    
    elif t[res] > key:
      last = res-1

  return None

# Función: min_heapify
# Autores: [Nombre de los autores]
# Descripción: Implementa el algoritmo de min-heapify en un min-heap representado por un array NumPy.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# - i: índice del nodo que se ajustará para mantener la propiedad de min-heap.
# Parámetros de salida: Realiza cambios en el array 'h' para mantener la propiedad de min-heap.
def min_heapify(h:np.ndarray, i: int):
  
  # Bucle principal
  while 2*i+1 < len(h):
    # Inicialización de 'next_i' con el valor actual de 'i' 
    next_i = i
    
    # Comparación con el hijo izquierdo
    if h[next_i] > h[2*i+1]:
      next_i = 2*i+1
    
    # Verificación del hijo derecho y comparación
    if 2*i+2 < len(h) and h[next_i] > h[2*i+2]:
      next_i = 2*i+2
    
    # Ajuste de posición si se encontró un hijo con un valor menor
    if next_i > i:
      h[i], h[next_i] = h[next_i], h[i]
      i = next_i
    
    # Retorno si no se realizó ningún intercambio
    elif i == next_i:
      return
    

# Función: insert_min_heap
# Autores: [Nombre de los autores]
# Descripción: Inserta un elemento en un min-heap representado por un array NumPy y ajusta el heap para mantener la propiedad de min-heap.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# - k: valor a insertar en el min-heap.
# Parámetros de salida: Retorna el array NumPy modificado después de insertar el elemento.

def insert_min_heap(h: np.ndarray, k: int) -> np.ndarray:
    # Añadir el nuevo elemento al final del array
    h +=[k]
    i = len(h) - 1
    
    # Bucle para ajustar el min-heap después de la inserción
    while i > 0:
        # Comparar el elemento actual con su padre
        if h[i] < h[(i - 1) // 2]:
            # Intercambiar valores si el elemento es menor que su padre
            aux = h[i]
            h[i] = h[(i - 1) // 2]
            h[(i - 1) // 2] = aux
            i = (i - 1) // 2
        else:
            # Romper el bucle si el elemento es mayor o igual que su padre
            break
    
    # Retornar el array modificado
    return h


# Función: create_min_heap
# Autores: [Nombre de los autores]
# Descripción: Crea un min-heap a partir de un array NumPy ajustando los elementos para cumplir con la propiedad de min-heap.
# Parámetros de entrada:
# - h: array NumPy que representa el heap.
# Parámetros de salida: Modifica el array NumPy para convertirlo en un min-heap.

def create_min_heap(h: np.ndarray):
    # Inicializar la variable de control j
    j = 1
    
    # Bucle externo para repetir el proceso de creación del min-heap
    while j < len(h):
        # Inicializar el índice i en la última posición del array
        i = len(h) - 1
        
        # Bucle interno para ajustar el min-heap
        while i > 0:
            # Comparar el elemento actual con su padre
            if h[i] < h[(i - 1) // 2]:
                # Intercambiar valores si el elemento es menor que su padre
                aux = h[i]
                h[i] = h[(i - 1) // 2]
                h[(i - 1) // 2] = aux
                i = (i - 1) // 2
            else:
                # Decrementar el índice si el elemento es mayor o igual que su padre
                i = i - 1
        
        # Incrementar la variable de control j
        j += 1

    
def pq_ini():
  return np.empty (shape=0)

def pq_insert(h: np.ndarray, k: int)-> np.ndarray:
    
    p_queue = insert_min_heap(h, k)
    
    return p_queue

# Función: pq_remove
# Autores: [Nombre de los autores]
# Descripción: Elimina y devuelve el elemento mínimo de un min-heap representado por un array NumPy.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# Parámetros de salida: Devuelve una tupla que contiene el elemento mínimo y el array actualizado.

def pq_remove(h: np.ndarray) -> tuple[int, np.ndarray]:
    # Almacenar el elemento mínimo antes de la eliminación
    elem = h[0]
    
    # Reemplazar el primer elemento con el último
    h[0] = h[len(h) - 1]
    
    # Eliminar el último elemento del array
    h = h[:-1]

    # Restaurar la propiedad de min-heap mediante la función min_heapify
    min_heapify(h, 0)
    
    # Devolver el elemento mínimo y el array actualizado en una tupla
    return elem, h


# Función: min_heap_sort
# Autores: [Nombre de los autores]
# Descripción: Ordena un array NumPy utilizando el algoritmo de min-heap sort.
# Parámetros de entrada:
# - h: array NumPy que se desea ordenar utilizando min-heap sort.
# Parámetros de salida: Devuelve un array NumPy ordenado.

def min_heap_sort(h: np.ndarray) -> np.ndarray:
    # Inicializar un array para almacenar los elementos ordenados
    sorted_array = np.array([])

    # Longitud inicial del array
    l = len(h)

    # Crear un min-heap a partir del array original
    create_min_heap(h)

    # Extraer y agregar elementos al array ordenado hasta que el heap esté vacío
    while l > 0:
        # Obtener y eliminar el elemento mínimo del heap
        min_elem, h = pq_remove(h)

        # Agregar el elemento mínimo al array ordenado
        sorted_array = np.append(sorted_array, min_elem)

        # Decrementar la longitud del heap
        l = l - 1

    # Devolver el array NumPy ordenado
    return sorted_array


    

