def bb(t: list, first: int, last: int, key: int):

  while first < last:
    
    res = (first + last)/2
    res = int(res)
    
    if t[res] == key:
      return res
    
    elif t[res] < key:
      first = res+1
    
    elif t[res] > key:
      last = res-1

  return None
lista = [3, 5, 6, 8, 10, 15, 21]

indice = bb(lista, 0, 6, 5)

print(indice)  
