def  rec_bb(t: list, f: int, l: int, key: int):
 
    while f < l:
        res = (f +l)/2
        res = int(res)
        
        if t[res] == key:
            return res
        elif t[res] < key:
            f = res +1
            return rec_bb(t, f, l, key)
        elif t[res] > key:
            l = res -1
            return rec_bb(t, f, l, key)
    
    return None

lista = [3, 5, 6, 8, 10, 15, 21]

indice = rec_bb(lista, 0, 6, 5)

print(indice)       
        
    
        
            
    