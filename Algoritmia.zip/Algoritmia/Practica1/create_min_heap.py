import numpy as np

# Función: create_min_heap
# Autores: [Nombre de los autores]
# Descripción: Crea un min-heap a partir de un array NumPy ajustando los elementos para cumplir con la propiedad de min-heap.
# Parámetros de entrada:
# - h: array NumPy que representa el heap.
# Parámetros de salida: Modifica el array NumPy para convertirlo en un min-heap.

def create_min_heap(h: np.ndarray):
    # Inicializar la variable de control j
    j = 1
    
    # Bucle externo para repetir el proceso de creación del min-heap
    while j < len(h):
        # Inicializar el índice i en la última posición del array
        i = len(h) - 1
        
        # Bucle interno para ajustar el min-heap
        while i > 0:
            # Comparar el elemento actual con su padre
            if h[i] < h[(i - 1) // 2]:
                # Intercambiar valores si el elemento es menor que su padre
                aux = h[i]
                h[i] = h[(i - 1) // 2]
                h[(i - 1) // 2] = aux
                i = (i - 1) // 2
            else:
                # Decrementar el índice si el elemento es mayor o igual que su padre
                i = i - 1
        
        # Incrementar la variable de control j
        j += 1


min_heap = [16, 30, 20, 15, 10, 8]

create_min_heap(min_heap)

print(min_heap)