import numpy as np

# Función: min_heapify
# Autores: [Nombre de los autores]
# Descripción: Implementa el algoritmo de min-heapify en un min-heap representado por un array NumPy.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# - i: índice del nodo que se ajustará para mantener la propiedad de min-heap.
# Parámetros de salida: Realiza cambios en el array 'h' para mantener la propiedad de min-heap.
def min_heapify(h:np.ndarray, i: int):
  
  # Bucle principal
  while 2*i+1 < len(h):
    # Inicialización de 'next_i' con el valor actual de 'i' 
    next_i = i
    
    # Comparación con el hijo izquierdo
    if h[next_i] > h[2*i+1]:
      next_i = 2*i+1
    
    # Verificación del hijo derecho y comparación
    if 2*i+2 < len(h) and h[next_i] > h[2*i+2]:
      next_i = 2*i+2
    
    # Ajuste de posición si se encontró un hijo con un valor menor
    if next_i > i:
      h[i], h[next_i] = h[next_i], h[i]
      i = next_i
    
    # Retorno si no se realizó ningún intercambio
    elif i == next_i:
      return

# Función: pq_remove
# Autores: [Nombre de los autores]
# Descripción: Elimina y devuelve el elemento mínimo de un min-heap representado por un array NumPy.
# Parámetros de entrada:
# - h: array NumPy que representa el min-heap.
# Parámetros de salida: Devuelve una tupla que contiene el elemento mínimo y el array actualizado.

def pq_remove(h: np.ndarray) -> tuple[int, np.ndarray]:
    # Almacenar el elemento mínimo antes de la eliminación
    elem = h[0]
    
    # Reemplazar el primer elemento con el último
    h[0] = h[len(h) - 1]
    
    # Eliminar el último elemento del array
    h = h[:-1]

    # Restaurar la propiedad de min-heap mediante la función min_heapify
    min_heapify(h, 0)
    
    # Devolver el elemento mínimo y el array actualizado en una tupla
    return elem, h

min_heap = [8, 11, 10, 16, 15, 30, 20]

tuple = pq_remove(min_heap)

print(min_heap)

print(tuple)
