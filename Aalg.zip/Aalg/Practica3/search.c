/**
 *
 * Description: Implementation of functions for search
 *
 * File: search.c
 * Author: Carlos Aguirre and Javier Sanz-Cruzado
 * Version: 1.0
 * Date: 14-11-2016
 *
 */

#include "search.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/**
 *  Key generation functions
 *
 *  Description: Receives the number of keys to generate in the n_keys
 *               parameter. The generated keys go from 1 to max. The
 * 				 keys are returned in the keys parameter which must be 
 *				 allocated externally to the function.
 */
  
/**
 *  Function: uniform_key_generator
 *               This function generates all keys from 1 to max in a sequential
 *               manner. If n_keys == max, each key will just be generated once.
 */
void uniform_key_generator(int *keys, int n_keys, int max){
  int i;

  for(i = 0; i < n_keys; i++) keys[i] = 1 + (i % max);

  return;
}

/**
 *  Function: potential_key_generator
 *               This function generates keys following an approximately
 *               potential distribution. The smaller values are much more 
 *               likely than the bigger ones. Value 1 has a 50%
 *               probability, value 2 a 17%, value 3 the 9%, etc.
 */
void potential_key_generator(int *keys, int n_keys, int max)
{
  int i;

  for(i = 0; i < n_keys; i++) 
  {
    keys[i] = .5+max/(1 + max*((double)rand()/(RAND_MAX)));
  }

  return;
}

PDICT init_dictionary (int size, char order){
  PDICT dic;
  int* tabla;

  if(size <0 || (order != 0 && order != 1)){
    return NULL;
  }

  dic = (DICT*)malloc(sizeof(DICT));
  if(!dic){
    return NULL;
  }

  dic->size = size;
  dic->order = order;

  tabla = (int*)malloc(size*sizeof(int));
  if(!tabla){
    free(dic);
    return NULL;
  }
  dic->table = tabla;
  dic->n_data = 0; 

  return dic;  
}

void free_dictionary(PDICT pdict){ 
  pdict->size = 0;
  pdict->order = 0;
  pdict->n_data = 0;
  pdict->table = NULL;
	free(pdict->table);
  free(pdict);
  return;
}

int insert_dictionary(PDICT pdict, int key){
  int a,j;

	if(!pdict || pdict->n_data == pdict->size){ 
    return ERR;
  }
  pdict->table[pdict->n_data] = key;
  
  if(pdict->order == SORTED){
    a=pdict->table[pdict->n_data]; 
    j=pdict->n_data-1;
    while (j >= 0 && pdict->table[j] > a){
      pdict->table[j+1]=pdict->table[j]; 
      j--;
    }
    pdict->table[j+1]=a;
  }
  pdict->n_data++;
  return OK;
}

int massive_insertion_dictionary (PDICT pdict,int *keys, int n_keys){ 
  int i=0,st=0;
	
  if(!pdict || !keys || n_keys < 0){
    return ERR;
  }
  for(i=0; i<n_keys; i++){
    st = insert_dictionary(pdict,keys[i]);
    if(st == ERR){
      printf("Falla en un insert individual");
      return ERR;
    }
  }
  return OK; 
}

int search_dictionary(PDICT pdict, int key, int *ppos, pfunc_search method){ 
  int st;
	if(!pdict || key < 0 || !ppos || !method){
    return ERR;
  }
  st = method(pdict->table, 0, pdict->n_data, key, ppos);
  return st;
}

/* Search functions of the Dictionary ADT */
int bin_search(int *table,int F,int L,int key, int *ppos){ 
  int res=0, ob=0;
  
	if(!table || key < 0 || !ppos || F < 0 || L < 0){
    return ERR;
  }
  while(F<=L){
    
    res = (F+L)/2;
    ob++;
    if(table[res] == key){
      *ppos = res;
      return ob;
    }
    
    else if(table[res] < key){
      F = res+1;
    }

    else if(table[res] > key){
      L = res -1;
    }
  }
  *ppos = NOT_FOUND;
  return ERR;
}

int lin_search(int *table,int F,int L,int key, int *ppos){
	int i=0, ob=0;
  if(!table || key < 0 || !ppos || F < 0 || L < 0){
    return ERR;
  }
  for(i= F; i< L; i++){
    ob++;
    if(table[i] ==  key){
      *ppos = i;
      return ob; 
    }
  }
  *ppos = NOT_FOUND;
  return ERR;
}
int lin_auto_search(int *table,int F,int L,int key, int *ppos){
  int i=0, aux=0, ob=0;
  if(!table || key < 0 || !ppos || F < 0 || L < 0){
    return ERR;
  }
  for(i = F; i<L; i++){
    ob++;
    if(table[i] ==  key){
      if(i == F){
        *ppos = F;
        return ob;
      }
      *ppos = i-1;
      aux = table[i-1];
      table[i-1] = key;
      table[i]= aux;
      return ob;
    }
  }
  *ppos = NOT_FOUND;
  return ERR;
}


