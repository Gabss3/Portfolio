/**
 *
 * Descripcion: Implementation of sorting functions
 *
 * Fichero: sorting.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */


#include "sorting.h"
#include <stdlib.h>
#include <stdio.h>

void swap(int *a, int *b){
  int aux;
  if(a == NULL){
    return;
  }
  if(b == NULL){
    return;
  }
  aux = *a;
  *a = *b;
  *b = aux;

  return;
}


/***************************************************/
/* Function: SelectSort    Date:                   */
/* Your comment                                    */
/***************************************************/
int SelectSort(int* array, int ip, int iu)
{
  int i=0, minn=0, ob=0;
  
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  for(i=ip; i<iu; i++){
    minn = min(array, i, iu, &ob);
    if(minn == ERR){
      return ERR;
    }
    swap(&array[i], &array[minn]);
  }

  return ob; 
}

int SelectSortInv(int* array, int ip, int iu)
{
  int i=0, minn=0, ob=0;
  
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  for(i=iu; i>ip; i--){
    minn = min(array, ip, i, &ob);
    if(minn == ERR){
      return ERR;
    }
    swap(&array[i], &array[minn]);
  }

  return ob; 
}

int min(int* array, int ip, int iu, int *ob){ 
  int min=0, i=0;
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  min = ip;
  for(i=ip; i<=iu; i++){
    (*ob)++;
    if(array[min]> array[i]){
      min = i;
    }
  }

  return min;
}


int merge(int* tabla, int ip, int iu, int imedio){
  int i= ip, j = imedio+1, k=0, tam=0, ob=0;
  int *tablaux = NULL;

  if(!tabla || ip<0 || iu<ip || imedio<0){
      return ERR;
  }
  
  tam = (iu - ip) + 1;

  tablaux = (int*)malloc(tam*sizeof(int));
  if(!tablaux){
    return ERR;
  }
  
  while(i<=imedio && j <= iu){
    ob++;
    if (tabla[i] < tabla[j]){
      tablaux[k] = tabla[i];
      i++;
    }
    else{
      tablaux[k] = tabla[j];
      j++;
    } 
    k++;  
  }

  if(i>imedio){
    while(j<=iu){
      tablaux[k] = tabla[j];
      j++;
      k++;
    }
  }
  else if(j>iu){
    while(i<=imedio){
      tablaux[k] = tabla[i];
      i++;
      k++;
    }
  }

  for (i = ip; i <= iu; i++)
  {
    tabla[i] = tablaux[i - ip];
  }

  free(tablaux);
      
  return ob;
}


int mergesort(int* tabla, int ip, int iu){
  int med = 0;
  int ob = 0;
  int st = 0;

  if(!tabla || ip<0 || iu<ip){
      return ERR;
  }
  if(ip == iu){
    return OK;
  }
  else{
    med = (ip+iu)/2;
    
    st = mergesort(tabla,ip,med);
    if(st == ERR){
      return ERR;
    }
    ob += st;
    
    st = mergesort(tabla,med+1,iu);
    if(st == ERR){
      return ERR;
    }
    ob += st;

    st = merge(tabla,ip,iu,med);
    if(st == ERR){
      return ERR;
    }
    ob += st;

  }

  return ob;
}

int median(int *tabla, int ip, int iu,int *pos){
  
  if(!tabla || ip<0 || iu<ip){
      return ERR;
  }

  *pos = ip;
  return OK;
}

int median_avg(int *tabla, int ip, int iu, int *pos){
  if(!tabla || ip<0 || iu<ip){
      return ERR;
  }

  *pos = (ip+iu)/2;
  return OK;
}

int median_stat(int *tabla, int ip, int iu, int *pos){
  
  int med = (ip+iu)/2, ob=3;
  if(!tabla || ip<0 || iu<ip){
      return ERR;
  }

  if ((tabla[ip] >= tabla[iu] && tabla[ip] <= med) || (tabla[ip] >= med && tabla[ip] <= tabla[iu]))
        *pos = ip;
  else if ((tabla[iu] >= tabla[ip] && tabla[iu] <= med) || (tabla[iu] >= med && tabla[iu] <= tabla[ip]))
      *pos = iu;
  else
      *pos = med;

    return ob;
}

int partition(int* tabla, int ip, int iu,int *pos){
  int ob=0, k = 0, st, i;

  st = median(tabla, ip, iu, pos);
  if(st == ERR){
      return ERR;
  }
  k = tabla[*pos];

  swap(&tabla[ip], &tabla[*pos]);

  *pos = ip;

  for(i=ip+1; i<=iu; i++){
    ob++;
    if(tabla[i]<k){
      (*pos)++;
       swap(&tabla[i],&tabla[*pos]);
    }

  }

  swap(&tabla[ip],&tabla[*pos]);
  
  return ob;
}

int quicksort(int* tabla, int ip, int iu){
  int ob=0, pivote, st;
  
  if(iu<ip){
    return -1;
  }

  if(ip == iu){
    return 0;
  }

  st = partition(tabla, ip, iu, &pivote);

  if(st >0){
    ob+= st;
  }
  else{
    return ERR;
  }

  if(ip< pivote-1){
    st = quicksort(tabla, ip, pivote-1);
    if(st == ERR){
      return ERR;
    }
    ob += st;
  }

  if(pivote+1 < iu){
    st = quicksort(tabla,pivote+1,iu);
    if(st == ERR){
      return ERR;
    }
    ob += st;
  }

  return ob;

}

