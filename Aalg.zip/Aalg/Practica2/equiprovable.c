#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "permutations.h"

int main(){
    FILE* f;
    int i,num = 0, *array;
    f = fopen("equi.txt","w");
    if(!f){
        return -1;
    }

    array = (int*)malloc(10*sizeof(int));
    if(!array){
        return -1;
    }
    
    for(i=0;i<=1000000;i++){
        num = random_num(1,10);
        if(num == 1){
            array[0]++;
        }
        if(num == 2){
            array[1]++;
        }
        if(num == 3){
            array[2]++;
        }
        if(num == 4){
            array[3]++;
        }
        if(num == 5){
            array[4]++;
        }
        if(num == 6){
            array[5]++;
        }
        if(num == 7){
            array[6]++;
        }
        if(num == 8){
            array[7]++;
        }
        if(num == 9){
            array[8]++;
        }
        if(num == 10){
            array[9]++;
        }
        
    }
    for(i=0;i<=9;i++){
        fprintf(f,"%d\n",array[i]);
    }

    free(array);
    fclose(f);
    return 0;
}