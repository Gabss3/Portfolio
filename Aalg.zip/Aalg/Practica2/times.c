/**
 *
 * Descripcion: Implementation of time measurement functions
 *
 * Fichero: times.c
 * Autor: Carlos Aguirre Maeso
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "times.h"
#include "sorting.h"
#include "permutations.h"

/***************************************************/
/* Function: average_sorting_time Date:            */
/*                                                 */
/* Your documentation                              */
/***************************************************/
short average_sorting_time(pfunc_sort method, int n_perms, int N, PTIME_AA ptime){
  int i=0, ob, *opb, avrg=0;
  clock_t start_t, end_t;
  int **perms = generate_permutations(n_perms,N);
  if(!perms){
    return ERR;
  }

  if(method == NULL){
    return ERR;
  }
  if(n_perms<=0){
    return ERR;
  }
  if(N<=0){
    return ERR;
  }
  if(ptime == NULL){
    return ERR;
  }

  opb = (int*)malloc(n_perms*sizeof(int));
  if(!opb){
    for(i=0;i<n_perms;i++){
      free(perms[i]);
    }
    free(perms);
    return ERR;
  }

  start_t = clock();
  if(start_t == -1){
    for(i=0;i<n_perms;i++){
      free(perms[i]);
    }
    free(perms);
    free(opb);
    return ERR;
  }

  for(i=0; i<n_perms; i++){
    ob=method(perms[i], 0, N-1);
    if(ob == ERR){
      for(i=0;i<n_perms;i++){
        free(perms[i]);
      }
      free(perms);
      free(opb);
      return ERR;
    }
    opb[i]= ob;
  }

  end_t = clock();
  if(end_t == -1){
    for(i=0;i<n_perms;i++){
      free(perms[i]);
    }
    free(perms);
    free(opb);
    return ERR;
  }
  ptime->N = N;
  ptime->n_elems = n_perms;

  ptime->max_ob= opb[0];
  for(i=0; i<n_perms;i++){
    if(ptime->max_ob< opb[i]){
      ptime->max_ob = opb[i];
    } 
  }

  ptime->min_ob= opb[0];
  for(i=0; i<n_perms;i++){
    if(ptime->min_ob > opb[i]){
      ptime->min_ob = opb[i];
    } 
    avrg+= opb[i];
  }

  ptime->average_ob = avrg/n_perms;

  ptime->time = ((double)(end_t - start_t) / (CLOCKS_PER_SEC)/n_perms);
  
  free(opb);
  
  for(i=0;i<n_perms;i++){
    free(perms[i]);
  }
  free(perms);
  return OK;
}

/***************************************************/
/* Function: generate_sorting_times Date:          */
/*                                                 */
/* Your documentation                              */
/***************************************************/
short generate_sorting_times(pfunc_sort method, char* file, int num_min, int num_max, int incr, int n_perms){

  PTIME_AA time;

  int i,j,n_times,ret;

  if(method == NULL){
    return ERR;
  }
  if(n_perms<=0){
    return ERR;
  }
  if(num_min<=0){
    return ERR;
  }
  if(num_max<=0){
    return ERR;
  }
  if(incr <=0){
    return ERR;
  }

  n_times = ((num_max-num_min) / incr)+1; 

  time = (PTIME_AA)malloc(n_times*sizeof(TIME_AA));
  if(!time){
    return ERR;
  }
  
  for(j=0,i=num_min; i <= num_max; j++,i += incr){
    ret = average_sorting_time(method, n_perms, i, &time[j]);
    
    if(ret == ERR){
      free(time);
      return ERR;
    } 

  }


  ret = save_time_table(file,time,n_times);
  if(ret == ERR){
    free(time);
    return ERR;
  } 
  
  free(time);
  return OK;
}

/***************************************************/
/* Function: save_time_table Date:                 */
/*                                                 */
/* Your documentation                              */
/***************************************************/
short save_time_table(char* file, PTIME_AA ptime, int n_times){

  FILE *fichero;
  int i;
  
  fichero = fopen(file, "w");
  if(!fichero){
    return ERR;
  }
  

  for(i=0; i<n_times; i++){
    fprintf(fichero, "%d %f %.2f %d %d \n", ptime[i].N, ptime[i].time, ptime[i].average_ob, ptime[i].max_ob, ptime[i].min_ob);
  }

  fclose(fichero);
  
  return OK;
}


