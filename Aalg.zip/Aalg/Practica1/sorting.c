/**
 *
 * Descripcion: Implementation of sorting functions
 *
 * Fichero: sorting.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */


#include "sorting.h"
#include <stdlib.h>
#include <stdio.h>

void swap(int *a, int *b){
  int aux;
  if(a == NULL){
    return;
  }
  if(b == NULL){
    return;
  }
  aux = *a;
  *a = *b;
  *b = aux;

  return;
}


/***************************************************/
/* Function: SelectSort    Date:                   */
/* Your comment                                    */
/***************************************************/
int SelectSort(int* array, int ip, int iu)
{
  int i=0, minn=0, ob=0;
  
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  for(i=ip; i<iu; i++){
    minn = min(array, i, iu, &ob);
    if(minn == ERR){
      return ERR;
    }
    swap(&array[i], &array[minn]);
  }

  return ob; 
}

int SelectSortInv(int* array, int ip, int iu)
{
  int i=0, minn=0, ob=0;
  
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  for(i=iu; i>ip; i--){
    minn = min(array, ip, i, &ob);
    if(minn == ERR){
      return ERR;
    }
    swap(&array[i], &array[minn]);
  }

  return ob; 
}

int min(int* array, int ip, int iu, int *ob){ 
  int min=0, i=0;
  if(!array || ip<0 || iu<ip){
    return ERR;
  }

  min = ip;
  for(i=ip; i<=iu; i++){
    (*ob)++;
    if(array[min]> array[i]){
      min = i;
    }
  }

  return min;
}