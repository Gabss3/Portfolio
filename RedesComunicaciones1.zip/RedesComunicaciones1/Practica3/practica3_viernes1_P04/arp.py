'''
    arp.py
    Implementación del protocolo ARP y funciones auxiliares que permiten realizar resoluciones de direcciones IP.
    Autor: Javier Ramos <javier.ramos@uam.es>
    2019 EPS-UAM
'''



from ethernet import *
import logging
import socket
import struct
import fcntl
import time
from threading import Lock
from expiringdict import ExpiringDict

#Semáforo global 
globalLock =Lock()
#Dirección de difusión (Broadcast)
broadcastAddr = bytes([0xFF]*6)
#Cabecera ARP común a peticiones y respuestas. Específica para la combinación Ethernet/IP
ARPHeader = bytes([0x00,0x01,0x08,0x00,0x06,0x04]) #?? segun el enunciado la cabecera tiene otra estructura
#longitud (en bytes) de la cabecera común ARP
ARP_HLEN = 6 #?? segun el enunciado la cabecera ARP tiene 28 bytes

#Variable que alamacenará que dirección IP se está intentando resolver
requestedIP = None
#Variable que alamacenará que dirección MAC resuelta o None si no se ha podido obtener
resolvedMAC = None
#Variable que alamacenará True mientras estemos esperando una respuesta ARP
awaitingResponse = False

myIP = None

#Variable para proteger la caché
cacheLock = Lock()
#Caché de ARP. Es un diccionario similar al estándar de Python solo que eliminará las entradas a los 10 segundos
cache = ExpiringDict(max_len=100, max_age_seconds=10)

def ARPGratiutousMascara() -> int:
    if ARPGratiutous(myIP) == 0:
        logging.info('La IP %s no está duplicada en la red.', socket.inet_ntoa(struct.pack('!I', myIP)))
    return 0

def ARPGratiutous(ip_comprobar: int) -> int:
    '''
    Nombre: ARPGratiutous
    Descripción: Envía un ARP gratuitous request para verificar si la IP `ip_comprobar`
                 ya está en uso en la red. Si recibe respuesta, significa que la IP está
                 en uso y retorna un error.
    Argumentos:
        - ip_comprobar: Entero de 32 bits con la dirección IP que se quiere verificar
    Retorno: 0 si la IP no está en uso (no hay respuesta), -1 si ya está en uso (hay respuesta)
    '''
    global awaitingResponse, requestedIP, resolvedMAC

    with globalLock:
        requestedIP = ip_comprobar
        awaitingResponse = True
        resolvedMAC = None

    # Creamos petición ARP para comprobar si la IP está en uso
    arp_request = createARPRequest(ip_comprobar)
    etherType = 0x0806  # Código de EtherType para ARP
    sendEthernetFrame(arp_request, len(arp_request), etherType, broadcastAddr)

    #Esperamos una respuesta
    time.sleep(1)

    # Revisamos si se recibió una respuesta ARP
    with globalLock:
        if awaitingResponse:  
            awaitingResponse = False
            requestedIP = None
            return 0  
        else:
            logging.error('La IP %s ya está en uso en la red.', socket.inet_ntoa(struct.pack('!I', ip_comprobar)))
            return -1  




def getIP(interface:str) -> int:
    '''
        Nombre: getIP
        Descripción: Esta función obtiene la dirección IP asociada a una interfaz. Esta función NO debe ser modificada
        Argumentos:
            -interface: nombre de la interfaz
        Retorno: Entero de 32 bits con la dirección IP de la interfaz
    '''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ip = fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', (interface[:15].encode('utf-8')))
    )[20:24]
    s.close()
    return struct.unpack('!I',ip)[0]

def printCache()->None:
    '''
        Nombre: printCache
        Descripción: Esta función imprime la caché ARP
        Argumentos: Ninguno
        Retorno: Ninguno
    '''
    print('{:>12}\t\t{:>12}'.format('IP','MAC'))
    with cacheLock:
        for k in cache:
            if k in cache:
                print ('{:>12}\t\t{:>12}'.format(socket.inet_ntoa(struct.pack('!I',k)),':'.join(['{:02X}'.format(b) for b in cache[k]])))



def processARPRequest(data:bytes,MAC:bytes)->None:
    '''
        Nombre: processARPRequest
        Decripción: Esta función procesa una petición ARP. Esta función debe realizar, al menos, las siguientes tareas:
            -Extraer la MAC origen contenida en la petición ARP
            -Si la MAC origen de la trama ARP no es la misma que la recibida del nivel Ethernet retornar
            -Extraer la IP origen contenida en la petición ARP
            -Extraer la IP destino contenida en la petición ARP
            -Comprobar si la IP destino de la petición ARP es la propia IP:
                -Si no es la propia IP retornar
                -Si es la propia IP:
                    -Construir una respuesta ARP llamando a createARPReply (descripción más adelante)
                    -Enviar la respuesta ARP usando el nivel Ethernet (sendEthernetFrame)
        Argumentos:
            -data: bytearray con el contenido de la trama ARP (después de la cabecera común)
            -MAC: dirección MAC origen extraída por el nivel Ethernet
        Retorno: Ninguno
    '''
    global myIP,myMAC


    #formato de la cabecera ARP específica para Ethernet/IP, es el formato en el que vamos a desempaquetar la trama
    ARP_HEADER_FORMAT = '!HHBBH6s4s6s4s'
    
    expected_length = struct.calcsize(ARP_HEADER_FORMAT)

    #desempaquetar la trama ARP y extraemos todo lo que contiene
    hw_type, proto_type, hw_size, proto_size, opcode, sender_mac, sender_ip, target_mac, target_ip = struct.unpack(ARP_HEADER_FORMAT, data[:expected_length])

    #direccion MAC del nivel Ethernet
    ethernet_MAC = MAC 
    
   #verificamos que la direccion MAC del nivel Ethernet y la obtenido dentro de la trama ARP coincidan
    if ethernet_MAC != sender_mac:
        logging.debug('Las direcciones MAC no coinciden, el paquete esta malformado o ha sido alterado.')
        return    

    
    #convertimos la IP destino a formato legible
    target_IP_int = struct.unpack('!I', target_ip)[0]
        
    #comprobamos que la IP destino de la peticion ARP es la propia IP
    if myIP != target_IP_int:
        logging.debug('Las IP no coinciden, el paquete ARP no viene dirigido a este sistema y por lo tanto ha sido descartado.')
        return
    
    sender_IP_int = struct.unpack('!I', sender_ip)[0]

    #llamamos a arpreply para construir una respuesta
    arp_reply = createARPReply(sender_IP_int, ethernet_MAC)
    
    #enviamos la respuesta ARP usando el nivel Ethernet
    etherType = 0x0806  #código de EtherType para ARP mencionado en la practica
    result = sendEthernetFrame(arp_reply, len(arp_reply), etherType, sender_mac)
    
    #verificamos si el envío fue exitoso
    if result != 0:
        logging.error('Error al enviar la respuesta ARP.')
    else:
        logging.debug('Respuesta ARP enviada correctamente.')    
    
def processARPReply(data:bytes,MAC:bytes)->None:
    '''
        Nombre: processARPReply
        Decripción: Esta función procesa una respuesta ARP. Esta función debe realizar, al menos, las siguientes tareas:
            -Extraer la MAC origen contenida en la petición ARP
            -Si la MAC origen de la trama ARP no es la misma que la recibida del nivel Ethernet retornar
            -Extraer la IP origen contenida en la petición ARP
            -Extraer la MAC destino contenida en la petición ARP
            -Extraer la IP destino contenida en la petición ARP
            -Comprobar si la IP destino de la petición ARP es la propia IP:
                -Si no es la propia IP retornar
                -Si es la propia IP:
                    -Comprobar si la IP origen se corresponde con la solicitada (requestedIP). Si no se corresponde retornar
                    -Copiar la MAC origen a la variable global resolvedMAC
                    -Añadir a la caché ARP la asociación MAC/IP.
                    -Cambiar el valor de la variable awaitingResponse a False
                    -Cambiar el valor de la variable requestedIP a None
        Las variables globales (requestedIP, awaitingResponse y resolvedMAC) son accedidas concurrentemente por la función ARPResolution y deben ser protegidas mediante un Lock.
        Argumentos:
            -data: bytearray con el contenido de la trama ARP (después de la cabecera común)
            -MAC: dirección MAC origen extraída por el nivel Ethernet
        Retorno: Ninguno
    '''
    global requestedIP,resolvedMAC,awaitingResponse,cache, myIP
    
    #formato de la cabecera ARP específica para Ethernet/IP, es el formato en el que vamos a desempaquetar la trama
    ARP_HEADER_FORMAT = '!HHBBH6s4s6s4s'

    expected_length = struct.calcsize(ARP_HEADER_FORMAT)

    #desempaquetar la trama ARP y extraemos todo lo que contiene
    hw_type, proto_type, hw_size, proto_size, opcode, sender_mac, sender_ip, target_mac, target_ip = struct.unpack(ARP_HEADER_FORMAT, data[:expected_length])

    #direccion MAC del nivel Ethernet
    ethernet_MAC = MAC 
    
   #verificamos que la direccion MAC del nivel Ethernet y la obtenido dentro de la trama ARP coincidan
    if ethernet_MAC != sender_mac:
        logging.debug('Las direcciones MAC no coinciden, el paquete esta malformado o ha sido alterado.')
        return
    
    #obtenemos en formato legible la direccion IP del sistema (de la interfaz)
    
    
    #convertimos la IP destino a formato legible
    target_IP_int = struct.unpack('!I', target_ip)[0]
        
    #comprobamos que la IP destino de la peticion ARP es la propia IP
    if myIP != target_IP_int:
        logging.debug('Las IP no coinciden, el paquete ARP no viene dirigido a este sistema y por lo tanto ha sido descartado.')
        return

    #bloqueamos el acceso a las variables globales mientras las accedemos/modificamos
    with globalLock:
        
        #verificamos si la IP origen es igual a la solicitada (requestedIP)
        if requestedIP != struct.unpack('!I', sender_ip)[0]:  #comparamos como enteros
            logging.debug('La IP origen no se corresponde con la IP solicitada, el paquete ha sido descartado.')
            return
        
        #copiamos la MAC origen a la variable global resolvedMAC
        resolvedMAC = sender_mac

        #añadimos a la caché ARP la asociación MAC/IP
        cache[struct.unpack('!I', sender_ip)[0]] = sender_mac
        
        #cambiamos el estado de la variable awaitingResponse
        awaitingResponse = False
        
        #cambiamos requestedIP a None
        requestedIP = None
    
    logging.debug('Respuesta ARP procesada y caché actualizada.')
        


def createARPRequest(ip:int) -> bytes:
    '''
        Nombre: createARPRequest
        Descripción: Esta función construye una petición ARP y devuelve la trama con el contenido.
        Argumentos: 
            -ip: dirección a resolver 
        Retorno: Bytes con el contenido de la trama de petición ARP
    '''
    global myMAC,myIP
    frame = bytes()
    
    #formato de la cabecera ARP específica para Ethernet/IP
    ARP_HEADER_FORMAT = '!HHBBH6s4s6s4s'
    
    #construimos la cabecera ARP segun los valores que nos han indicado en la practica
    hw_type = 0x0001  #ethernet
    proto_type = 0x0800  #IPv4
    hw_size = 6  #tamaño de la dirección MAC
    proto_size = 4  #tamaño de la dirección IP
    opcode = 0x0001  #petición ARP

    #creamos los datos de la trama ARP
    #Sender MAC (myMAC) y Sender IP (myIP) del dispositivo
    sender_mac = myMAC
    sender_ip = struct.pack('!I', myIP)  #convertimos a formato de bytes
    target_mac = bytes([0x00] * 6)  #como la MAC destino es desconocida se pone a 0
    target_ip = struct.pack('!I', ip)  #convertimos la IP objetivo a bytes

    #construimos la trama ARP
    frame = struct.pack(ARP_HEADER_FORMAT, hw_type, proto_type, hw_size, proto_size, opcode, sender_mac, sender_ip, target_mac, target_ip)
    
    
    return frame

def createARPReply(IP:int ,MAC:bytes) -> bytes:
    '''
        Nombre: createARPReply
        Descripción: Esta función construye una respuesta ARP y devuelve la trama con el contenido.
        Argumentos: 
            -IP: dirección IP a la que contestar
            -MAC: dirección MAC a la que contestar
        Retorno: Bytes con el contenido de la trama de petición ARP
    '''
    global myMAC,myIP
    frame = bytes()
    
    #formato de la cabecera ARP específica para Ethernet/IP
    ARP_HEADER_FORMAT = '!HHBBH6s4s6s4s'
    
    #construimos la cabecera ARP
    hw_type = 0x0001  #ethernet
    proto_type = 0x0800  # IPv4
    hw_size = 6  #tamaño de la dirección MAC
    proto_size = 4  #tamaño de la dirección IP
    opcode = 0x0002  #respuesta ARP

    #creamos los datos de la trama ARP
    #Sender MAC (myMAC) y Sender IP (myIP) del dispositivo
    sender_mac = myMAC
    sender_ip = struct.pack('!I', myIP)  #convertimos a formato de bytes
    target_mac = MAC  #la MAC destino es la que se pasa como argumento
    target_ip = struct.pack('!I', IP)  #convertimos la IP destino a bytes

    #construimos la trama ARP
    frame = struct.pack(ARP_HEADER_FORMAT, hw_type, proto_type, hw_size, proto_size, opcode, sender_mac, sender_ip, target_mac, target_ip)
    
    return frame
    

def process_arp_frame(us:ctypes.c_void_p,header:pcap_pkthdr,data:bytes,srcMac:bytes) -> None:
    '''
        Nombre: process_arp_frame
        Descripción: Esta función procesa las tramas ARP. 
            Se ejecutará por cada trama Ethenet que se reciba con Ethertype 0x0806 (si ha sido registrada en initARP). 
            Esta función debe realizar, al menos, las siguientes tareas:
                -Extraer la cabecera común de ARP (6 primeros bytes) y comprobar que es correcta
                -Extraer el campo opcode
                -Si opcode es 0x0001 (Request) llamar a processARPRequest (ver descripción más adelante)
                -Si opcode es 0x0002 (Reply) llamar a processARPReply (ver descripción más adelante)
                -Si es otro opcode retornar de la función
                -En caso de que no exista retornar
        Argumentos:
            -us: Datos de usuario pasados desde la llamada de pcap_loop. En nuestro caso será None
            -header: cabecera pcap_pktheader
            -data: array de bytes con el contenido de la trama ARP
            -srcMac: MAC origen de la trama Ethernet que se ha recibido
        Retorno: Ninguno
    '''
    #definimos el formato de la cabecera ARP
    ARP_HEADER_FORMAT = '!HHBBH6s4s6s4s'

    #extraemos la cabecera común de ARP
    try:
        hw_type, proto_type, hw_size, proto_size, opcode, sender_mac, sender_ip, target_mac, target_ip = struct.unpack(ARP_HEADER_FORMAT, data[:struct.calcsize(ARP_HEADER_FORMAT)])
    except struct.error as e:
        logging.error('Error al desempaquetar la trama ARP: %s', e)
        return

    #comprobamos si el opcode es una petición o una respuesta
    if opcode == 0x0001:  #se trata de una ARP Request
        processARPRequest(data, srcMac)
    elif opcode == 0x0002:  #se trata de una ARP Reply
        processARPReply(data, srcMac)
    else:
        logging.debug('Opcode erroneo: %04x', opcode)
        return


def initARP(interface:str) -> int:
    '''
        Nombre: initARP
        Descripción: Esta función construirá inicializará el nivel ARP. Esta función debe realizar, al menos, las siguientes tareas:
            -Registrar la función del callback process_arp_frame con el Ethertype 0x0806
            -Obtener y almacenar la dirección MAC e IP asociadas a la interfaz especificada
            -Realizar una petición ARP gratuita y comprobar si la IP propia ya está asignada. En caso positivo se debe devolver error.
            -Marcar la variable de nivel ARP inicializado a True
    '''
    global myIP,myMAC,arpInitialized
    
     #registramos la función del callback process_arp_frame con el Ethertype 0x0806
    if registerEthCallback(process_arp_frame, 0x0806) != 0:
        logging.error('Error al registrar la función de callback para ARP')
        return -1
    

    #obtenemos y almacenamos la dirección IP y MAC asociadas a la interfaz especificada
    try:
        myMAC = getHwAddr(interface) 
        myIP = getIP(interface)
    except Exception as e:
        logging.error('Error al obtener MAC o IP: %s', e)
        return -1
    
    #hacemos una petición ARP gratuita y comprobamos si la IP propia ya está asignada
    if ARPGratiutous(myIP) != 0:
        return -1

    #marcamos la variable de nivel ARP inicializado a True
    arpInitialized = True

    with cacheLock:
        cache[myIP] = myMAC

    logging.debug('Nivel ARP inicializado correctamente')
    return 0

def ARPResolution(ip:int) -> bytes:
    '''
        Nombre: ARPResolution
        Descripción: Esta función intenta realizar una resolución ARP para una IP dada y devuelve la dirección MAC asociada a dicha IP 
            o None en caso de que no haya recibido respuesta. Esta función debe realizar, al menos, las siguientes tareas:
                -Comprobar si la IP solicitada existe en la caché:
                -Si está en caché devolver la información de la caché
                -Si no está en la caché:
                    -Construir una petición ARP llamando a la función createARPRequest (descripción más adelante)
                    -Enviar dicha petición
                    -Comprobar si se ha recibido respuesta o no:
                        -Si no se ha recibido respuesta reenviar la petición hasta un máximo de 3 veces. Si no se recibe respuesta devolver None
                        -Si se ha recibido respuesta devolver la dirección MAC
            Esta función necesitará comunicarse con el la función de recepción (para comprobar si hay respuesta y la respuesta en sí) mediante 3 variables globales:
                -awaitingResponse: indica si está True que se espera respuesta. Si está a False quiere decir que se ha recibido respuesta
                -requestedIP: contiene la IP por la que se está preguntando
                -resolvedMAC: contiene la dirección MAC resuelta (en caso de que awaitingResponse) sea False.
            Como estas variables globales se leen y escriben concurrentemente deben ser protegidas con un Lock
    '''
    global requestedIP,awaitingResponse,resolvedMAC
    
    num_trials = 3
    retry_interval = 1  #segundos entre cada reintento

    #comprobamos si la IP está en la caché
    with cacheLock:
        if ip in cache:
            return cache[ip]  #devolvemos la MAC si está en caché

    #si no está en la caché,enviamos una petición ARP
    logging.debug('IP no encontrada en caché, enviando petición ARP para %s', socket.inet_ntoa(struct.pack('!I', ip)))
    
    if myIP == ip:
        logging.info('No puedes enviar una peticion sobre tu misma IP %s', socket.inet_ntoa(struct.pack('!I', myIP)))
        return
    
    #construimos y enviamos la petición ARP
    requestData = createARPRequest(ip)
    sendEthernetFrame(requestData, len(requestData), 0x0806, broadcastAddr)

    #iniciamos el proceso de espera de respuesta
    with globalLock:
        requestedIP = ip
        awaitingResponse = True

    #intentamos recibir respuesta, reintentando hasta 3 veces
    for attempt in range(num_trials):
        time.sleep(retry_interval)  #esperamos un segundo entre cada reintento

        with globalLock:
            if not awaitingResponse:  #si recibimos una respuesta:
                logging.debug('Respuesta recibida para %s', socket.inet_ntoa(struct.pack('!I', ip)))
                return resolvedMAC  #devolvemos la dirección MAC resuelta

    #si no se recibió respuesta tras los reintentos
    logging.warning('No se recibió respuesta ARP para %s después de %d intentos', socket.inet_ntoa(struct.pack('!I', ip)), num_trials)
    return None