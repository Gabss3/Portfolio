'''
    ip.py
    
    Funciones necesarias para implementar el nivel IP
    Autor: Javier Ramos <javier.ramos@uam.es>
    2022 EPS-UAM
'''
import math
from ethernet import *
from arp import *
from fcntl import ioctl
import subprocess
SIOCGIFMTU = 0x8921
SIOCGIFNETMASK = 0x891b
#Diccionario de protocolos. Las claves con los valores numéricos de protocolos de nivel superior a IP
#por ejemplo (1, 6 o 17) y los valores son los nombres de las funciones de callback a ejecutar.
protocols={}
#Tamaño mínimo de la cabecera IP
IP_MIN_HLEN = 20
#Tamaño máximo de la cabecera IP
IP_MAX_HLEN = 60


def chksum(msg):
    '''
        Nombre: chksum
        Descripción: Esta función calcula el checksum IP sobre unos datos de entrada dados (msg)
        Argumentos:
            -msg: array de bytes con el contenido sobre el que se calculará el checksum
        Retorno: Entero de 16 bits con el resultado del checksum en ORDEN DE RED
    '''
    s = 0
    y = 0xa29f    
    for i in range(0, len(msg), 2):
        if (i+1) < len(msg):
            a = msg[i] 
            b = msg[i+1]
            s = s + (a+(b << 8))
        elif (i+1)==len(msg):
            s += msg[i]
        else:
            raise 'Error calculando el checksum'
    y = y & 0x00ff
    s = s + (s >> 16)
    s = ~s & 0xffff

    return s

def getMTU(interface):
    '''
        Nombre: getMTU
        Descripción: Esta función obteiene la MTU para un interfaz dada
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar la MTU
        Retorno: Entero con el valor de la MTU para la interfaz especificada
    '''
    s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
    ifr = struct.pack('16sH', interface.encode("utf-8"), 0)
    mtu = struct.unpack('16sH', ioctl(s,SIOCGIFMTU, ifr))[1]
   
    s.close()
   
    return mtu
   
def getNetmask(interface):
    '''
        Nombre: getNetmask
        Descripción: Esta función obteiene la máscara de red asignada a una interfaz 
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar la máscara
        Retorno: Entero de 32 bits con el valor de la máscara de red
    '''
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ip = fcntl.ioctl(
        s.fileno(),
       SIOCGIFNETMASK,
        struct.pack('256s', (interface[:15].encode('utf-8')))
    )[20:24]
    s.close()
    return struct.unpack('!I',ip)[0]


def getDefaultGW(interface):
    '''
        Nombre: getDefaultGW
        Descripción: Esta función obteiene el gateway por defecto para una interfaz dada
        Argumentos:
            -interface: cadena con el nombre la interfaz sobre la que consultar el gateway
        Retorno: Entero de 32 bits con la IP del gateway
    '''
    p = subprocess.Popen(['ip r | grep default | awk \'{print $3}\''], stdout=subprocess.PIPE, shell=True)
    dfw = p.stdout.read().decode('utf-8')
    print(dfw)
    return struct.unpack('!I',socket.inet_aton(dfw))[0]



def process_IP_datagram(us,header,data,srcMac):
    '''
        Nombre: process_IP_datagram
        Descripción: Esta función procesa datagramas IP recibidos.
            Se ejecuta una vez por cada trama Ethernet recibida con Ethertype 0x0800
            Esta función debe realizar, al menos, las siguientes tareas:
                -Extraer los campos de la cabecera IP (includa la longitud de la cabecera)
                -Calcular el checksum y comprobar que es correcto                    
                -Analizar los bits de de MF y el offset. Si el offset tiene un valor != 0 dejar de procesar el datagrama (no vamos a reensamblar)
                -Loggear (usando logging.debug) el valor de los siguientes campos:
                    -Longitud de la cabecera IP
                    -IPID
                    -TTL
                    -Valor de las banderas DF y MF
                    -Valor de offset
                    -IP origen y destino
                    -Protocolo
                -Comprobar si tenemos registrada una función de callback de nivel superior consultando el diccionario protocols y usando como
                clave el valor del campo protocolo del datagrama IP.
                    -En caso de que haya una función de nivel superior registrada, debe llamarse a dicha funciñón 
                    pasando los datos (payload) contenidos en el datagrama IP.
        
        Argumentos:
            -us: Datos de usuario pasados desde la llamada de pcap_loop. En nuestro caso será None
            -header: cabecera pcap_pktheader
            -data: array de bytes con el contenido del datagrama IP
            -srcMac: MAC origen de la trama Ethernet que se ha recibido
        Retorno: Ninguno
   '''
    
    # Extraemos los campos de la cabecera IP
    ip_header = struct.unpack('!BBHHHBB', data[:10])
    checksum_invertido = struct.unpack('H',data[10:12])
    rest_ip_header = struct.unpack('II', data[12:IP_MIN_HLEN])
    #Dividimos 1B en 4 bits para obtener la versión y 4 bits para obtener la longitud de la cabecera
    versionihl = ip_header[0]
    print('versionihl: ', end='')
    print(versionihl)
    version = (versionihl & 0xF0) >> 4
    print('version: ', end='')
    print(version)

    #Multiplicamos por 4 para obtener la longitud en bytes
    ihl = (versionihl & 0x0F) * 4 
    print('ihl: ', end='')
    print(ihl)
    
    type_of_service = ip_header[1]
    total_length = ip_header[2]
    ip_id = ip_header[3]
    flags_offset = ip_header[4]
    ttl = ip_header[5]
    protocol = ip_header[6]
    checksum = checksum_invertido[0]
    src_ip = socket.ntohl(rest_ip_header[0])
    dst_ip = socket.ntohl(rest_ip_header[1])


    # Comprobaciones
    if version != 4:
        logging.error("Versión IP incorrecta")
        return

    if ihl < IP_MIN_HLEN or ihl > IP_MAX_HLEN:
        print(ihl)
        print(version)
        logging.error("Longitud de cabecera IP incorrecta")
        return

    # Comprobamos checksum
    if chksum(data[:10] + bytearray(2) + data[12:ihl])  != checksum:
        logging.error("Checksum IP incorrecto")
        return

    # Extraemos las banderas y offset y comprobamos si es un fragmento
    flags = (flags_offset & 0xE000) >> 13
    df = (flags & 0x2) >> 1
    mf = flags & 0x1
    offset = (flags_offset & 0x1FFF) * 8

    if offset != 0:
        logging.debug("Fragmento recibido, ignorando.")
        return

    # Loggeamos los campos usando logging.debug
    logging.debug(f"Procesando datagrama IP:")
    logging.debug(f"Versión: {version}, IHL: {ihl} bytes, ToS: {type_of_service}, Longitud total: {total_length} bytes")
    logging.debug(f"IPID: {ip_id}, TTL: {ttl}, Protocolo: {protocol}, Checksum: {checksum}")
    logging.debug(f"DF: {df}, MF: {mf}, Offset: {offset}")
    logging.debug(f"IP origen: {src_ip}, IP destino: {dst_ip}")

    # Por último, verificamos si tenemos un callback registrado para este protocolo
    if protocol in protocols:
        callback = protocols[protocol]
        payload = data[ihl:total_length]
        callback(us, header, payload, src_ip)
    else:
        logging.warning(f"Protocolo {protocol} no registrado.")





def registerIPProtocol(callback,protocol):
    '''
        Nombre: registerIPProtocol
        Descripción: Esta función recibirá el nombre de una función y su valor de protocolo IP asociado y añadirá en la tabla 
            (diccionario) de protocolos de nivel superior dicha asociación. 
            Este mecanismo nos permite saber a qué función de nivel superior debemos llamar al recibir un datagrama IP  con un 
            determinado valor del campo protocolo (por ejemplo TCP o UDP).
            Por ejemplo, podemos registrar una función llamada process_UDP_datagram asociada al valor de protocolo 17 y otra 
            llamada process_ICMP_message asocaida al valor de protocolo 1. 
        Argumentos:
            -callback_fun: función de callback a ejecutar cuando se reciba el protocolo especificado. 
                La función que se pase como argumento debe tener el siguiente prototipo: funcion(us,header,data,srcIp):
                Dónde:
                    -us: son los datos de usuarios pasados por pcap_loop (en nuestro caso este valor será siempre None)
                    -header: estructura pcap_pkthdr que contiene los campos len, caplen y ts.
                    -data: payload del datagrama IP. Es decir, la cabecera IP NUNCA se pasa hacia arriba.
                    -srcIP: dirección IP que ha enviado el datagrama actual.
                La función no retornará nada. Si un datagrama se quiere descartar basta con hacer un return sin valor y dejará de procesarse.
            -protocol: valor del campo protocolo de IP para el cuál se quiere registrar una función de callback.
        Retorno: Ninguno 
    '''

    protocols[protocol] = callback


def initIP(interface,opts=None):
    global myIP, MTU, netmask, defaultGW,ipOpts, IPID
    '''
        Nombre: initIP
        Descripción: Esta función inicializará el nivel IP. Esta función debe realizar, al menos, las siguientes tareas:
            -Llamar a initARP para inicializar el nivel ARP
            -Obtener (llamando a las funciones correspondientes) y almacenar en variables globales los siguientes datos:
                -IP propia
                -MTU
                -Máscara de red (netmask)
                -Gateway por defecto
            -Almacenar el valor de opts en la variable global ipOpts
            -Registrar a nivel Ethernet (llamando a registerCallback) la función process_IP_datagram con el Ethertype 0x0800
            -Inicializar el valor de IPID con el número de pareja
        Argumentos:
            -interface: cadena de texto con el nombre de la interfaz sobre la que inicializar ip
            -opts: array de bytes con las opciones a nivel IP a incluir en los datagramas o None si no hay opciones a añadir
        Retorno: True o False en función de si se ha inicializado el nivel o no
    '''
    # Primero intemtamos inicializar ARP
    if initARP(interface) == -1:
        logging.error("Error inicializando ARP")
        return False
    
    # Obtenemos los datos de la interfaz
    myIP = getIP(interface)
    MTU = getMTU(interface)
    netmask = getNetmask(interface)
    defaultGW = getDefaultGW(interface)

    # Almacenamos las opciones
    ipOpts = opts

    # Registramos la función de callback
    registerEthCallback(process_IP_datagram, 0x0800)

    # Inicializamos el valor de IPID
    IPID = 4

    return True
    

def sendIPDatagram(dstIP,data,protocol):
    global IPID, MTU, myIP, ipOpts

    '''
        Nombre: sendIPDatagram
        Descripción: Esta función construye un datagrama IP y lo envía. En caso de que los datos a enviar sean muy grandes la función
        debe generar y enviar el número de fragmentos IP que sean necesarios.
        Esta función debe realizar, al menos, las siguientes tareas:
            -Determinar si se debe fragmentar o no y calcular el número de fragmentos
            -Para cada datagrama o fragmento:
                -Construir la cabecera IP con los valores que corresponda.Incluir opciones en caso de que ipOpts sea distinto de None
                -Calcular el checksum sobre la cabecera y añadirlo a la cabecera
                -Añadir los datos a la cabecera IP
                -En el caso de que sea un fragmento ajustar los valores de los campos MF y offset de manera adecuada
                -Enviar el datagrama o fragmento llamando a sendEthernetFrame. Para determinar la dirección MAC de destino
                al enviar los datagramas se debe hacer unso de la máscara de red:                  
            -Para cada datagrama (no fragmento):
                -Incrementar la variable IPID en 1.
        Argumentos:
            -dstIP: entero de 32 bits con la IP destino del datagrama 
            -data: array de bytes con los datos a incluir como payload en el datagrama
            -protocol: valor numérico del campo IP protocolo que indica el protocolo de nivel superior de los datos
            contenidos en el payload. Por ejemplo 1, 6 o 17.
        Retorno: True o False en función de si se ha enviado el datagrama correctamente o no
          
    '''
    MTU_fixed = MTU
    if MTU % 8 != 0:
        MTU_fixed = math.floor(MTU // 8) * 8

    mtu_payload_size = MTU_fixed - IP_MIN_HLEN  
    if ipOpts:
        mtu_payload_size -= len(ipOpts)
    
    fragmentos = []
    data_offset = 0
    total_length = len(data)
    
    # Dividimos los datos en fragmentos si son mayores al tamaño del payload del MTU
    while total_length > 0:
        fragment_size = min(mtu_payload_size, total_length)
        fragmentos.append(data[data_offset:(data_offset + fragment_size)])
        data_offset += fragment_size
        total_length -= fragment_size

    # Generamos y enviamos cada fragmento
    for i, fragment in enumerate(fragmentos):
        is_last_fragment = (i == len(fragmentos) - 1)
        offset = (i * mtu_payload_size) // 8  

        ihl = 5 
        if ipOpts:
            ihl += len(ipOpts) // 4

        flags_offset = ((0b001 if not is_last_fragment else 0b000) << 13) | (offset & 0x1FFF)

        if ipOpts == None:
            ipOpts = bytearray(0)
        ip_header = struct.pack("!BBHHHBBHII", (4 << 4) | ihl, 1, 20 + len(ipOpts) + len(fragment),  IPID, flags_offset, 65, protocol, 0, myIP, dstIP)

        # Añadimos opciones si las hay
        if ipOpts:
            ip_header += ipOpts

        # Calculamos el checksum
        checksum = chksum(ip_header)
        ip_header = (ip_header[:10] + struct.pack('H', checksum) + ip_header[12:])

        # Combinamos cabecera y datos del fragmento
        packet = ip_header + fragment

        # Convertimos la IP destino en dirección MAC usando la red
        if (dstIP & netmask) != (myIP & netmask):
            dst_mac = ARPResolution(defaultGW)
        else:
            dst_mac = ARPResolution(dstIP)
        if not dst_mac:
            logging.error(f"Fallo al resolver MAC para la IP {dstIP}")
            return False

        # Enviamos usando sendEthernetFrame
        if sendEthernetFrame(packet, len(packet), 0x0800, dst_mac) == -1:
            logging.error(f"Error al enviar el fragmento {i} del datagrama IP")
            return False

        # Incrementamos IPID solo después de enviar un datagrama completo
        if is_last_fragment:
            IPID += 1

    return True

