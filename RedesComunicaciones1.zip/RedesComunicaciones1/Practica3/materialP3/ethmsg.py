'''
    ethmsg.py
    Implementación del protocolo de mensajeria basica para emision de mensajes en tiempo real sobre ethernet.
    Autor: Manuel Ruiz <manuel.ruiz.fernandez@uam.es>
    2024 EPS-UAM
'''

from ethernet import *
import logging
import socket
import struct
import fcntl
import time
from threading import Lock
from expiringdict import ExpiringDict

ETHTYPE = 0x3003
#Dirección de difusión (Broadcast)
broadcast = bytes([0xFF]*6)




def process_ethMsg_frame(us, header, data, srcMac):
    '''
    Nombre: process_ethMsg_frame
    Descripción:
        Esta función procesa las tramas mensajes sobre Ethernet con Ethertype 0x3003.
        Realiza las siguientes tareas:
        - Imprime el contenido de los datos (dirección IP y mensaje) indicando la MAC origen y el tiempo de recepción.
        - El formato de salida debe ser: [<segundos.microsegundos>] <MAC> -> <IP>: <mensaje>.
        - data[0:4] contiene la dirección IP, y data[4:] contiene el mensaje.

    Argumentos:
        - us: Datos de usuario pasados desde pcap_loop (en nuestro caso será None).
        - header: Cabecera pcap_pkthdr con la información de la captura (timestamp, etc.).
        - data: Array de bytes con el contenido de la trama Ethernet.
        - srcMac: Dirección MAC origen de la trama Ethernet que se ha recibido.

    Retorno:
        - Ninguno
    '''
    # Extraemos la dirección IP 
    ip_bytes = data[0:4]
    ip_address = '.'.join(map(str, ip_bytes))

    # El resto de la trama es el mensaje
    message = data[4:].decode('utf-8', errors='ignore')  # Decodificamos el mensaje (ignoramos errores de codificación)

    # Extraemos el tiempo de la cabecera
    timestamp = header.ts
    seconds = timestamp.tv_sec
    microseconds = timestamp.tv_usec

    # Convertimos la MAC a un formato legible
    src_mac_str = ':'.join(f'{byte:02x}' for byte in srcMac)

    # Imprimimos la información en el formato solicitado
    logging.info(f'[{seconds}.{microseconds:06d}] {src_mac_str} -> {ip_address}: {message}')




def initEthMsg(interface: str) -> int:
    '''
    Nombre: initEthMsg
    Descripción:
        Esta función inicializará el nivel EthMsg y registrará el callback process_ethMsg_frame
        con el Ethertype 0x3003. Se encargará de:
        - Registrar el callback `process_ethMsg_frame` para manejar las tramas con Ethertype 0x3003.
        - Inicializar el nivel Ethernet usando `startEthernetLevel`.

    Argumentos:
        - interface: nombre de la interfaz de red a utilizar.
    
    Retorno:
        - 0 si todo es correcto.
        - -1 si ocurre algún error.
    '''
    # Registramos la función de callback process_ethMsg_frame para Ethertype 0x3003

    ethertype = 0x3003
    registerEthCallback(process_ethMsg_frame, ethertype)


def sendEthMsg(ip: str, message: str) -> int:
    '''
    Nombre: sendEthMsg
    Descripción: 
        Esta función crea y envía un mensaje en broadcast sobre el protocolo 0x3003.
        Realiza las siguientes tareas:
        - Crear un paquete de datos que contenga la dirección IP y el mensaje.
        - Enviar los datos llamando a la función de envío de tramas Ethernet.
        - En los datos que se entreguen al nivel Ethernet, la dirección IP se codifica como 32 bits en orden de red (data[0:4]),
          y el mensaje se codifica como un array de bytes (data[4:]).

    Argumentos:
        - ip: Dirección IP destino a la que remitir el mensaje.
        - message: Cadena de caracteres con el mensaje a remitir.

    Retorno:
        - 0 si el envío fue exitoso, -1 en caso de error.
    '''
    global broadcastAddr

    
    # Convertir la dirección IP en formato decimal a 32 bits en orden de red
    ip_bytes = struct.pack('!I', ip)  # Esto convierte la IP a formato binario de 32 bits

    # Codificar el mensaje como un array de bytes
    message_bytes = message.encode('utf-8')

    # Crear los datos a enviar: IP (4 bytes) + Mensaje
    data = ip_bytes + message_bytes
    length = len(data)

    # Comprobar que el tamaño no exceda los límites de Ethernet
    if length > ETH_FRAME_MAX - 14:  # Restamos 14 bytes de la cabecera Ethernet
        logging.error(f"El tamaño del mensaje es demasiado grande para enviarlo en una trama Ethernet.")
        return -1

    # Enviar la trama Ethernet con el Ethertype 0x3003 en modo broadcast
    etherType = 0x3003

    result = sendEthernetFrame(data, length, etherType, broadcastAddr)

    if result != 0:
        logging.error(f"Error al enviar el mensaje a {ip}")

    return result


