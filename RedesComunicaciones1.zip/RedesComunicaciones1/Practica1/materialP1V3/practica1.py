'''
practica1.py
Muestra el tiempo de llegada de los primeros N paquetes a la interfaz especificada
como argumento y los vuelca a traza nueva con tiempo actual.

Autor: Javier Ramos <javier.ramos@uam.es>
Blanca Matas Gavira y Gabriella Leaño Kalocsa
2020 EPS-UAM
'''

from rc1_pcap import *
import sys
import signal
import argparse
import time
import logging

ETH_FRAME_MAX = 1514
TO_MS = 10
num_paquete = 0
primer_tiempo = None
ultimo_tiempo = None
max_paquetes = float('inf') 
num_bytes = 14  

def signal_handler(nsignal, frame):
    global num_paquete, primer_tiempo, ultimo_tiempo
    logging.info('Control C pulsado')
    if handle:
        pcap_breakloop(handle)

    # Calcular la diferencia de tiempo entre el primer y último tiempo
    if primer_tiempo is not None and ultimo_tiempo is not None:
        diferencia = ultimo_tiempo - primer_tiempo
        logging.info(f"Diferencia de tiempo entre el primer y último paquete: {diferencia:.6f} segundos")
    else:
        logging.info("No se capturaron el número mínimo de paquetes.")

    logging.info(f"Total de paquetes capturados: {num_paquete}")

    # Cerrar recursos
    if handle:
        pcap_close(handle)
    if dumper_noIP:
        pcap_dump_close(dumper_noIP)
    if dumper_IP:
        pcap_dump_close(dumper_IP)







def procesa_paquete(us, header, data):
    global num_paquete, primer_tiempo, ultimo_tiempo, dumper_IP, dumper_noIP
    num_paquete += 1
    timestamp = header.ts.tv_sec + header.ts.tv_usec / 1e6

    # Inicializar tiempos
    if primer_tiempo is None:
        primer_tiempo = timestamp
    ultimo_tiempo = timestamp

    # Guardar los N primeros bytes en el log
    logging.info(f'Nuevo paquete de {header.len} bytes capturado en el timestamp UNIX {header.ts.tv_sec}.{header.ts.tv_usec}')
    
    # Mostrar los N bytes especificados
    bytes_to_show = min(num_bytes, header.len)
    hex_data = ' '.join(f'{data[i]:02X}' for i in range(bytes_to_show)) #muestra los bytes especificados en formato hexadecimal 
    logging.info(hex_data)

    # Escribir el tráfico en el fichero de captura con el offset temporal
    byte12 = data[12]
    byte13 = data[13]
    if byte12 == 0x08 and byte13 == 0x00:
        pcap_dump(dumper_IP, header, data)  # Guardar paquete IP
    else:
        pcap_dump(dumper_noIP, header, data)  # Guardar paquete no IP






def analiza_traza(traza):
    global num_paquete, primer_tiempo, ultimo_tiempo
    errbuf = bytearray()

    # Abrir el archivo pcap para análisis
    handle = pcap_open_offline(traza, errbuf)
    
    if handle is None:
        logging.error("Error al abrir el archivo pcap.")
        return  # Salir si no se pudo abrir el archivo

    # Resetear contadores de paquetes y tiempos
    num_paquete = 0
    primer_tiempo = None
    ultimo_tiempo = None

    # Leer paquetes del archivo usando pcap_loop
    def callback(us, header, data):
        global num_paquete, primer_tiempo, ultimo_tiempo
        
        # Incrementar el número de paquetes procesados
        num_paquete += 1
        timestamp = header.ts.tv_sec + header.ts.tv_usec / 1e6

        # Inicializar tiempos
        if primer_tiempo is None:
            primer_tiempo = timestamp
        ultimo_tiempo = timestamp

        # Guardar los N primeros bytes en el log
        logging.info(f'Nuevo paquete de {header.len} bytes capturado en el timestamp UNIX {header.ts.tv_sec}.{header.ts.tv_usec}')
        
        # Mostrar los N bytes especificados
        bytes_to_show = min(num_bytes, header.len)
        hex_data = ' '.join(f'{data[i]:02X}' for i in range(bytes_to_show))
        logging.info(hex_data)

    ret = pcap_loop(handle, max_paquetes, callback, None)

    if ret == -1:
        logging.error('Error al procesar el archivo pcap.')
    elif ret == 0:
        logging.info('Se alcanzó el final del archivo pcap o se detuvo la captura.')

    # Calcular la diferencia de tiempo si hay al menos 2 paquetes
    if num_paquete >= 2:
        diferencia = ultimo_tiempo - primer_tiempo
        logging.info(f"Diferencia de tiempo entre el primer y último paquete: {diferencia:.6f} segundos")
    else:
        logging.info("No se capturaron suficientes paquetes para calcular la diferencia de tiempo.")

    logging.info(f'Total de paquetes leídos: {num_paquete}')
    
    # Cerrar el handle
    pcap_close(handle)


if __name__ == "__main__":
    global handle, dumper_IP, dumper_noIP
    parser = argparse.ArgumentParser(description='Captura tráfico de una interfaz (o lee de fichero) y muestra la longitud y timestamp de los primeros N paquetes',
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--file', dest='tracefile', default=False, help='Fichero pcap a abrir')
    parser.add_argument('--itf', dest='interface', default=False, help='Interfaz a abrir')
    parser.add_argument('--nbytes', dest='nbytes', type=int, default=14, help='Número de bytes a mostrar por paquete')
    parser.add_argument('--npkts', dest='npkts', type=int, default=float('inf'), help='Número de paquetes a procesar')
    parser.add_argument('--debug', dest='debug', default=False, action='store_true', help='Activar Debug messages')
    
    args = parser.parse_args()

    num_bytes = args.nbytes  
    max_paquetes = args.npkts  

    if args.debug:
        logging.basicConfig(level=logging.DEBUG, format='[%(asctime)s %(levelname)s]\t%(message)s')
    else:
        logging.basicConfig(level=logging.INFO, format='[%(asctime)s %(levelname)s]\t%(message)s')

    if args.tracefile is False and args.interface is False:
        logging.error('No se ha especificado interfaz ni fichero')
        parser.print_help()
        sys.exit(-1)

    if args.tracefile:
        analiza_traza(args.tracefile)
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    # Obtener la fecha actual en formato UNIX
    timestamp = int(time.time())
    interface_name = args.interface

    # Crear los nombres de los archivos
    file_noIP = f"capturaNOIP.{interface_name}.{timestamp}.pcap"  # Paquetes IP
    file_IP = f"captura.{interface_name}.{timestamp}.pcap"  # Paquetes no IP

    # Abrir la interfaz especificada para captura
    errbuf = bytearray()
    handle = pcap_open_live(interface_name, ETH_FRAME_MAX, 1, TO_MS, errbuf)
    
    # Crear los dumpers
    pcap_noIP_descr = pcap_open_dead(DLT_EN10MB, ETH_FRAME_MAX)
    pcap_IP_descr = pcap_open_dead(DLT_EN10MB, ETH_FRAME_MAX)
    dumper_noIP = pcap_dump_open(pcap_noIP_descr, file_noIP)
    dumper_IP = pcap_dump_open(pcap_IP_descr, file_IP)

    # Captura de paquetes
    ret = pcap_loop(handle, int(max_paquetes), procesa_paquete, None)
    
    if ret == -1:
        logging.error('Error al capturar un paquete')
    elif ret == -2:
        logging.debug('pcap_breakloop() llamado')
    elif ret == 0:
        logging.debug('No hay más paquetes o límite superado')

    logging.info(f'{num_paquete} paquetes procesados')

    # Cerrar recursos al final
    pcap_close(handle)
    pcap_dump_close(dumper_noIP)
    pcap_dump_close(dumper_IP)