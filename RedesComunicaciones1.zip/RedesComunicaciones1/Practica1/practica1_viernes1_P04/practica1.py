'''
practica1.py
Muestra el tiempo de llegada de los primeros N paquetes a la interfaz especificada
como argumento y los vuelca a traza nueva con tiempo actual.

Autor: Javier Ramos <javier.ramos@uam.es>
Blanca Matas Gavira y Gabriella Leaño Kalocsa
2020 EPS-UAM
'''

from rc1_pcap import *
import sys
import signal
import argparse
import time
import logging

ETH_FRAME_MAX = 1514
TO_MS = 10
num_paquete = 0
primer_tiempo = None
ultimo_tiempo = None
max_paquetes = float('inf') 
num_bytes = 14  

def signal_handler(nsignal, frame):
    global num_paquete, primer_tiempo, ultimo_tiempo, handle, dumper_IP, dumper_noIP
    logging.info('Control C pulsado')

    # Verificamos si handle está abierto antes de llamar a pcap_breakloop
    if handle:
        logging.info('Deteniendo captura de paquetes.')
        pcap_breakloop(handle)

    #Calculamos la diferencia de tiempo entre el primer y ultimo paquete
    if primer_tiempo is not None and ultimo_tiempo is not None:
        diferencia = ultimo_tiempo - primer_tiempo
        logging.info(f"Diferencia de tiempo entre el primer y último paquete: {diferencia:.6f} segundos")
    else:
        logging.info("No se capturaron el número mínimo de paquetes.")

    logging.info(f"Total de paquetes capturados: {num_paquete}")



dumper_IP = None
dumper_noIP = None
count = 0

#funcion que usa pcap_loop para analizar y manipular los paquetes que se van capturando
"""
us: son los datos auxiliares de usuario que se han pasado a pcap_loop
pkt_header: es un objeto de tipo pcap_pkthdr que contiene la cabecera pcap del paquete leído o capturado.Este objeto tiene tres campos:
    pkt_header.ts : objeto timestamp que contiene el tiempo de captura del paquete. A su vez este objeto tiene 2 campos:
        ts.tv_sec: timestamp del paquete en segundos.
        ts.tv_usec: microsegundos dentro del segundo actual de timestamp. OJO: Este valor nunca debe ser superior a 1,000,000. Esta variable NO almacena el mismo tiempo que tv_sec pero en microsegundos sino la parte fraccional del tiempo de captura.
    pkt_header.len: longitud real del paquete. 
    pkt_header.caplen: longitud capturada del paquete. Esto es, pkt_data solo contendrá pkt_header.caplen bytes.
data es un bytearray que contiene los datos del paquete en caso de éxito.
Es responsabilidad de pcap_loop(·), no de la función de atención, reservar y liberar la memoria para devolver la cabecera y datos de cada paquete.

"""
def procesa_paquete(us, header, data):
    global num_paquete, primer_tiempo, ultimo_tiempo, dumper_IP, dumper_noIP, count
    num_paquete += 1
    timestamp = header.ts.tv_sec + header.ts.tv_usec / 1e6

    # Inicializamos los tiempos
    if primer_tiempo is None:
        primer_tiempo = timestamp
    ultimo_tiempo = timestamp

    #Guardamos los N primeros bytes en el log junto al tiempo de captura
    logging.info(f'Nuevo paquete de {header.len} bytes capturado en el timestamp UNIX {header.ts.tv_sec}.{header.ts.tv_usec}')
    
    # Mostramos los N bytes especificados
    bytes_to_show = min(num_bytes, header.len)
    hex_data = ' '.join(f'{data[i]:02X}' for i in range(bytes_to_show))
    logging.info(hex_data)

    #Accedemos a los bytes 12 y 13 del paquete
    byte12 = data[12]
    byte13 = data[13]
    if dumper_IP is not None and byte12 == 0x08 and byte13 == 0x00:
        pcap_dump(dumper_IP, header, data)  
    elif dumper_noIP is not None:
        pcap_dump(dumper_noIP, header, data) 

    count+=1
    #Cuando se ha procesado el ultimo paquete escribimos en el log la difer     if count == max_paquetes:
    if count == max_paquetes:
        if num_paquete >= 2:
            diferencia = ultimo_tiempo - primer_tiempo
            logging.info(f"Diferencia de tiempo entre el primer y último paquete: {diferencia:.6f} segundos")
        else:
            logging.info("No se capturaron suficientes paquetes para calcular la diferencia de tiempo.")

        

def analiza_traza(traza):
    global num_paquete, primer_tiempo, ultimo_tiempo
    errbuf = bytearray()

    # Abrimos el archivo pcap para análisis ->funcion para abrir un archivo previamente capturado
    """
    traza es una cadena con el nombre del archivo .pcap que se desea abrir.
    errbuf es un bytearray donde se guardará un mensaje de error en caso de que algo haya fallado al abrir el fichero
    La función nos devuelve un descriptor al archivo .pcap o None/Excepción en caso de que haya algún error
    
    """
    handle = pcap_open_offline(traza, errbuf)
    
    if handle is None:
        logging.error("Error al abrir el archivo pcap.")
        return  # Salir si no se pudo abrir el archivo

    # Reseteamos contadores de paquetes y tiempos
    num_paquete = 0
    primer_tiempo = None
    ultimo_tiempo = None

    #procesamos los paquetes capturados
    #Leemos los paquetes contenidos en handles, procesa_paquete, None)
    ret = pcap_loop(handle, max_paquetes, procesa_paquete, None)
    if ret == -1:
        logging.error('Error al capturar un paquete')
    elif ret == -2:
        logging.debug('pcap_breakloop() llamado')
    elif ret == 0:
        logging.debug('No hay más paquetes o límite superado')

        
    if num_paquete >= 2:
        diferencia = ultimo_tiempo - primer_tiempo
        logging.info(f"Diferencia de tiempo entre el primer y último paquete: {diferencia:.6f} segundos")
    else:
        logging.info("No se capturaron suficientes paquetes para calcular la diferencia de tiempo.")

    logging.info(f'Total de paquetes leídos: {num_paquete}')
    
    # Cerramos el handle
    pcap_close(handle)




#Programa principal para la captura y analisis de paquetes
if __name__ == "__main__":
    global handle
    parser = argparse.ArgumentParser(description='Captura tráfico de una interfaz (o lee de fichero) y muestra la longitud y timestamp de los primeros N paquetes',
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--file', dest='tracefile', default=False, help='Fichero pcap a abrir')
    parser.add_argument('--itf', dest='interface', default=False, help='Interfaz a abrir')
    parser.add_argument('--nbytes', dest='nbytes', type=int, default=14, help='Número de bytes a mostrar por paquete')
    parser.add_argument('--npkts', dest='npkts', type=int, default=float('inf'), help='Número de paquetes a procesar')
    parser.add_argument('--debug', dest='debug', default=False, action='store_true', help='Activar Debug messages')
    
    #Obtenemos los argumentos escritos por terminal
    args = parser.parse_args()

    num_bytes = args.nbytes  
    max_paquetes = args.npkts if args.npkts != float('inf') else -1  

    if args.debug:
        logging.basicConfig(level=logging.DEBUG, format='[%(asctime)s %(levelname)s]\t%(message)s')
    else:
        logging.basicConfig(level=logging.INFO, format='[%(asctime)s %(levelname)s]\t%(message)s')

    #Si no se pone nigun argumento por terminal se muestra los comandos de ayuda
    if args.tracefile is False and args.interface is False:
        logging.error('No se ha especificado interfaz ni fichero')
        parser.print_help()
        sys.exit(-1)

    #Si se llama a --file por terminal llamamos a la funcion de analisis de traza
    if args.tracefile:
        analiza_traza(args.tracefile)
        
        sys.exit(0)

    #Configuramos la señal INT para que responda según lo especificado enunciado
    signal.signal(signal.SIGINT, signal_handler)

    # Obtenemos la fecha actual en formato UNIX
    timestamp = int(time.time())
    interface_name = args.interface

    # Creamos los nombres de los archivos con los parametros especificados
    file_noIP = f"capturaNOIP.{interface_name}.{timestamp}.pcap"  # Paquetes IP
    file_IP = f"captura.{interface_name}.{timestamp}.pcap"  # Paquetes no IP

    # Abrimos la interfaz para captura -> funcion para abrir un interfaz para captura
    """
    interface_name es una cadena con el nombre de la interfaz que se quiere abrir (eth0, ens33...).
    ETH_FRAME_MAX es la cantidad de bytes que se quieren guardar por cada paquete. Es útil cuando no nos interesa la carga útil del paquete y así reduciríamos el tamaño de la captura.
    promisc (1) indica si queremos abrirla en modo promiscuo (promisc=1) o no (promisc=0).
    to_ms duración del timeout de lectura. Tiempo que se espera para leer varios paquetes en una misma transacción (polling).
    errbuf es un bytearray donde se guardará un mensaje de error en caso de que algo haya fallado al abrir la interfaz.
    La función nos devuelve un descriptor al archivo .pcap o None/Excepción en caso de que haya algún error
    """
    errbuf = bytearray()
    handle = pcap_open_live(interface_name, ETH_FRAME_MAX, 1, TO_MS, errbuf)
    
    # Creamos y abrimos los dumpers necesarios ->Para guardar un archivo pcap necesitamos primero crear el archivo donde vamos a ir volcando los paquetes
    pcap_noIP_descr = pcap_open_dead(DLT_EN10MB, ETH_FRAME_MAX)
    pcap_IP_descr = pcap_open_dead(DLT_EN10MB, ETH_FRAME_MAX)
    dumper_noIP = pcap_dump_open(pcap_noIP_descr, file_noIP)
    dumper_IP = pcap_dump_open(pcap_IP_descr, file_IP)

    # Capturamos los paquetes en bucle utilizando funcion auxiliar -> FUNCION PARA LEER TRAFICO DE UN INTERFAZ
    """
    HANDLE es el descriptor PCAP del que queramos leer (que anteriormente hemos abierto con open_pcap_live o open_pcap_offline).
    MAX_PAQUETES es el número de paquetes a analizar (-1 para ilimitados).
    PROCESA_PAQUETE es una función de atención al paquete. Esta función se ejecutará por cada paquete leído o capturado.
    user es una variable auxiliar que sirve para pasar datos a la función de atención.
    pcap_loop nos devuelve:
         0 si se leyó la traza entera o se supero el límite cnt.
        -1 Si hubo errores
        -2 Si fue interrumpido por pcap_breakloop() (u otras).
        Otros valores si se capturó un paquete.
    """
    ret = pcap_loop(handle, max_paquetes, procesa_paquete, None)
    
    if ret == -1:
        logging.error('Error al capturar un paquete')
    elif ret == -2:
        logging.debug('pcap_breakloop() llamado')
    elif ret == 0:
        logging.debug('No hay más paquetes o límite superado')

    logging.info(f'{num_paquete} paquetes procesados')

    #Cerramos recursos al final
    pcap_close(handle)
    pcap_dump_close(dumper_noIP)
    pcap_dump_close(dumper_IP)
    
    
    
    
    
    
    
    
    
    
    """
    pcap_open_dead(linktype, snaplen)

        Donde

        linktype es el tipo de enlace de los paquetes que vamos a guardar. Típicamente, para redes Ethernet: DLT_EN10MB
        snaplen es el tamaño máximo que queramos guardar de cada paquete. Típicamente, para redes Ethernet, 1514 Bytes (ojo: puede haber jumboframes, más grandes).
        Devuelve, como las otras funciones pcap_open, un descriptor de archivo pcap.

        Ejemplo:  descr2 = pcap_open_dead(DLT_EN10MB,1514)  # Abre un descriptor de archivo pcap para paquetes Ethernet, guardando como máximo 1514 Bytes de cada paquete.



        pcap_dump_open(descr, fname)

        Donde

        descr es el descriptor de archivo pcap previamente abierto con pcap_open_dead.
        fname es una cadena con el nombre del archivo pcap en el que queramos guardar los paquetes.
        Devuelve un objeto dumper que se usará para guardar paquetes.

        Ejemplos:  pdumper = pcap_dump_open(descr2,'salida.pcap')

        Crea un archivo llamado salida.pcap con las características (tipo de enlace, y tamaño máximo de paquete) de descr2 (que indicamos en el pcap_open_dead). Nos devuelve un objeto dumper.  Para guardar paquetes en el archivo creado con pcap_dump_open usamos la función:  

        pcap_dump(dumper,h,sp)

        dumper es el dumper devuelto por pcap_dump_open.
        h es un objeto de tipo pcap_pkthdr con la cabecera pcap del paquete que vamos a guardar.
        sp es un bytearray con el contenido del paquete. Se van a guardar tantos bytes como indiquemos en el campo caplen del parámetro h.
        Ejemplo:  pcap_dump(pdumper,h,pkt_data)

        Guardamos en pdumper el paquete apuntado por packet con cabecera h.
    """
