#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 17:50:00 2022

@author: jlgd
"""
import struct
from builtins import bytes
import time

print('Hola mundo!')

#________________________________

def suma(param1, param2=2) :
	return param1+param2

a = 1
print('Ejemplo de IF')
if a == 1:
    print ('A vale 1')
else:
    pass

input('Pulsa Enter para continuar')

a=False
if a is not False:
    print ('A es verdadero')
elif a is False:
    print ('A es falso')
else:
    print ('?')



print('Ejemplo de bucle for con funcion range')
for i in range(1,10,2):
	print (str(i)+'\n')
a = 0
input('Pulsa Enter para continuar')




print('Ejemplo de bucle while')
while a<10:
    print (str(a)+'\n')
    a=a+2
input('Pulsa Enter para continuar')

print('Ejemplo de uso de funcion')
print(suma(1,7))





print('Ejemplo de uso de listas')
a = [1,2,3,4,5]
print ('la lista es: '+str(a))
longitud = len(a)
print('La longitud de la lista es: '+ str(longitud))
print('El primer elemento es '+str(a[0]))
a[0] = 0
print('cambiamos el primer elemento y ahora es '+str(a[0]))
print('El ultimo elemento es '+str(a[-1]))
print('Los elementos de la posicion 2 a la 4 son '+str(a[1:4]))
a = a[3:]
print('Quitamos los elementos 1 a 3 y la nueva lista es '+str(a))
a[0]=255


#_________________________________-


lista=[]
a = [1,2,3,4,5]
if (a == bytearray([1,2,3,4,5])):
    print('Distinto')
else:
    print('Igual')
#_________________________________-

a[0]=255
print('{:02X}'.format(a[0]))
print('{} {:02X}'.format(a[0],a[0]))

print(str(time.time()))

tim=str(time.time())
tim = tim.split('.')
print(tim[1]) 


b=bytes([255,0,255])
bytes.hex(b)

#__________________________________-

sourceport=1

cab_udp=[] # Lista de bytes
cab_udp[0:2]=struct.pack('!H',sourceport)
cab_udp[0:2]=struct.pack('H',sourceport)

sourceport=256

cab_udp=[] # Lista de bytes
cab_udp[0:2]=struct.pack('!H',sourceport)
cab_udp[0:2]=struct.pack('H',sourceport)


sourceport=258

cab_udp=[] # Lista de bytes
cab_udp[0:2]=struct.pack('!H',sourceport)
cab_udp[0:2]=struct.pack('H',sourceport)


BA=bytearray(cab_udp[0:2])

sourceport=struct.unpack('!H',BA)[0]  #!!!!!!!!!
sourceport
sourceport=struct.unpack('H',BA)[0]  #!!!!!!!!!
sourceport

#________________________________

numero0 = 0
numero1 = 1
numero2 = 2

mensaje = struct.pack('!HHII',0x8014,numero0,numero1,numero2)
mensaje2 = struct.pack('HHII',0x8014,numero0,numero1,numero2)


print ('El mensaje empaquetado es '+str(mensaje))
print ('El mensaje empaquetado es '+str(mensaje2))


#________________________________

