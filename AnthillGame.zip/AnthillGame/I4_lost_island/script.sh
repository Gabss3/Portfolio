#!/bin/bash

# Verificar los argumentos proporcionados
if [ $# -lt 1 ]; then
    exit 1
fi

# Obtener los argumentos
opcion=$1
fichero=$2

# Compilar y ejecutar todas las pruebas si no se proporciona un nombre de fichero
if [ -z "$fichero" ]; then
    
    for prueba in src/*_test.c; do
        # Extraer el nombre del fichero sin extensión
        fichero_sin_extension=$(basename $prueba .c)
        
        # Compilar el fichero
        make "$fichero_sin_extension"
        
        # Ejecutar el programa dependiendo de la opción proporcionada
        if [ "$opcion" -eq 0 ]; then
            ./$fichero_sin_extension
        elif [ "$opcion" -eq 1 ]; then
            valgrind --leak-check=full ./$fichero_sin_extension
        else
            echo "Opción inválida. Debe ser 0 o 1."
            exit 1
        fi
    done
else
    # Compilar el fichero indicado
    make "$fichero"
    
    # Ejecutar el programa dependiendo de la opción proporcionada
    if [ "$opcion" -eq 0 ]; then
        ./"$fichero"
    elif [ "$opcion" -eq 1 ]; then
        valgrind --leak-check=full ./$fichero
    else
        echo "Opción inválida. Debe ser 0 o 1."
        exit 1
    fi
fi
