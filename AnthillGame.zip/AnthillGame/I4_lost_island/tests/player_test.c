#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "player.h"
#include "player_test.h"
#include "test.h"
#include "object.h"


#define MAX_TESTS 34

/** 
 * @brief Main function for PLAYER unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module PLAYER:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }
  if (all || test == 1)  test1_player_create();
  if (all || test == 2)test2_player_create();
  if (all || test == 3) test1_player_destroy();
  if (all || test == 4) test2_player_destroy();
  if (all || test == 5) test1_player_get_id();
  if (all || test == 6) test2_player_get_id();
  if (all || test == 7) test1_player_get_name();
  if (all || test == 8) test2_player_get_name();
  if (all || test == 9) test1_player_get_location();
  if (all || test == 10) test2_player_get_location();
  if (all || test == 11) test1_player_find_object_inventory();
  if (all || test == 12) test2_player_find_object_inventory();
  if (all || test == 13) test1_player_get_health();
  if (all || test == 14) test2_player_get_health();
  if (all || test == 15) test1_player_set_id();
  if (all || test == 16) test2_player_set_id();
  if (all || test == 17) test1_player_set_name();
  if (all || test == 18) test2_player_set_name();
  if (all || test == 19) test1_player_set_location();
  if (all || test == 20) test2_player_set_location();
  if (all || test == 21) test1_player_set_object();
  if (all || test == 22) test2_player_set_object();
  if (all || test == 23) test1_player_set_health();
  if (all || test == 24) test2_player_set_health();
  if (all || test == 25) test1_player_delete_object();
  if (all || test == 26) test2_player_delete_object();
  if (all || test == 27) test1_player_get_inventory();
  if (all || test == 28) test2_player_get_inventory();
  if (all || test == 29) test1_player_set_inventory();
  if (all || test == 30) test2_player_set_inventory();
  

  

  PRINT_PASSED_PERCENTAGE;

  return 1;
}


void test1_player_create(){
  Player *p;
  p = player_create(5);
  PRINT_TEST_RESULT(player_destroy(p) == OK); 
 
}

void test2_player_create(){
  Player *p;
  int result;
  p = player_create(5);
  result = p != NULL;
  PRINT_TEST_RESULT(result);
  player_destroy(p);
 
}

void test1_player_destroy(){
  Player *p;
  p = player_create(5);
  PRINT_TEST_RESULT(player_destroy(p));
  
}

void test2_player_destroy(){
  Player *p = NULL;
  player_destroy(p);
   PRINT_TEST_RESULT(player_destroy(p) == ERROR);
}

void test1_player_get_id(){
  Player *p;
  p = player_create(5);
  
  PRINT_TEST_RESULT(player_get_id(p) == 5);
  player_destroy(p);
  
}

void test2_player_get_id(){
  Player *p=NULL;
  PRINT_TEST_RESULT(player_get_id(p) == NO_ID);
  
}

void test1_player_get_name(){
  Player *p;
  p = player_create(5);
  player_set_name(p, "adios");
  PRINT_TEST_RESULT(strcmp(player_get_name(p), "adios") == 0);
  player_destroy(p);
 
}

void test2_player_get_name(){
  Player *p=NULL;
  PRINT_TEST_RESULT(player_get_name(p)==NULL);
  player_destroy(p);
}

void test1_player_get_location(){
  Player *p;
  p = player_create(5);
  player_set_location(p,3);
  
  PRINT_TEST_RESULT(player_get_location(p) == 3);
  player_destroy(p);
  
}

void test2_player_get_location(){
  Player *p=NULL;
  PRINT_TEST_RESULT(player_get_location(p) == NO_ID);
  
}

void test1_player_find_object_inventory(){
  Player *p = NULL;
  Id id_obj = 3;
  p = player_create(3);
	player_set_object(p, id_obj);
  PRINT_TEST_RESULT( player_find_object_inventory(p, id_obj) == TRUE);
  player_destroy(p);
}

void test2_player_find_object_inventory(){
  Player *p = NULL;
  PRINT_TEST_RESULT( player_find_object_inventory(p, NO_ID) == FALSE);
  player_destroy(p);
}

void test1_player_get_health(){
  Player *p;
  p = player_create(5);
  player_set_health(p,4);
  PRINT_TEST_RESULT(player_get_health(p) == 4);
  player_destroy(p);
  
}

void test2_player_get_health(){
  Player *p=NULL;
  PRINT_TEST_RESULT(player_get_health(p) == -1);
  
}

void test1_player_set_id(){
  Player *p;
  p = player_create(6);
  
  PRINT_TEST_RESULT(player_set_id(p,8)==OK);
  player_destroy(p);
}

void test2_player_set_id(){
  Player *p;
  p = player_create(2);
  PRINT_TEST_RESULT(player_set_id(p, NO_ID)==ERROR);
  player_destroy(p);
  
}

void test1_player_set_name(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_set_name(p, "hola") == OK);
  player_destroy(p);
}
void test2_player_set_name(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_set_name(p, NULL) == ERROR);
  player_destroy(p);
}

void test1_player_set_location(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_set_location(p, 5) == OK);
  player_destroy(p);
}
void test2_player_set_location(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_set_location(p, NO_ID) == ERROR);
  player_destroy(p);
  
}

void test1_player_set_object(){
  Player *p=NULL;

  p = player_create(4);
  PRINT_TEST_RESULT(player_set_object(p,3)==OK);
  player_destroy(p);
  ;
  
  
}
void test2_player_set_object(){
  Player *p = NULL;
  p = player_create(5);
  PRINT_TEST_RESULT(player_set_object(p, NO_ID) == ERROR);
  player_destroy(p);
}

void test1_player_set_health(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_set_health(p, 4) == OK);
  player_destroy(p);
}
void test2_player_set_health(){
  Player *p=NULL;
  
  PRINT_TEST_RESULT(player_set_health(p, 3) == ERROR);
  player_destroy(p);
  
}

void test1_player_delete_object(){
  Player *p;
  Id id_obj = 3;
  p = player_create(3);

	player_set_object(p, id_obj);
  PRINT_TEST_RESULT( player_delete_object(p, id_obj) == OK);
  player_destroy(p);
  
}

void test2_player_delete_object(){
  Player *p=NULL;
  Id id_obj = NO_ID;
  PRINT_TEST_RESULT( player_delete_object(p, id_obj) == ERROR);
}

void test1_player_get_inventory(){
  Player *p;
  p = player_create(4);
  PRINT_TEST_RESULT(player_get_inventory(p)!=NULL);
  player_destroy(p);
}


void test2_player_get_inventory(){
  Player *p=NULL;
  PRINT_TEST_RESULT(player_get_inventory(p)==NULL);
}

void test1_player_set_inventory(){
  Player *p = NULL;
  Inventory *inv;
  p = player_create(3);
  inv = inventory_create();
  PRINT_TEST_RESULT(player_set_inventory(p,inv)==OK);
  player_destroy(p);
}

void test2_player_set_inventory(){
  Player *p = NULL;
  Inventory *inv = NULL;
  PRINT_TEST_RESULT(player_set_inventory(p,inv)==ERROR);
}

