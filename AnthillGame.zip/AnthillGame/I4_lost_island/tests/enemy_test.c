#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "enemy.h"
#include "enemy_test.h"
#include "test.h"

#define MAX_TESTS 43

int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Enemy:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }
  if (all || test == 1) test1_enemy_create();
  if (all || test == 2) test2_enemy_create();
  if (all || test == 3) test1_enemy_get_id();
  if (all || test == 4) test2_enemy_get_id();
  if (all || test == 5) test1_enemy_set_name();
  if (all || test == 6) test2_enemy_set_name();
  if (all || test == 7) test3_enemy_set_name();
  if (all || test == 8) test1_enemy_get_name();
  if (all || test == 9) test2_enemy_get_name();
  if (all || test == 10) test1_enemy_get_location();
  if (all || test == 11) test2_enemy_get_location();
  if (all || test == 12) test1_enemy_get_health ();
  if (all || test == 13) test2_enemy_get_health ();
  if (all || test == 14) test1_enemy_set_location();
  if (all || test == 15) test2_enemy_set_location();
  if (all || test == 16) test1_enemy_set_health();
  if (all || test == 17) test2_enemy_set_health();
  if (all || test == 18) test1_enemy_destroy();
  if (all || test == 18) test2_enemy_destroy();
  if (all || test == 19) test1_enemy_set_id();
  if (all || test == 20) test2_enemy_set_id();
  
  
  


  PRINT_PASSED_PERCENTAGE;

  return 1;

}

void test1_enemy_create(){
  int result;
  Enemy *e;
  e=enemy_create(6);
  result=e!=NULL;
  PRINT_TEST_RESULT(result);
  enemy_destroy(e);
}
void test2_enemy_create(){
  Enemy *e;
  e=enemy_create(5);
  PRINT_TEST_RESULT(enemy_get_id(e)==5);
  enemy_destroy(e);
}
void test1_enemy_get_id(){
  Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_get_id(e)==6);
  enemy_destroy(e);
}
void test2_enemy_get_id(){
  Enemy*e=NULL;
  PRINT_TEST_RESULT(enemy_get_id(e)==NO_ID);
}
void test1_enemy_set_name(){
  Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_set_name(e, "hola")==OK);
  enemy_destroy(e);
}
void test2_enemy_set_name(){
  Enemy*e=NULL;
  PRINT_TEST_RESULT(enemy_set_name(e, "hola")==ERROR);
}
void test3_enemy_set_name(){
  Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_set_name(e, NULL)==ERROR);
  enemy_destroy(e);
}

void test1_enemy_get_name(){
  Enemy *e;
  e = enemy_create(1);
  enemy_set_name(e, "hola");
  PRINT_TEST_RESULT(strcmp(enemy_get_name(e), "hola") == 0);
  enemy_destroy(e);
}
void test2_enemy_get_name(){
  Enemy *e=NULL;
  PRINT_TEST_RESULT(enemy_get_name(e)==NULL);
}

void test1_enemy_get_location(){
  Enemy *e;
  e=enemy_create(6);
  enemy_set_location(e, 3);
  PRINT_TEST_RESULT(enemy_get_location(e)==3);
  enemy_destroy(e);

}
void test2_enemy_get_location(){
  Enemy *e=NULL;
  PRINT_TEST_RESULT(enemy_get_location(e)==NO_ID);
}

void test1_enemy_get_health (){
  Enemy *e;
  e=enemy_create(6);
  enemy_set_health(e, 2);
  PRINT_TEST_RESULT(enemy_get_health(e)==2);
  enemy_destroy(e);
}
void test2_enemy_get_health (){
  Enemy *e=NULL;
  PRINT_TEST_RESULT(enemy_get_location(e)==-1);
}

void test1_enemy_set_location(){
  Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_set_location(e, 5)==OK);
  enemy_destroy(e);
}
void test2_enemy_set_location(){
  Enemy *e=NULL;
  PRINT_TEST_RESULT(enemy_set_location(e, 4)==ERROR);
}


void test1_enemy_set_health(){
  Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_set_health(e, 5)==OK);
  enemy_destroy(e);
}
void test2_enemy_set_health(){
  Enemy *e=NULL;
  PRINT_TEST_RESULT(enemy_set_health(e, 4)==ERROR);
}

void test1_enemy_destroy(){
  Enemy *e=NULL;
  e= enemy_create(2);
  PRINT_TEST_RESULT(enemy_destroy(e));

}

void test2_enemy_destroy() {
  Enemy *e = NULL;;
  PRINT_TEST_RESULT(enemy_destroy(e) == OK);
}

void test1_enemy_set_id(){
   Enemy *e;
  e=enemy_create(6);
  PRINT_TEST_RESULT(enemy_get_id(e) == 6);
  enemy_destroy(e);

  
}

void test2_enemy_set_id(){
  Enemy *e = NULL;
  PRINT_TEST_RESULT(enemy_set_id(e, 6)==ERROR);

}
