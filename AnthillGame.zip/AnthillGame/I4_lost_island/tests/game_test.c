/** 
 * @brief It tests game module
 * 
 * @file game_test.c
 * @author Noelia Rincón Roldán
 * @version 0.2 
 * @date 4-05-2023
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "game_test.h"
#include "game.h"
#include "types.h"
#include "test.h"

#define MAX_TESTS 57

/** 
 * @brief Main function for GAME unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Game:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }

  
  
  if (all || test == 1) test1_game_create();
  if (all || test == 2) test1_game_destroy();
  if (all || test == 3) test2_game_destroy();
  if (all || test == 4) test1_game_add_space();
  if (all || test == 5) test2_game_add_space();
  if (all || test == 6) test1_game_get_space();
  if (all || test == 7) test2_game_get_space();
  if (all || test == 8) test1_game_get_link();
  
  if (all || test == 9) test2_game_get_link();
  if (all || test == 10) test1_game_get_link_by_name();
  if (all || test == 11) test2_game_get_link_by_name();
  if (all || test == 12) test1_game_get_connection(); 
  if (all || test == 13) test2_game_get_connection();
  if (all || test == 14) test1_game_get_connection_status();
  if (all || test == 15) test2_game_get_connection_status();
  if (all || test == 16) test1_game_add_link();
  if (all || test == 17) test2_game_add_link();
  if (all || test == 18) test1_game_get_player();
  if (all || test == 19) test2_game_get_player();
  if (all || test == 20) test1_game_add_player();
  if (all || test == 21) test2_game_add_player();
  if (all || test == 22) test1_game_get_player_location();
  
  if (all || test == 23) test2_game_get_player_location();
  if (all || test == 24) test1_game_get_enemy();
  if (all || test == 25) test2_game_get_enemy();
  if (all || test == 26) test1_game_add_enemy();
  if (all || test == 27) test2_game_add_enemy();
  if (all || test == 28) test1_game_add_object();
  if (all || test == 29) test2_game_add_object();
  if (all || test == 30) test1_game_get_object_location();
  if (all || test == 31) test2_game_get_object_location();
  if (all || test == 32) test1_game_set_object_location();
  if (all || test == 33) test2_game_set_object_location();
  if (all || test == 34) test1_game_get_object();
  if (all || test == 35) test2_game_get_object();
  if (all || test == 36) test1_game_get_objects_ids();

  if (all || test == 37) test2_game_get_objects_ids();
  if (all || test == 38) test1_game_get_object_by_name();
  if (all || test == 39) test2_game_get_object_by_name();
  if (all || test == 40) test1_game_get_last_command();
  if (all || test == 41) test2_game_get_last_command();
  if (all || test == 42) test1_game_get_st();
  if (all || test == 43) test2_game_get_st();
  if (all || test == 44) test1_game_get_act_description();
  if (all || test == 45) test2_game_get_act_description();
  if (all || test == 46) test1_game_set_act_description();
  if (all || test == 47) test2_game_set_act_description();
  if (all || test == 48) test1_game_update();
  if (all || test == 49) test2_game_update();
  if (all || test == 50) test1_game_get_dialogue();
  if (all || test == 51) test1_game_get_dialogue();
  if (all || test == 52) test1_game_get_space_id_at();
  if (all || test == 53) test2_game_get_space_id_at();
  if (all || test == 54) test1_game_set_connection_status();
  if (all || test == 55) test2_game_set_connection_status();
  if (all || test == 56) test1_game_is_over();
  if (all || test == 57) test2_game_is_over();
  
  
  

  PRINT_PASSED_PERCENTAGE;

  return 1;
}


void test1_game_create(){
  int result;
  Game *game;
  game = game_create();
  result=game!=NULL ;
  PRINT_TEST_RESULT(result);
  game_destroy(game);  
  
  
}


void test1_game_destroy(){
  Game *game;
  game = game_create();
  PRINT_TEST_RESULT(game_destroy(game)==OK);
  
}
void test2_game_destroy(){
  Game *game=NULL;
  PRINT_TEST_RESULT(game_destroy(game)==OK);
}

void test1_game_add_space(){
  Game *game;
  Space *sp;
  game = game_create();
  sp = space_create(3);
  PRINT_TEST_RESULT(game_add_space(game,sp)==OK);
  game_destroy(game);
  
}
void test2_game_add_space(){
  Game *game;
  game = game_create();
  PRINT_TEST_RESULT(game_add_space(game, NULL)==ERROR);
  game_destroy(game);  
  
}

void test1_game_get_space(){
  Game *game;
  Space *sp;
  game = game_create();
  sp = space_create(2);
  game_add_space(game, sp);
  PRINT_TEST_RESULT(game_get_space(game,space_get_id(sp))==sp);
  game_destroy(game);
  
  
}
void test2_game_get_space(){
  Game *game=NULL;
  PRINT_TEST_RESULT(game_get_space(game,2)==NULL);
  
}

void test1_game_get_link(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(2);
  game_add_link(g, l);
  PRINT_TEST_RESULT(game_get_link(g,2)==l);
  game_destroy(g);
  
}
void test2_game_get_link(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_link(g,NO_ID)==NULL);
  
}

void test1_game_get_link_by_name(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(2);
  link_set_name(l, "hola");
  game_add_link(g,l);
  PRINT_TEST_RESULT(game_get_link_by_name(g, link_get_name(l))==l);
  game_destroy(g);
}
void test2_game_get_link_by_name(){
  Game *g = NULL;

  PRINT_TEST_RESULT(game_get_link_by_name(g, NULL)==NULL);
  
}

void test1_game_get_connection(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(45);
  link_set_origin(l, 3);
  link_set_destination(l, 2);
  link_set_direction(l, S);
  link_set_status(l, OPEN);
  game_add_link(g, l);
  PRINT_TEST_RESULT(game_get_connection(g, 3,S) == 2);
  game_destroy(g);
  
}
void test2_game_get_connection(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_connection(g, NO_ID,NO_DIRECTION) == NO_ID);
  
  
}
void test1_game_get_connection_status(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(45);
  link_set_origin(l, 3);
  link_set_destination(l, 2);
  link_set_direction(l, S);
  link_set_status(l, OPEN);
  game_add_link(g, l);
  game_set_connection_status(g, link_get_origin(l),link_get_direction(l),link_get_status(l));
  PRINT_TEST_RESULT(game_get_connection_status(g, 3,S) == OPEN);
  game_destroy(g);
  
}
void test2_game_get_connection_status(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_connection_status(g, NO_ID,NO_DIRECTION) == -1);
  
}

void test1_game_add_link(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(2);
  PRINT_TEST_RESULT(game_add_link(g, l));
  game_destroy(g);
}
void test2_game_add_link(){
  Game *g = NULL;
  Link *l;
  l = link_create(2);
  PRINT_TEST_RESULT(game_add_link(g, l) == ERROR);
  link_destroy(l);
  
}

void test1_game_get_player(){
  Game *g;
  Player *p;
  g = game_create();
  p = player_create(2);
  game_add_player(g, p);
  PRINT_TEST_RESULT(game_get_player(g)==p);
  game_destroy(g);
  
}
void test2_game_get_player(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_player(g) == NULL);
  
}

void test1_game_add_player(){
  Game *g;
  Player *p ;
  g = game_create();
  p = player_create(2);
  PRINT_TEST_RESULT(game_add_player(g, p) == OK);
  game_destroy(g);
  
}
void test2_game_add_player(){
  Game *g = NULL;
  Player *p = NULL;
  PRINT_TEST_RESULT(game_add_player(g, p) == ERROR);

  
}

void test1_game_get_player_location(){
  Game* game;
  Player* p;
  game = game_create();
  p = player_create(1);
  player_set_location(p, 2);
  game_add_player(game, p);
  PRINT_TEST_RESULT(game_get_player_location(game) == 2);
  game_destroy(game);
  
}
void test2_game_get_player_location(){
  Game *game = NULL;
  PRINT_TEST_RESULT(game_get_player_location(game) == NO_ID);  
}

void test1_game_get_enemy(){
  Game *g;
  Enemy *e;
  g = game_create();
  e = enemy_create(2);
  game_add_enemy(g, e);
  PRINT_TEST_RESULT(game_get_enemy(g)==e);
  game_destroy(g);
  
}
void test2_game_get_enemy(){
  Game* game = NULL;
  PRINT_TEST_RESULT(game_get_enemy(game) == NULL);
  
}

void test1_game_add_enemy(){
  Game *g;
  Enemy *e;
  g = game_create();
  e = enemy_create(2);
  PRINT_TEST_RESULT(game_add_enemy(g, e)==OK);
  game_destroy(g);  
  
}
void test2_game_add_enemy(){
  Game *g =NULL;
  Enemy *e = NULL;
  PRINT_TEST_RESULT(game_add_enemy(g, e)==ERROR);
}


void test1_game_add_object(){
  Game* game;
  Object* object;
  game = game_create();
  object = object_create(3);
  PRINT_TEST_RESULT(game_add_object(game, object) == OK);
  game_destroy(game);
  
}
void test2_game_add_object(){
  Game* game=NULL;
  Object* object=NULL;
  PRINT_TEST_RESULT(game_add_object(game, object) == ERROR);
  
}
void test1_game_get_object_location(){
   Game *g;
  Object *o;
  Space *s;
  g = game_create();
  o = object_create(3);
  s = space_create(2);
  game_add_object(g, o);
  game_add_space(g, s);
  game_set_object_location(g, 2, 3);
  space_set_object(s, 3);
  PRINT_TEST_RESULT(game_get_object_location(g, 3) == 2);
  game_destroy(g);
}
void test2_game_get_object_location(){
  Game* game = NULL;
  PRINT_TEST_RESULT(game_get_object_location(game, NO_ID) == NO_ID);
}

void test1_game_set_object_location(){
  Game *g;
  Object *o;
  g = game_create();
  o = object_create(3);
  game_add_object(g, o);
  PRINT_TEST_RESULT(game_set_object_location(g, 2, 3) == OK);
  game_destroy(g);
  
}
void test2_game_set_object_location(){
  Game* g = NULL;
  PRINT_TEST_RESULT(game_set_object_location(g, 2, 3) == ERROR);
  
}

void test1_game_get_object(){
  Game *g;
  Object *o;
  g = game_create();
  o = object_create(4);
  game_add_object(g, o);
  PRINT_TEST_RESULT(game_get_object(g,4)==o);
  game_destroy(g);
  
}
void test2_game_get_object(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_object(g,4)==NULL);  
}

void test1_game_get_objects_ids(){
  Game* g;
  Object* o;
  Id* ids;
  g = game_create();
  o = object_create(3);
  ids = (Id*) malloc(MAX_SET_IDS * sizeof(Id));
  game_add_object(g, o);
  game_set_object_location(g, 2, 3);
  PRINT_TEST_RESULT(game_get_objects_ids(g, ids) == OK);
  free(ids);
  game_destroy(g);
  
}
void test2_game_get_objects_ids(){
  Game *g = NULL;
  Id* ids;
  ids = (Id*) malloc(MAX_SET_IDS * sizeof(Id));
  PRINT_TEST_RESULT(game_get_objects_ids(g, ids) == ERROR);
  free(ids);
  game_destroy(g);
  
  
}

void test1_game_get_object_by_name(){
  Game *g;
  Object *o;
  g = game_create();
  o = object_create(3);
  object_set_name(o, "object");
  game_add_object(g,o);
  game_set_object_location(g, 2,3);
  PRINT_TEST_RESULT(game_get_object_by_name(g,"object")==o);
  game_destroy(g);
  
}
void test2_game_get_object_by_name(){
  Game *g = NULL;
  Object *o;
  o = object_create(3);
  object_set_name(o, "object");
  PRINT_TEST_RESULT(game_get_object_by_name(g, "object")==NULL);
  object_destroy(o);
}

void test1_game_get_last_command(){
  Game *g;
  g = game_create();
  PRINT_TEST_RESULT(game_get_last_command(g)==NO_CMD);
  game_destroy(g);
  
}
void test2_game_get_last_command(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_last_command(g)==NO_CMD);
  
}

void test1_game_get_st(){
  Game *g;
  g = game_create();
  PRINT_TEST_RESULT(game_get_st(g)==OK);
  game_destroy(g);
}
void test2_game_get_st(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_st(g)==ERROR);

}

void test1_game_get_act_description(){
  Game *g;
  g = game_create();
  game_set_act_description(g, "desc");
  PRINT_TEST_RESULT(strcmp (game_get_act_description(g), "desc") == 0);
  game_destroy(g);
  
}
void test2_game_get_act_description(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_act_description(g)==NULL);
}

void test1_game_set_act_description(){
  Game *g;
  g = game_create();
  PRINT_TEST_RESULT(game_set_act_description(g ,"desc")==OK);
  game_destroy(g);
  
}
void test2_game_set_act_description(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_set_act_description(g,"desc")==ERROR);
  
}

void test1_game_update(){
  Game *g;
  g = game_create();
  PRINT_TEST_RESULT(game_update(g,UP) == OK);
  game_destroy(g);
  
}
void test2_game_update(){
  Game *g;
  g = game_create();
  PRINT_TEST_RESULT(game_update(g,NO_CMD)!=ERROR);
  game_destroy(g);
}


void test1_game_get_dialogue(){
  Game*g;
  g = game_create();
 
  PRINT_TEST_RESULT(game_get_dialogue(g)!=NULL);
}
void test2_game_get_dialogue(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_get_dialogue(g)==NULL);
}


void test1_game_get_space_id_at(){
  Game *g;
  Space *sp;
  g = game_create();
  sp = space_create(2);
  game_add_space(g, sp);
  PRINT_TEST_RESULT(game_get_space_id_at(g, 0)==space_get_id(sp));
  game_destroy(g);
}
void test2_game_get_space_id_at(){
  Game *g=NULL;
  PRINT_TEST_RESULT(game_get_space_id_at(g,-1) == NO_ID);
}

void test1_game_set_connection_status(){
  Game *g;
  Link *l;
  g = game_create();
  l = link_create(2);
  link_set_origin(l, 1);
  link_set_destination(l, 2);
  link_set_status(l, OPEN);
  link_set_direction(l, S);
  game_add_link(g,l);
  PRINT_TEST_RESULT(game_set_connection_status(g, link_get_origin(l), S, OPEN)==OK);
  game_destroy(g); 
}

void test2_game_set_connection_status(){
  Game *g=NULL;
  game_create();
  PRINT_TEST_RESULT(game_set_connection_status(g, 1, S, OPEN)==ERROR);

  
}


void test1_game_is_over(){
  Game *g;
  Player* p;
  g = game_create();
  p = player_create(2);
  game_add_player(g, p);
  player_set_health(game_get_player(g), -1);
  PRINT_TEST_RESULT(game_is_over(g) == FALSE);
  game_destroy(g);
  
}
void test2_game_is_over(){
  Game *g = NULL;
  PRINT_TEST_RESULT(game_is_over(g) == FALSE);
  
}



