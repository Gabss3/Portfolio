/**
 * @brief Testea el módulo game_management
 *
 * @file game_management_test.c
 * @author Noelia Rincón
 * @version 3.0
 * @date 05-04-2022
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "command.h"
#include "command_test.h"
#include "test.h"



/*
The command module only consists in a function "T_Command command_get_user_input()" that gets the user's input and compare it with the commands created and returns the command, if it exists. It cannot be tested as the other functions in the other modules. The inform test of this function can be done by understanding it. If we tested it we could identify 3 different cases.
* 1) if the user's imput is valid the program identifys correctly the corresponding command and the program executes correctly the inputed command.
* 2) if the user's imput is not valid the program identifys correctly the corresponding unknown  command and returns NO_CMD.
* 3) if the user's imput is empty the program identifys correctly the corresponding unknown  command and returns NO_CMD

*/