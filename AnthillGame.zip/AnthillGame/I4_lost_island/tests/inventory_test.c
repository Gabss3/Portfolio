/** 
 * @brief It tests inventory module
 * 
 * @file inventory_test.c
 * @author Blanca Matas Gavira
 * @version 0.2 
 * @date 23-03-2023
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "inventory.h"
#include "set.h"
#include "inventory_test.h"
#include "test.h"

#define MAX_TESTS 27

/** 
 * @brief Main function for INVENTORY unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Inventory:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }

  if (all || test == 1) test1_inventory_create();
  if (all || test == 2) test2_inventory_create();
  if (all || test == 3) test1_inventory_destroy();
  if (all || test == 4) test2_inventory_destroy();
  if (all || test == 5) test1_inventory_set_obj();
  if (all || test == 6) test2_inventory_set_obj();
  if (all || test == 7) test1_inventory_get_objs();
  if (all || test == 8) test2_inventory_get_objs();
  if (all || test == 9) test1_inventory_get_maxobjs();
  if (all || test == 10) test2_inventory_get_maxobjs();
  if (all || test == 11) test1_inventory_del_object();
  if (all || test == 12) test2_inventory_del_object();
  if (all || test == 13) test1_inventory_find_object();
  if (all || test == 14) test2_inventory_find_object();
  

  PRINT_PASSED_PERCENTAGE;

  return 1;
}



void test1_inventory_create() {
  Inventory *inv;
  inv = inventory_create();
  PRINT_TEST_RESULT(inventory_destroy(inv) == OK);
}

void test2_inventory_create() { 
  int result;
  Inventory *inv;
  inv = inventory_create();
  result=inv!=NULL ;
  PRINT_TEST_RESULT(result);
  inventory_destroy(inv);
}



void test1_inventory_destroy() {
  Inventory *inv;
  inv = inventory_create();
  PRINT_TEST_RESULT(inventory_destroy(inv));
}


void test2_inventory_destroy() {
  Inventory *inv = NULL;
  inventory_destroy(inv);
  PRINT_TEST_RESULT(inventory_destroy(inv) == ERROR);
}


void test1_inventory_set_obj(){
  Inventory *inv=NULL;
  Id id=1;
  inv = inventory_create();
  
  PRINT_TEST_RESULT(inventory_set_obj(inv, id) == OK);
  inventory_destroy(inv);
}

void test2_inventory_set_obj(){
   Inventory *inv = NULL;
  PRINT_TEST_RESULT(inventory_set_obj(inv, NO_ID) == ERROR);
  inventory_destroy(inv);
}


void test1_inventory_get_objs(){
  Inventory *inv;
  inv = inventory_create();
  PRINT_TEST_RESULT(inventory_get_objs(inv) != NULL);
  inventory_destroy(inv);
  
}

void test2_inventory_get_objs(){
  Inventory *inv = NULL;

  PRINT_TEST_RESULT(inventory_get_objs(inv) == NULL);
  
}

void test1_inventory_get_maxobjs(){
  Inventory *inv = NULL;
  inv = inventory_create();
  PRINT_TEST_RESULT(inventory_get_maxobjs(inv) != -1);
  inventory_destroy(inv);
}

void test2_inventory_get_maxobjs(){
  Inventory *inv = NULL;

  PRINT_TEST_RESULT(inventory_get_maxobjs(inv) == -1);
 
}

void test1_inventory_del_object(){
  Inventory *inv;
  inv = inventory_create();
  inventory_set_obj(inv,3);
  PRINT_TEST_RESULT(inventory_del_object(inv, 3) == OK);
  inventory_destroy(inv);
  
}

void test2_inventory_del_object(){
  Inventory *inv = NULL;
  inventory_set_obj(inv,3);
  PRINT_TEST_RESULT(inventory_del_object(inv, 5) == ERROR);

}



void test1_inventory_find_object(){
  Inventory *inv;
  inv = inventory_create();
  inventory_set_obj(inv, 5);
  PRINT_TEST_RESULT(inventory_find_object(inv, 5) == TRUE);
  inventory_del_object(inv, 5);
  inventory_destroy(inv);
  
}

void test2_inventory_find_object(){
  Inventory *inv = NULL;
  PRINT_TEST_RESULT(inventory_find_object(inv, -1) == FALSE );
  inventory_destroy(inv);

}



