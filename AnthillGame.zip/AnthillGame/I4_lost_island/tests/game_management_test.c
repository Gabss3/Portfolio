/**
 * @brief tests the game_management module
 *
 * @file game_management_test.c
 * @author Noelia Rincón
 * @version 3.0
 * @date 05-04-2022
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "game_management.h"
#include "game_management_test.h"
#include "test.h"
#include "game.h"

#define MAX_TESTS 21

/** 
 * @brief Main function for GAME_MANAGEMENT unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char **argv)
{

  int test = 0;
  int all = 1;

  if (argc < 2)
  {
    printf("Running all test for module Game_management:\n");
  }
  else
  {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS)
    {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }

  if (all || test == 1) test1_game_management_load_spaces();
  if (all || test == 2) test2_game_management_load_spaces();
  if (all || test == 3) test1_game_management_load_objects();
  if (all || test == 4) test2_game_management_load_objects();
  if (all || test == 5) test1_game_management_load_enemy();
  if (all || test == 6) test2_game_management_load_enemy();
  if (all || test == 7) test1_game_management_load_player();
  if (all || test == 8) test2_game_management_load_player();
  if (all || test == 9) test1_game_management_load_links();
  if (all || test == 10) test2_game_management_load_links();
  if (all || test == 11) test1_game_management_save();
  if (all || test == 12) test2_game_management_save();


  PRINT_PASSED_PERCENTAGE;

  return 1;
}

void test1_game_management_load_spaces() {
  Game* game;
  game = game_create();
  PRINT_TEST_RESULT(game_management_load_spaces(game, "lost_island.dat") == OK);
  game_destroy(game);
}

void test2_game_management_load_spaces(){
  Game* game = NULL;
  PRINT_TEST_RESULT(game_management_load_spaces(game, "hola") == ERROR);
}


void test1_game_management_load_objects(){
  Game* game;
  game = game_create();
  PRINT_TEST_RESULT(game_management_load_objects(game, "lost_island.dat") == OK);
  game_destroy(game);
}

void test2_game_management_load_objects() {
  Game* game = NULL;
  PRINT_TEST_RESULT(game_management_load_objects(game, "lost_island.dat") == ERROR);
}


void test1_game_management_load_enemy() {
  Game* game;
  game = game_create();
  PRINT_TEST_RESULT(game_management_load_enemy(game, "lost_island.dat") == OK);
  game_destroy(game);
}

void test2_game_management_load_enemy() {
  Game* game = NULL;
  PRINT_TEST_RESULT(game_management_load_enemy(game, "lost_island.dat") == ERROR);
}


void test1_game_management_load_player() {
  Game* game;
  game = game_create();
  PRINT_TEST_RESULT(game_management_load_player(game, "lost_island.dat") == OK);
  game_destroy(game);
}

void test2_game_management_load_player() {
  Game* game = NULL;
  PRINT_TEST_RESULT(game_management_load_player(game, "hola") == ERROR);
}


void test1_game_management_load_links() {
  Game* game;
  game = game_create();
  PRINT_TEST_RESULT(game_management_load_links(game, "lost_island.dat") == OK);
  game_destroy(game);
}

void test2_game_management_load_links() {
  Game* game = NULL;
  PRINT_TEST_RESULT(game_management_load_links(game, "lost_island.dat") == ERROR);
}


void test1_game_management_save() {
  Game* game;
  char *pf = "lost_island.dat";
  game = game_create();
  PRINT_TEST_RESULT(game_management_save(game, pf) == OK);
  game_destroy(game);
}

void test2_game_management_save() {
  Game* game;
  char *pf = NULL;
  game = game_create();
  PRINT_TEST_RESULT(game_management_save(game, pf) == ERROR);
  game_destroy(game);
}
