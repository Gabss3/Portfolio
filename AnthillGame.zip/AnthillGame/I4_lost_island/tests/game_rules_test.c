/** 
 * @brief It tests game_rules module
 * 
 * @file game_rules_test.c
 * @author Noelia Rincón Roldán
 * @version 0.2 
 * @date 7-05-2023
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h>
#include <time.h>
#include "game_rules_test.h"
#include "game.h"
#include "game_rules.h"
#include "types.h"
#include "test.h"

#define MAX_TESTS 18

/** 
 * @brief Main function for GAME_RULES unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Game_rules:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }

  

  if (all || test == 1) test1_gm_player_at_cherry();
  if (all || test == 2) test2_gm_player_at_cherry();
  if (all || test == 3) test1_gm_cherry_hidden();
  if (all || test == 4) test2_gm_cherry_hidden();
 /* if (all || test == 5) test1_gm_escaped_message();
  if (all || test == 6) test2_gm_escaped_message(); 
  if (all || test == 7) test1_gm_killed_message();
  if (all || test == 8) test2_gm_killed_message();
  if (all || test == 9) test1_gm_volcano_message();
  if (all || test == 10) test2_gm_volcano_message();
*/
  
  /*There can only be made the test of the two first functions, because the other three use sprintf and a char pointer to a string, so we cannot initialize that pointer and as a result, we cannot test the functions. There are also functions that are type void, and we cannot test them either because of that */

  PRINT_PASSED_PERCENTAGE;

  return 1;
}



  void test1_gm_player_at_cherry(){
    Game *g;
    Player *p;
    Object *o;
    g =game_create();
    p = player_create(2);
    o = object_create(2);
    object_set_name(o, "cherry");
    player_set_location(p,2);
    game_add_object(g, o);
    game_add_player(g, p);
    game_set_object_location(g, 2, 2);
    PRINT_TEST_RESULT(gm_player_at_cherry(g)==FALSE);
    
  }
  void test2_gm_player_at_cherry(){
    Game *g=NULL;
    PRINT_TEST_RESULT(gm_player_at_cherry(g)==FALSE);
    
  }
  void test1_gm_cherry_hidden(){
    Game *g;
    Object *o;
    g = game_create();
    o = object_create(2);
    object_set_hidden(o, TRUE);
    object_set_name(o, "cherry");
    game_add_object(g, o);
    PRINT_TEST_RESULT(gm_cherry_hidden(g)==TRUE);
    game_destroy(g);
  }
  void test2_gm_cherry_hidden(){
    Game *g=NULL;
    PRINT_TEST_RESULT(gm_cherry_hidden(g)==FALSE);
    
  }
  
  
  /*
  void test1_gm_escaped_message(){
    Game *g;
    Player *p;
    char *str = NULL;
    g = game_create();
    p = player_create(2);
    game_add_player(g, p);
    game_set_player_location(g, 6);
    PRINT_TEST_RESULT(gm_escaped_message(g,str)==OK);
    game_destroy(g);
    
  }
  void test2_gm_escaped_message(){
    Game *g = NULL;
    char *str ;
    PRINT_TEST_RESULT(gm_escaped_message(g,str)==ERROR);
    
    
  }
  void test1_gm_killed_message(){
    Game *g;
    Player *p;
    char *str;
    g = game_create();
    p = player_create(2);
    player_set_health(p, 0);
    game_add_player(g, p);
    PRINT_TEST_RESULT(gm_killed_message(g, str)==OK);
    game_destroy(g);
  }
  void test2_gm_killed_message(){
    Game *g = NULL;
    char *str ;
    PRINT_TEST_RESULT(gm_killed_message(g, str)==ERROR);
    
  }
  void test1_gm_volcano_message(){
     Game *g;
    Player *p;
    char *str;
    g = game_create();
    p = player_create(2);
    game_add_player(g, p);
    game_set_player_location(g, 29);
    PRINT_TEST_RESULT(gm_volcano_message(g,str)==OK);
    game_destroy(g);
    
  }
  void test2_gm_volcano_message(){
    Game *g = NULL;
    char *str ;
    PRINT_TEST_RESULT(gm_volcano_message(g, str)==ERROR);
    
    
  }
 */



