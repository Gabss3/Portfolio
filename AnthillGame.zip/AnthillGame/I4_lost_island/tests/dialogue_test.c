
/** 
 * @brief It tests dialogue module
 * 
 * @file dialogue_test.c
 * @author Noelia Rincón Roldán
 * @version 0.2 
 * @date 4-05-2023
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

#include "dialogue.h"
#include "dialogue_test.h"
#include "test.h"

#define MAX_TESTS 43

/** 
 * @brief Main function for DIALOGUE unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Dialogue:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }
  if (all || test == 1) test1_dialogue_create();
  if (all || test == 1) test1_dialogue_destroy();
  
  
  
  PRINT_PASSED_PERCENTAGE;

  return 1;

}

void test1_dialogue_create(){
  int result;
  Dialogue *d = NULL;
  d = dialogue_create();
  result=d!=NULL ;
  PRINT_TEST_RESULT(result);
  dialogue_destroy(d);   

}

void test1_dialogue_destroy(){
  Dialogue *d = NULL;
  d = dialogue_create();
  PRINT_TEST_RESULT(dialogue_destroy(d));

}

/*********
There can only be made the test of the two first functions, the dialogue_string function has been tested in a different file where it worked correctly. Its uses can also be seen in the implementation of the main every time the player does an action. 

*******************/




