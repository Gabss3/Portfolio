/**
 * @brief It tests object module
 *
 * @file object_test.c
 * @author Noelia Rincón Roldán
 * @version 3.0
 * @date 09-03-2021
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "object.h"
#include "object_test.h"
#include "types.h"
#include "test.h"


#define MAX_TESTS 45

/**
 * @brief Main function for SPACE unit tests.
 *
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed
 *   2.- A number means a particular test (the one identified by that number)
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Object:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }


  if (all || test == 1) test1_object_create();
  if (all || test == 2) test2_object_create();
  if (all || test == 3) test1_object_destroy();
  if (all || test == 4) test2_object_destroy();
  if (all || test == 5) test1_object_set_id();
  if (all || test == 6) test2_object_set_id();
  if (all || test == 6) test1_object_get_id();
  if (all || test == 7) test2_object_get_id();
  if (all || test == 8) test1_object_set_name();
  if (all || test == 9) test2_object_set_name();
  if (all || test == 10) test1_object_get_name();
  if (all || test == 11) test2_object_get_name();
  if (all || test == 12) test1_object_set_description();
  if (all || test == 13) test2_object_set_description();
  
  if (all || test == 14) test1_object_get_description();
  if (all || test == 15) test2_object_get_description();
  
  if (all || test == 16) test1_object_del_obj_name();
  if (all || test == 17) test2_object_del_obj_name();
  if (all || test == 18) test1_object_has_light();
  if (all || test == 19) test2_object_has_light();
  if (all || test == 20) test1_object_set_light();
  if (all || test == 21) test2_object_set_light();
  if (all || test == 22) test1_object_is_hidden();
  if (all || test == 23) test2_object_is_hidden();
  if (all || test == 24) test1_object_set_hidden();
  if (all || test == 25) test2_object_set_hidden();
  if (all || test == 26) test1_object_is_movable();
  if (all || test == 27) test2_object_is_movable();
  if (all || test == 28) test1_object_set_movable();
  if (all || test == 29) test2_object_set_movable();
  if (all || test == 30) test1_object_is_dependent();
  if (all || test == 31) test2_object_is_dependent();
  if (all || test == 32) test1_object_set_dependency();
  if (all || test == 33) test2_object_set_dependency();
  if (all || test == 34) test1_object_can_open();
  if (all || test == 35) test2_object_can_open();
  if (all || test == 36) test1_object_set_open();
  if (all || test == 37) test2_object_set_open();
  if (all || test == 38) test1_object_get_open();
  if (all || test == 39) test2_object_get_open();
  if (all || test == 40) test1_object_is_turnedon();
  if (all || test == 41) test2_object_is_turnedon();
  if (all || test == 42) test1_object_set_turnedon();
  if (all || test == 43) test2_object_set_turnedon();
  if (all || test == 44) test1_object_find_dependence();
  if (all || test == 45) test2_object_find_dependence();

  
  
  
  
  
  
  PRINT_PASSED_PERCENTAGE;

  return 1;
}

void test1_object_create() {
  int result;
  Object *o;
  o = object_create(5);
  result=o!=NULL ;
  PRINT_TEST_RESULT(result);
  object_destroy(o);
}

void test2_object_create() {
  Object *o;
  o = object_create(4);
  PRINT_TEST_RESULT(object_get_id(o) == 4);
  object_destroy(o);
}

void test1_object_destroy(){
  Object *o;
  o = object_create(5);
  PRINT_TEST_RESULT(object_destroy(o) == OK);
}

void test2_object_destroy(){
  Object *o = NULL;
  PRINT_TEST_RESULT(object_destroy(o)==ERROR);
}

void test1_object_set_id(){
  Object *o;
  o = object_create(1);
  PRINT_TEST_RESULT(object_set_id(o,3)==OK);
  object_destroy(o);  
}

void test2_object_set_id(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_id(o,NO_ID)==ERROR);
  
}



void test1_object_get_id() {
  Object *o;
  o = object_create(25);
  PRINT_TEST_RESULT(object_get_id(o) == 25);
  object_destroy(o);
}

void test2_object_get_id() {
  Object *o = NULL;
  PRINT_TEST_RESULT(object_get_id(o) == NO_ID);
}

void test1_object_set_name() {
  Object *o;
  o = object_create(5);
  PRINT_TEST_RESULT(object_set_name(o, "hola") == OK);
  object_destroy(o);
}

void test2_object_set_name() {
  Object *o = NULL;
  PRINT_TEST_RESULT(object_set_name(o, "hola") == ERROR);
}



void test1_object_get_name() {
  Object *o;
  o = object_create(1);
  object_set_name(o, "adios");
  PRINT_TEST_RESULT(strcmp(object_get_name(o), "adios") == 0);
  object_destroy(o);
}

void test2_object_get_name() {
  Object *o = NULL;
  PRINT_TEST_RESULT(object_get_name(o) == NULL);
}

void test1_object_set_description(){
  Object *o;
  o = object_create(5);
  PRINT_TEST_RESULT(object_set_description(o, "hola") == OK);
  object_destroy(o);
  
}

void test2_object_set_description() {
  Object *o = NULL;
  PRINT_TEST_RESULT(object_set_name(o, "hola") == ERROR);
}

void test1_object_get_description(){
   Object *o;
  o = object_create(1);
  object_set_description(o, "adios");
  PRINT_TEST_RESULT(strcmp(object_get_description(o), "adios") == 0);
  object_destroy(o);
}

void test2_object_get_description(){
  Object *o = NULL;  
  PRINT_TEST_RESULT(object_get_description(o)== NULL);

}

void test1_object_del_obj_name(){
  Object *o;
  o = object_create(3);
  object_set_name(o, "hola");
  PRINT_TEST_RESULT(object_del_obj_name(o,"hola") == ERROR);
  object_destroy(o);
  
}
void test2_object_del_obj_name(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_del_obj_name(o,"hola") == ERROR);
  
}

void test1_object_has_light(){
  Object *o;
  o = object_create(3);
  object_set_light(o, TRUE);
  PRINT_TEST_RESULT(object_has_light(o)==TRUE);
  object_destroy(o);
}
void test2_object_has_light(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_has_light(o)==FALSE);
  
}

void test1_object_set_light(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_light(o, TRUE)==OK);
  object_destroy(o);
}

void test2_object_set_light(){
   Object *o=NULL;
  PRINT_TEST_RESULT(object_set_light(o, TRUE)== ERROR);  
}

void test1_object_is_hidden(){
  Object *o;
  o = object_create(3);
  object_set_hidden(o, TRUE);
  PRINT_TEST_RESULT(object_is_hidden(o)==TRUE);
  object_destroy(o);

  
}

void test2_object_is_hidden(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_is_hidden(o)==FALSE);
}


void test1_object_set_hidden(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_hidden(o, TRUE)==OK);
  object_destroy(o);
  
}
void test2_object_set_hidden(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_hidden(o,TRUE) == ERROR);
  
}

void test1_object_is_movable(){
  Object *o;
  o = object_create(3);
  object_set_movable(o, TRUE);
  PRINT_TEST_RESULT(object_is_movable(o)==TRUE);
  object_destroy(o);
}
void test2_object_is_movable(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_is_movable(o)==FALSE);
  
}

void test1_object_set_movable(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_movable(o, TRUE)==OK);
  object_destroy(o);
  
}
void test2_object_set_movable(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_movable(o,TRUE) == ERROR);
}

void test1_object_is_dependent(){
  Object *o;
  o = object_create(3);
  object_set_dependency(o, 1);
  PRINT_TEST_RESULT(object_is_dependent(o)==1);
  object_destroy(o);
}
void test2_object_is_dependent(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_is_dependent(o) == FALSE);
}

void test1_object_set_dependency(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_dependency(o, 1)==OK);
  object_destroy(o);
  
}
void test2_object_set_dependency(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_dependency(o,1) == ERROR);
}

void test1_object_can_open(){
  Object *o;
  o = object_create(3);
  object_set_open(o, 1);
  PRINT_TEST_RESULT(object_can_open(o) == TRUE);
  object_destroy(o);
}
void test2_object_can_open(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_can_open(o) == FALSE);
}

void test1_object_set_open(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_open(o,1) == OK);
  object_destroy(o);
}
void test2_object_set_open(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_open(o,1) == ERROR);
  
}

void test1_object_get_open(){
  Object *o;
  o = object_create(1);
  object_set_open(o,1);
  PRINT_TEST_RESULT(object_get_open(o)==1);
  object_destroy(o);
  
}
void test2_object_get_open(){
  Object *o = NULL;
  PRINT_TEST_RESULT(object_get_open(o) == -1);
}

void test1_object_is_turnedon(){
  Object *o;
  o = object_create(1);
  object_set_turnedon(o,TRUE);
  PRINT_TEST_RESULT(object_is_turnedon(o)==TRUE);
  object_destroy(o);
  
}
void test2_object_is_turnedon(){
  Object *o = NULL;
  PRINT_TEST_RESULT(object_is_turnedon(o) == FALSE);
}

void test1_object_set_turnedon(){
  Object *o;
  o = object_create(3);
  PRINT_TEST_RESULT(object_set_turnedon(o,TRUE) == OK);
  object_destroy(o);
}
void test2_object_set_turnedon(){
  Object *o=NULL;
  PRINT_TEST_RESULT(object_set_turnedon(o,TRUE) == ERROR);

}

void test1_object_find_dependence(){
  Object *o;
  Inventory *inv;
  o = object_create(2);
  object_set_dependency(o, 1);
  inv = inventory_create();
  inventory_set_obj(inv,object_is_dependent(o));
  PRINT_TEST_RESULT(object_find_dependence(o, inv));
  object_destroy(o);
  inventory_destroy(inv);
  
}
void test2_object_find_dependence(){
   Object *o=NULL;
    Inventory*inv = NULL;
  PRINT_TEST_RESULT(object_find_dependence(o,inv)==FALSE);
}











