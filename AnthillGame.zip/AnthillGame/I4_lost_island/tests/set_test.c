/** 
 * @brief It tests set module
 * 
 * @file set_test.c
 * @author Noelia Rincón
 * @version 0.2 
 * @date 11-03-2023
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "set.h"
#include "set_test.h"
#include "test.h"

#define MAX_TESTS 28

/** 
 * @brief Main function for SPACE unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Set:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }

  if (all || test == 1) test1_set_create();
  if (all || test == 2) test2_set_create();
  if (all || test == 5) test1_set_destroy();
  if (all || test == 6) test2_set_destroy();
  if (all || test == 7) test1_set_add_id();
  if (all || test == 8) test2_set_add_id();
  if (all || test == 9) test3_set_add_id();
  if (all || test == 10) test1_set_del_id();
  if (all || test == 11) test2_set_del_id();
  if (all || test == 12) test3_set_del_id();
  if (all || test == 13) test4_set_del_id();
  if (all || test == 14) test5_set_del_id();
  if (all || test == 15) test1_set_array_full();
  if (all || test == 16) test2_set_array_full();
  if (all || test == 17) test1_set_id_exists();
  if (all || test == 18) test2_set_id_exists();
  if (all || test == 19) test1_set_total_id();
  if (all || test == 20) test2_set_total_id();
 

  PRINT_PASSED_PERCENTAGE;

  return 1;
}



void test1_set_create() {
  Set *s;
  s = set_create();
  PRINT_TEST_RESULT(set_destroy(s) == OK);
}

void test2_set_create() { 
  int result;
  Set *s;
  s = set_create();
  result=s!=NULL ;
  PRINT_TEST_RESULT(result);
  set_destroy(s);
}


void test1_set_destroy() {
  Set *s;
  s = set_create();
  PRINT_TEST_RESULT(set_destroy(s));
}


void test2_set_destroy() {
  Set *s = NULL;
  PRINT_TEST_RESULT(set_destroy(s) == ERROR);
}


void test1_set_add_id() {
  Set *s;
  s = set_create();
  PRINT_TEST_RESULT(set_add_id(s, 5) == OK);
  set_destroy(s);

}


void test2_set_add_id() {
  Set *s = NULL;
  PRINT_TEST_RESULT(set_add_id(s, 5) == ERROR);
}



void test3_set_add_id() {
  Set *s;
  s = set_create();
  PRINT_TEST_RESULT(set_add_id(s, 1) == OK);
  set_destroy(s);
}



void test1_set_del_id() {
  Set *s;
  s = set_create();
  set_add_id(s, 5);
  PRINT_TEST_RESULT(set_del_id(s, 5) == OK);
  set_destroy(s);
}



void test2_set_del_id() {
  Set *s;
  s = set_create();
  set_add_id(s, 7);
  PRINT_TEST_RESULT(set_del_id(s, 5) == ERROR);
  
}



void test3_set_del_id() {
  Set *s =  NULL;
  PRINT_TEST_RESULT(set_del_id(s, 5) == ERROR);
}

void test4_set_del_id() {
  Set *s;
  s = set_create();
  set_add_id(s, 5);
  set_del_id(s, 5);
  PRINT_TEST_RESULT(set_del_id(s, 5) == ERROR);

}

void test5_set_del_id() {
  Set *s;
  s = set_create();
  set_add_id(s, 5);
  set_add_id(s, 6);
  set_add_id(s, 7);
  PRINT_TEST_RESULT(set_del_id(s, 8) == ERROR);
  set_destroy(s);
}



void test1_set_array_full(){
  Set *s;
  s=set_create();
  PRINT_TEST_RESULT(set_array_full(s)==ERROR);
  set_destroy(s);
}

void test2_set_array_full(){
  Set *s=NULL;
  PRINT_TEST_RESULT(set_array_full(s)==ERROR);
  
}

void test1_set_id_exists(){
  Set *s;
  s = set_create();
  set_add_id(s, 3);
  PRINT_TEST_RESULT(set_id_exists(s, 3)==TRUE);

  
}

void test2_set_id_exists(){
  Set *s=NULL;
  PRINT_TEST_RESULT(set_id_exists(s, NO_ID)==FALSE);

  
}


void test1_set_total_id() {
  Set *s;
  s = set_create();
  set_add_id(s, 5);
  PRINT_TEST_RESULT(set_total_id(s) == 1);
  set_destroy(s);
}


void test2_set_total_id() {
  Set *s;
  s = set_create();
  PRINT_TEST_RESULT(set_total_id(s) == 0);
  set_destroy(s);
}



