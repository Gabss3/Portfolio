/**
 * @brief defines the game_loop interface
 *
 * @file game_loop.c
 * @author Profesores PPROG
 * @version 3.0
 * @date 30-11-2020
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include "string.h"

#include "graphic_engine.h"
#include "game.h"
#include "command.h"
#include "game_management.h"
#include "types.h"

#define MAX 100

/*Inicialitates the game loop*/
int game_loop_init(Game *game, Graphic_engine **gengine, char *file_name);

/*Runs the game loop*/
void game_loop_run(Game *game, Graphic_engine *gengine, FILE *file);

/*Cleans up the game loop*/
void game_loop_cleanup(Game *game, Graphic_engine *gengine);


int main(int argc, char *argv[]){
  Game *game = NULL;
  Graphic_engine *gengine;
  FILE *file = NULL;
  

  /*This conditonal makes sure there is no error in the function*/
  if (argc < 2){
    fprintf(stderr, "Use: %s <game_data_file>\n", argv[0]);
    return 1;
  }


  /* if the user has entered a log file it writes its information */
  if (argc > 3 && strcmp(argv[2], "-l") == 0){
    file = fopen(argv[3], "w");
    if (!file){
      return 1;
    }
  }
  
  srand(time(NULL));
    
  game = game_create();
  if (!game){
    return 1;
  }


  /*The code enters the conditional if there where no previous errors detected*/
  if (!game_loop_init(game, &gengine, argv[1])){
        game_loop_run(game, gengine, file);  
        game_loop_cleanup(game, gengine); 
  }

  if (file){
    fclose(file);
    
  }

  
  return 0;
  
}

/* Error Control while initializing game. */

int game_loop_init(Game *game, Graphic_engine **gengine, char *file_name){
  if (game_management_create_from_file(game, file_name) == ERROR){
    fprintf(stderr, "Error while initializing game.\n");
    return 1;
  }

  /* Error Control while initializing graphic engine. */
  
  if ((*gengine = graphic_engine_create()) == NULL){
    fprintf(stderr, "Error while initializing graphic engine.\n");
    game_destroy(game);
    return 1;
  }

  return 0;
}


/*Runs the game loop*/

void game_loop_run(Game *game, Graphic_engine *gengine, FILE *file){
  T_Command command = NO_CMD;
  STATUS st = OK;
  int i = 0;

  
  while ((command != EXIT) && !game_is_over(game)){

    
    graphic_engine_paint_game(gengine, game, file);
    command = command_get_user_input(game_get_last_command(game));
    game_update(game, command);

    if (file){
      for (i = 0; i < MAX; i++){
        fprintf(file, "hola");
        st = game_get_st(game);
        if(st == OK){
        fprintf(file, ": OK\n");
        }
        else{
        fprintf(file, ": ERROR\n");
        }
      }
    }

  }
  
  if (file){
    fprintf(file, "Exit: Everything went alright"); 
  }

    
}


/*Destroys the game and the gengine*/

void game_loop_cleanup(Game *game, Graphic_engine *gengine){
  game_destroy(game);
  graphic_engine_destroy(gengine);
}