

#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include "game_rules.h"
#include "game.h"


/*It sets the object named cherry to not hidden*/
void gm_cherry_growing(Game *game){

  /* Error control */
  if(!game){
      return;
  }

  object_set_hidden(game_get_object_by_name(game, "cherry"), FALSE);

  return;
}

/*It return wether the object named cherry is hidden or not*/
BOOL gm_cherry_hidden(Game *game){
  
  /* Error control */
  if(!game){
    return FALSE;
  }
  
  if(object_is_hidden(game_get_object_by_name(game, "cherry"))==TRUE){
    return TRUE;
  }
    
  else
    return FALSE;
}

/*It returns wether the player is at the same space as the object named cherry or not*/
BOOL gm_player_at_cherry(Game *game){

  /* Error control*/
  if(!game){
      return FALSE;
  }
 if(player_get_location(game_get_player(game))==game_get_object_location(game, object_get_id(game_get_object_by_name(game, "cherry")))){
    return TRUE;
  }

  return FALSE;
}

/* It drops the cherry at a random space of the game*/
void gm_cherry_drop(Game *game){
  int random;

  /*Error control*/
  if(!game){
    return;
  }
  
  random = rand() % 32;
  
  player_delete_object(game_get_player(game), object_get_id(game_get_object_by_name(game, "cherry")));
  space_set_object(game_get_space(game, random), object_get_id(game_get_object_by_name(game, "cherry")));
  object_set_hidden(game_get_object_by_name(game, "cherry"), TRUE);

  return;
}  

/*It sets the object named masterkey to not hidden*/
void gm_masterkey_appearing(Game *game){

  /* Error control*/
  if(!game){
      return;
  }

  object_set_hidden(game_get_object_by_name(game, "masterkey"), FALSE);
  return;
}

/*It sets a killed message*/
STATUS gm_killed_message(Game *game, char *str){

  /*Error control*/
  if(!game){
      return ERROR;
  }
  if (player_get_health(game_get_player(game)) == 0){
    sprintf(str, "Oh no, you have been killed!");
    player_set_health(game_get_player(game), -1);
    return OK;
  }
  return ERROR;
}

/*It sets an escaped message*/
STATUS gm_escaped_message(Game *game, char *str){

  /*Error control*/
  if(!game){
    return ERROR;
  }

  if(player_get_location(game_get_player(game))==6){
    sprintf(str, "Congratulations, you found the helicopter and escaped!");
    player_set_health(game_get_player(game), -1);
    return OK;
  } 
      
  return ERROR;

}

/*It sets a volcano message*/
STATUS gm_volcano_message(Game *game, char *str){

  /*Error control*/
  if(!game){
      return ERROR;
  }

  if(player_get_location(game_get_player(game))== 29){
    sprintf(str, "Oh no you have fallen into a Volcano, you are dead now.");
    player_set_health(game_get_player(game), -1);
    return OK;
  }
  
  return ERROR;
}

/*It sets the player to a random space of the game*/
void gm_teletransport_player(Game *game){

    int random=6;

    /*Error control*/
    if(!game){
        return;
    }

    while(random ==6 || random==30 || random==31 || random==32 || random==23){
        random = rand() % 32;
    }

    game_set_player_location(game, random);
    return;
}
