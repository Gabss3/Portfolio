/** 
 * @brief defines the enemy interface
 * 
 * @file enemy.c
 * @author Blanca Matas
 * @version 1.0 
 * @date 14/04/2023
 * @copyright GNU Public License
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "enemy.h"

/**
 * @brief Enemy
 *
 * This struct stores all the information of a enemy.
 */
struct _Enemy {
    Id id;                   /* The id of the enemy */
    char name[WORD_SIZE];    /* The name of the enemy */
    Id location;             /* Id of the enemy location */
    int health;              /* Health points of the enemy*/
};

/*Creates a new enemy*/

Enemy *enemy_create(Id id)
{
    Enemy *enemy;

  /*Error control*/
    if (id == NO_ID) {
        return NULL;
    }
  /* Allocates memory for the new enemy*/
    enemy = (Enemy *)malloc(sizeof(Enemy));
    if (!enemy) {
        return NULL;
    }

    /* Initializates all elements */
    enemy->id = id;
    enemy->name[0] = '\0';
    enemy->location = NO_ID;
    enemy->health = HEALTH_ENEMY;
    return enemy;
}

/*frees the previous memory allocation for a enemy */

STATUS enemy_destroy(Enemy *enemy)
{
  /* Error control */
    if (!enemy) {
        return OK;
    }

    free(enemy);
    enemy = NULL;
    return OK;
}

 /*It gets the id of a enemy*/

Id enemy_get_id(Enemy *enemy)
{
  /* Error control */
  
    if (!enemy){
      return NO_ID;
    }
    return enemy->id;
}

/* It sets the id of the enemy*/
STATUS enemy_set_id(Enemy *enemy, Id id)
{
  /* Error control */
    if (!enemy || id == NO_ID) {
        return ERROR;
    }

    enemy->id = id;
    return OK;
}

  /* It sets the name of the enemy */

STATUS enemy_set_name(Enemy *enemy, char *name)
{
  /* Error control */
  
    if (!enemy || name == NULL){
        return ERROR;
    }

    if (!strcpy(enemy->name, name)){
      return ERROR;
    }

    return OK;
}

  /* It gets the name of the enemy */

const char * enemy_get_name(Enemy* enemy) {
  /* Error control */
  
  if (!enemy)
    return NULL;

  return enemy->name;
}
/** It gets the the location of a enemy*/
Id enemy_get_location(Enemy* enemy){
  /* Error control */
  
  if(!enemy)
    return NO_ID;

  return enemy->location;
}

  /* It sets the location of the enemy */
STATUS enemy_set_location(Enemy* enemy, Id location){
  
  /* Error control */
  if(!enemy||location==NO_ID)
    return ERROR;

  enemy->location=location;
  return OK;
}

/* It prints all the information of the enemy (id,name,location,health) */
STATUS enemy_print(Enemy *enemy) {
  if (!enemy) {
      return ERROR;
  }

  fprintf(stdout, "--> enemy (id: %ld; name: %s; location: %ld; health: %d) \n", enemy->id, enemy->name, enemy->location, enemy->health);
  return OK;
}

/*It gets the health of the enemy*/

int enemy_get_health(Enemy* enemy) {
  /* Error control */
  
  if (!enemy) {
    return -1;
  }
  return enemy->health;
}

  /* it sets the health of the enemy */
STATUS enemy_set_health(Enemy* enemy, int health){
  
  /* Error control */
  if(!enemy||health < 0 || health >HEALTH_ENEMY)
    return ERROR;

  enemy->health = health;
  return OK;
}

