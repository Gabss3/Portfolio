/** 
 * @brief It reads the information from a file to implement in the game 
 * 
 * @file game_management.c
 * @author Blanca Matas
 * @version 1.0 
 * @date 30/04/2023
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game_management.h"


/*creates a game from a file*/

STATUS game_management_create_from_file(Game *game, char *file){
  if(!file){
    
    return ERROR;
  }
       
  if ( game_management_load_spaces(game, file) == ERROR)
    return ERROR;

  if ( game_management_load_objects(game, file) == ERROR)
    return ERROR;
  
  if ( game_management_load_player(game, file) == ERROR)
    return ERROR;

  if ( game_management_load_enemy(game, file) == ERROR)
    return ERROR;
  
  if ( game_management_load_links(game, file) == ERROR)
    return ERROR;
  if (game_management_load_inventory(game, file) == ERROR){
    return ERROR;
  }
  return OK;
}

/*it loads all the spaces in the game*/

STATUS game_management_load_spaces(Game *game, char *filename){
  FILE *file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char *toks = NULL;
  Id id = NO_ID;
  Space *space = NULL;
  STATUS status = OK;
  char desc[WORD_SIZE] = "";
  char gdesc[TAM1][TAM2] = {""};
  int i = 0;
  BOOL light = TRUE;

/*Control error*/
  
  if (!game || !filename){
    return ERROR;
  }
  
/*opens the file where the information is*/
  file = fopen(filename, "r");
  if (file == NULL){
    return ERROR;
  }

/*reads the file and gets the info*/

while (fgets(line, WORD_SIZE, file)){
    if (strncmp("#s:", line, 3) == 0){

      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);
      toks = strtok(NULL, "|");
      light = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(desc, toks);
       
      for (i = 0; i < TAM1; i++){
        toks = strtok(NULL, "|");
        strcpy(gdesc[i], toks);
        gdesc[i][TAM2 -1] = '\0'; 
      }
      
      /*creates the spaces whith the information and the sets its in the necessary fields*/

      space = space_create(id);
      if (space != NULL){
        space_set_id(space, id);
        space_set_name(space, name);
        space_set_description(space, desc);
        space_set_light(space, light);
        
        
        for (i = 0; i < TAM1; i++){
          space_set_gdesc(space, gdesc[i], i);
          strcpy(gdesc[i], "         ");
        }
        
        game_add_space(game, space);
      }
    }
  }

  if (ferror(file)){
    status = ERROR;
  }
/*closes the file*/
  fclose(file);
  return status;
  
}

/*it loads all the objects in the game*/

STATUS game_management_load_objects(Game *game, char *filename){
  
  FILE *file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char *toks = NULL;
  Id id = NO_ID, space = NO_ID;
  Object *object = NULL;
  STATUS status = OK;
  char description[WORD_SIZE];
  BOOL hidden = TRUE;
  BOOL movable = FALSE;
  Id dependency = NO_ID;
  Id open = NO_ID;
  BOOL turnedon = FALSE;
  BOOL light = FALSE;

  /*Control error*/

  if (!filename || !game){
    return ERROR;
  }

  /*opens the file where the information is*/

  file = fopen(filename, "r");
  if (file == NULL){
    return ERROR;
  }

  /*reads the file and gets the info*/

  while (fgets(line, WORD_SIZE, file)){
    
    if (strncmp("#o:", line, 3) == 0){
      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);
      toks = strtok(NULL, "|");
      space = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(description, toks);
      toks = strtok(NULL, "|");
      hidden = atol(toks);
      toks = strtok(NULL, "|");
      movable = atol(toks);
      toks = strtok(NULL, "|");
      dependency = atol(toks);
      toks = strtok(NULL, "|");
      open = atol(toks);
      toks = strtok(NULL, "|");
      turnedon = atol(toks);
      toks = strtok(NULL, "|");
      light = atol(toks);


      /*creates the objects whith the information and the sets its in the necessary fields*/
      object = object_create(id);
      if (object != NULL){
        object_set_name(object, name);
        object_set_description(object, description);
        object_set_light(object, light);
        object_set_hidden(object, hidden);
        object_set_movable(object, movable);
        object_set_dependency(object, dependency);
        object_set_open(object, open);
        object_set_turnedon(object, turnedon);
        game_set_object_location(game, space, id);
        game_add_object(game, object);
        
      }
    }
  }
  if (ferror(file)){
    status = ERROR;
  }
/*closes the file*/
  fclose(file);
  return status;
}

/*it loads the enemy in the game*/

STATUS game_management_load_enemy(Game *game, char *filename){
  
  FILE *file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char *toks = NULL;
  Id id = NO_ID, space = NO_ID;
  Enemy *enemy = NULL;
  STATUS status = OK;
  int health;

/*Control error*/

  if (!game || !filename){
    return ERROR;
  }
/*opens the file where the information is*/

  file = fopen(filename, "r");
  if (file == NULL){
    return ERROR;
  }

/*reads the file and gets the info*/

  while (fgets(line, WORD_SIZE, file)){

    if (strncmp("#e:", line, 3) == 0){
      
      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);
      toks = strtok(NULL, "|");
      space = atol(toks);
      toks = strtok(NULL, "|");
      health = atol(toks);

      /*creates the enemy whith the information and the sets its in the necessary fields*/
   
      enemy = enemy_create(id);
      if (enemy != NULL){
        enemy_set_name(enemy, name);
        enemy_set_location(enemy, space);
        enemy_set_health(enemy, health);
        game_add_enemy(game, enemy);
      }
    }
  }

  if (ferror(file)){
    status = ERROR;
  }

  /*closes the file*/

  fclose(file);
  return status;
}

/*it loads the player in the game*/

STATUS game_management_load_player(Game *game, char *filename){
  
  FILE *file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char *toks = NULL;
  Id space = NO_ID;
  Id id = NO_ID;
  int health = 0;
  int capacity = 0;
  Player *player = NULL;
  STATUS status = OK;

  /*Control error*/

  if (!game || !filename){
    return ERROR;
  }
  /*opens the file where the information is*/
  
  file = fopen(filename, "r");
  if (file == NULL){
    return ERROR;
  }
/*reads the file and gets the info*/

  while (fgets(line, WORD_SIZE, file))
  {
    if (strncmp("#p:", line, 3) == 0){
      
      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);
      toks = strtok(NULL, "|");
      space = atol(toks);
      toks = strtok(NULL, "|");
      health = atol(toks);
      toks = strtok(NULL, "|");
      capacity = atol(toks);

/*creates the player whith the information and the sets its in the necessary fields*/
   
      
      player = player_create(id);
      if (player != NULL){

        player_set_name(player, name);
        player_set_location(player, space);
        player_set_health(player, health);
        game_add_player(game, player);
        
      }
    }
  }

  if (ferror(file)){
    status = ERROR;
  }

/*closes the file*/

  fclose(file);
  return status;
}

/*it loads all the links in the game*/

STATUS game_management_load_links(Game* game, char* filename){

  FILE* file=NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char* toks = NULL;
  Id id = NO_ID,origin=NO_ID, destination=NO_ID;
  Link* link = NULL;
  STATUS status = OK;
  ACCESS st;
  DIRECTION direction;
  
/*Control error*/
  if (!filename || !game) {
    return ERROR;
  }

/*opens the file where the information is*/

  file = fopen(filename, "r");
  if (file == NULL) {
    return ERROR;
  }

/*reads the file and gets the info*/

  while (fgets(line, WORD_SIZE, file)) {
    if (strncmp("#l:", line, 3) == 0) {
      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);
      toks = strtok(NULL, "|");
      origin = atol(toks);
      toks = strtok(NULL, "|");
      destination = atol(toks);
      toks = strtok(NULL, "|");
      direction = atol(toks);
      toks = strtok(NULL, "|");
      st = atol(toks);

/*creates all the links whith the information and the sets its in the necessary fields*/
   

      link = link_create(id);
      if (link != NULL) {
        link_set_name(link, name);
        link_set_origin(link, origin);
        link_set_destination(link, destination);
        link_set_direction(link, direction);
        link_set_status(link, st);
        game_add_link(game, link);  
      }
    }
  }

  if(ferror(file)){
    status=ERROR;
  }

/*closes the file*/

  fclose(file);
  return status;
}


/*it loads the entire game with all the necessary fields*/

STATUS game_management_load_game(Game *game, char *filename){

  /*Control error*/

  if(!filename){
    return ERROR;
  }
/*it destroys the game and then creates a new one so the structures dont overlap themselves*/

  game_destroy(game);
  game_create(game);
/*calls the function to create the game with the information of a file*/

  game_management_create_from_file(game, filename);
  return OK;
  
}

/*it saves all the spaces in the game*/

STATUS game_management_save_spaces(Game *game, char *filename){

  FILE *file = NULL;
  Space *space = NULL;
  int i = 0;

/*Control error*/
  
  if (!game || !filename){
    return ERROR;
  }
 /*opens the file where the information is*/
  file = fopen(filename, "a");
  if (file == NULL){
    return ERROR;
  }
/*saves the inicial space*/
  space = game_get_space(game, game_get_space_id_at(game, 0));

/*saves the following spaces until there is no more*/
  
  for (i = 1; space != NULL && i < MAX_SPACES; i++){
    fprintf(file, "#s:%ld|%s|%d|%s|%s|%s|%s|%s|%s|\n", space_get_id(space), space_get_name(space), space_get_light(space), space_get_description(space), space_get_gdesc(space, 0), space_get_gdesc(space, 1), space_get_gdesc(space, 2), 
    space_get_gdesc(space, 3), space_get_gdesc(space, 4));
    space = game_get_space(game, game_get_space_id_at(game, i));
    
  }

/*closes the file*/
  fclose(file);
  return OK;
  
}

/*it saves all the objects in the game*/


STATUS game_management_save_objects(Game *game, char *filename){

FILE *file = NULL;
Object *object = NULL;
int i = 0;

/*Control error*/
  if (!game || !filename){
    return ERROR;
  }
/*opens the file where the information is*/
  file = fopen(filename, "a");
  if (file == NULL){
    return ERROR;
  }
/*saves the first object*/
  object = game_get_object(game, game_get_object_id_at(game, 0));

/*saves the following objects until there is no more*/
  
  for (i = 1; object != NULL && i < MAX_OBJECTS; i++) {
    fprintf(file, "#o:%ld|%s|%ld|%s|%d|%d|%ld|%ld|%d|%d|\n", object_get_id(object), object_get_name(object), game_get_object_location(game, object_get_id(object)), object_get_description(object), object_is_hidden(object), object_is_movable(object), object_dependency_id(object), object_get_open(object), object_is_turnedon(object), object_has_light(object));
    object = game_get_object(game, game_get_object_id_at(game, i));

  }
/*closes the file*/
  fclose(file);
  return OK;
}

/*it saves the player in the game*/
STATUS game_management_save_player(Game *game, char *filename){

  FILE *f = NULL;
  Player *player = NULL;
  Id *inventory = NULL;
  int i = 0;

/*Control error*/
  if (!game || !filename){
    return ERROR;
  }
/*opens the file where the information is*/
  f = fopen(filename, "a");
  if (!f){
    return ERROR;
  }
/*saves the player*/
  player = game_get_player(game);
  
/*allocates memory for the player's inventory*/
  inventory = (Id *)malloc(MAX_SET_IDS * sizeof(Id));
    if (!inventory){
      return ERROR;
    }
/*saves the inventory objects*/
  set_id_objects(inventory_get_objs(player_get_inventory(player)), inventory);

  for (i = 0; i < MAX_INVENTORY && inventory[i] != NO_ID; i++){
  
    fprintf(f, "#i:%ld|%s|%ld|%s|%d|%d|%ld|%ld|%d|%d|\n",object_get_id(game_get_object(game, inventory[i])), object_get_name(game_get_object(game, inventory[i])), game_get_object_location(game, inventory[i]), object_get_description(game_get_object(game, inventory[i])), object_is_hidden(game_get_object(game, inventory[i])), object_is_movable(game_get_object(game, inventory[i])), object_dependency_id(game_get_object(game, inventory[i])), object_get_open(game_get_object(game, inventory[i])), object_is_turnedon(game_get_object(game, inventory[i])), object_has_light(game_get_object(game, inventory[i])));
                
  }

/*saves the player info*/  
  fprintf(f, "#p:%ld|%s|%ld|%d|%d|\n", player_get_id(player), player_get_name(player), player_get_location(player), player_get_health(player), inventory_get_maxobjs(player_get_inventory(player)));
/*closes the file*/
  fclose(f);
  
/*frees memory*/
  free(inventory);
  return OK;
  
}
/*it saves the enemy in the game*/
STATUS game_management_save_enemy(Game *game, char *filename){

  FILE *file = NULL;
  Enemy *enemy = NULL;

/*Control error*/
  if (!game || !filename){
    return ERROR;
  }
/*opens the file where the information is*/
  
  file = fopen(filename, "a");
  if (file == NULL){
    return ERROR;
  }

  
/*saves the enemy info*/
  enemy = game_get_enemy(game);
  fprintf(file, "#e:%ld|%s|%ld|%d|\n", enemy_get_id(enemy), enemy_get_name(enemy), enemy_get_location(enemy), enemy_get_health(enemy));

/*closes the file*/

  fclose(file);
  return OK;
  
}

/*it saves all the links in the game*/

STATUS game_management_save_links(Game *game, char *filename){

  FILE *file = NULL;
  Link *link = NULL;
  int i = 0;

/*Control error*/
  if (!game || !filename){
    return ERROR;
  }
/*opens the file where the information is*/
  file = fopen(filename, "a");
  if (file == NULL){
    return ERROR;
  }
/*saves the first link*/  
  link = game_get_link(game, game_get_link_id_at(game, 0));

/*saves all the links until there are no more*/  
  
  for (i = 1; link != NULL && i < MAX_LINKS; i++) {
    fprintf(file, "#l:%ld|%s|%ld|%ld|%d|%d|\n", link_get_id(link), link_get_name(link), link_get_origin(link), link_get_destination(link), link_get_direction(link), link_get_status(link));
    link = game_get_link(game, game_get_link_id_at(game, i));
  }
/*saves the inventory objects*/
  fclose(file);
  return OK;
}
/*it calls all the functions to save the entire game*/

STATUS game_management_save(Game *game, char *filename){
/*Control error*/
  if(!game || !filename){
    return ERROR;
  }
  
  
  if(game_management_save_spaces(game, filename) == ERROR) {
    return ERROR;
  }
  if (game_management_save_player(game, filename) == ERROR) {
    return ERROR;
  }
  if (game_management_save_objects(game, filename) == ERROR) {
    return ERROR;
  }
  if (game_management_save_enemy(game, filename) == ERROR) {
    return ERROR;
  }
  if (game_management_save_links(game, filename) == ERROR) {
    return ERROR;
  }

  return OK;
  
}

/*it loads the player's inventory in the game*/
STATUS game_management_load_inventory(Game *game, char *filename){
  FILE *f = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char *toks = NULL;
  Id id = NO_ID, space = NO_ID;
  Object *object = NULL;
  char description[WORD_SIZE];
  Id dependency = NO_ID, open = NO_ID;
  BOOL hidden = 0, movable = 0, turnedon = 0, light = 0;
  
/*Control error*/
  
    if (!game || !filename){
        return ERROR;
    }

/*opens the file where the information is*/
    f = fopen(filename, "r");
    if (!f){
      return ERROR;
    }
/*reads the file and gets the info*/
    while (fgets(line, WORD_SIZE, f)){
      
      if (strncmp("#i:", line, 3) == 0){
        toks = strtok(line + 3, "|");
        id = atol(toks);
        toks = strtok(NULL, "|");
        strcpy(name, toks);
        toks = strtok(NULL, "|");
        space = atol(toks);
        toks = strtok(NULL, "|");
        strcpy(description, toks);
        toks = strtok(NULL, "|");
        hidden = atol(toks);
        toks = strtok(NULL, "|");
        movable = atoi(toks);
        toks = strtok(NULL, "|");
        dependency = atol(toks);
        toks = strtok(NULL, "|");
        open = atol(toks);
        toks = strtok(NULL, "|");
        turnedon = atoi(toks);
        toks = strtok(NULL, "|");
        light = atoi(toks);

/*creates all the objects that where inside of the inventory whith the information and the sets its in the necessary fields*/        
        object = object_create(id);
          if (object != NULL){
            object_set_name(object, name);
            game_set_object_location(game, space, id);
            object_set_description(object, description);
            object_set_hidden(object, hidden);
            object_set_movable(object, movable);
            object_set_dependency(object, dependency);
            object_set_open(object, open);
            object_set_turnedon(object, turnedon);
            object_set_light(object, light);
                
            game_add_object(game, object);
            player_set_object(game_get_player(game), id);
            
          }
      }
    }

    if (ferror(f)){
      return ERROR;
    }

/*closes the file*/


    fclose(f);
    return OK;
}