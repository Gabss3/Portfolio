/**
 * @brief It implements the set module and all the associated calls
 * for each command
 *
 * @file set.c
 * @author Blanca Matas
 * @version 1.0
 * @date 03-02-2023
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "set.h"
#include "types.h"


#define MAX 100

/* Definition of the set structure */
struct _Set {
  Id id_array[MAX_SET_IDS];
  int num_id;
};

/* Creates a new set */
Set *set_create(){

  Set *s = NULL;
  int i;

  /* Allocates memory for a new set */
  s = (Set *)malloc(sizeof(Set));
  /* Error control */
  if (s == NULL) {
    return NULL;
  }

  /* initialices its components */
  for (i = 0; i < MAX; i++){
    s->id_array[i] = NO_ID;
  }
  s->num_id = 0;

  return s;
}

/* Destroys a set */
STATUS set_destroy(Set *s){

  /* Error control */
  if (!s) {
    return ERROR;
  }
  /* frees the memory previously allocated */
  free(s);
  return OK;
}

/* Adds an if to the set */
STATUS set_add_id(Set *s, Id id){

  int i;

  /* Error control */
  if (!s || id == NO_ID){
    return ERROR;
  }
    
  /* Searchs for a free position in the id array and adds the new id */
  
  for (i = 0; i < MAX_SET_IDS; i++){
    if (s->id_array[i] == NO_ID){
      s->id_array[i] = id;
        s->num_id++;
        return OK;
      }
  }

  return ERROR;
}

/* gets the number of ids the set has */
int set_total_id(Set *s){

  /* Error control */
  if (!s){
    return ERROR;
  }

  return s->num_id;
}

/* Determines if the set array is full */
STATUS set_array_full(Set *s){
  /* Error control */
  if(!s){
    return ERROR;
  }
  if (s->num_id == MAX){
    return OK;
    
  }
  else
  return ERROR;
}

Id set_element(Set *s, int posicion_id) {

  if (!s){
    return NO_ID;
  }

  if (posicion_id > s->num_id){
    return NO_ID;
  }

  return s->id_array[posicion_id];
}

/* Determines if an id is in the set */
BOOL set_id_exists(Set *s, Id id){
  int i;
  
  /* Error control */
  if (!s || id == NO_ID){
    return FALSE;
  }

  /* Goes though all the ids searching for a coincidence */
  for (i = 0; i < MAX && s->id_array[i] != NO_ID; i++){
    if (s->id_array[i] == id){
      return TRUE;
    }
  }
  return FALSE;
}


/* Deletes an id in the set */
STATUS set_del_id(Set *s, long id){  
  STATUS f = ERROR;
  int i = 0;

  /* Error control */
  if (!s || id == NO_ID){
    return ERROR;
  }

  /* Finds the id and removes it from the array */
  for (i = 0; i < MAX; i++){
    if (s->id_array[i] == id){
      s->id_array[i] = NO_ID;
      s->num_id--;
      f = OK;
      break;
    }
  }
    /* Move all the ids to avoid having a free position in the midle */
    if (f == OK){
      for (; i < MAX; i++){
        s->id_array[i] = s->id_array[i+1];

        if (i == MAX - 1){
          s->id_array[i] = NO_ID;
        }
      }
    }

    return f;
}

/*Prints all the set information */

STATUS set_print_set(Set *s){
  int i;

  /* Error control */
  if (!s){
    return ERROR;
  }

  fprintf(stdout, "%d", s->num_id);

  for (i = 0; i < s->num_id; i++) {
    fprintf(stdout, "%ld ", s->id_array[i]);
  }
  return OK;
}




/* Sets the set id array */
STATUS set_id_objects(Set *s, Id *ids){
    int i;
  
    /* Error control */
    if (!s || !ids){
      return ERROR;
    }

  for (i = 0; i < MAX; i++){
        ids[i] = s->id_array[i];
    }

  return OK;
}



