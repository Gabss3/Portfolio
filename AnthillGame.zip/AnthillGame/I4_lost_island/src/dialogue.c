#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dialogue.h"

/**
* @brief It implements the dialogue module and all the associated calls
 * for each command
 *
 * @file dialogue.c
 * @author Noelia Rincón 
 * @version 1.0
 * @date 01-05-2023
 * @copyright GNU Public License
*/

/**
  * @brief estructure for the dialogue module
  */
struct _Dialogue
{
    T_Command last_cmd; /*!< last command that has been used in the game */
    int error;  /*!< counts the errors */
};

Dialogue *dialogue_create(){
    Dialogue *d;
  
/* allocates memory for the dialogue */
    d = (Dialogue *)malloc(sizeof(Dialogue));
    if (!d){
        return NULL;
    }
    d->error = 0;

    return d;
}

STATUS dialogue_destroy(Dialogue *d){

  /*Error control*/
    if (!d){
        return ERROR;
    }
/*liberates the dialogue*/
    free(d);

    return OK;
}

STATUS dialogue_string(Dialogue *d, T_Command cmd, STATUS st, char *str){
    
  T_Command aux = UNKNOWN;
  
  if (!d){
    return ERROR;
  }
/*gets the last command used in the game and saves it*/
  d->last_cmd = cmd;
  if(st == OK){
/*switch with all the commands that can be used and the outcome that will be printed in the game*/
switch (cmd){
  case UNKNOWN:
    sprintf(str, " This command is unkown, try something else");
    d->error = 0;
    break;

  case EXIT:
    sprintf(str, " You are exiting the game, come back soon!");
    d->error = 0;
    break;

  case TAKE:
    sprintf(str, " You have successfully taken the object!");
    d->error = 0;
    break;

  case DROP:
    sprintf(str, " You have successfully dropped the object!");
    d->error = 0;
    break;

  case ATTACK:
    sprintf(str, " Someone has been hurt!");
    d->error = 0;
    break;

  case MOVE:
    sprintf(str, " You have moved sucecessfully");
    d->error = 0;
    break;

  case INSPECT:
    sprintf(str, " You have inspected successfully!");
    d->error = 0;
    break;

  case OPENED:
    sprintf(str, " You have successfully opened the door!");
    d->error = 0;
    break;

  case TURNON:
    sprintf(str, " You have successfully turned on the flash!");
    d->error = 0;
    break;

  case TURNOFF:
    sprintf(str, " You have successfully turned off the flash!");
    d->error = 0;
    break;
  
  case SAVE:
    sprintf(str, " You have successfully saved the game!");
    d->error = 0;
    break;

  case LOAD:
    sprintf(str, " You have successfully loaded the game!");
    d->error = 0;
    break;

  default:
    break;
  }

  }else{

    /*if the command could no be executed the messages that shows*/
    if(aux == cmd){
      d->error = 2;
    }
    if(d->error == 0){
      aux = cmd;
    }
  
    if(d->error > 1){
      sprintf(str, " You have already done that, try something else.");
    }
    else{
      sprintf(str, " You cannot do that, try something else!");
    }   
  }

return OK;

}
    

