/**
 * @brief implements the inventory interface
 *
 * @file inventory.c
 * @author Gabriella Leaño
 * @version 3.0
 * @date 13-03-2023
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "inventory.h"
#define MAX_INV 128

/* defines the structure of the inventory*/
struct _Inventory{
  Set *objs;   
  int max_objs;
};

/* it creates a new inventory*/
Inventory *inventory_create() {

  Inventory *inv = NULL;

  /* Allocates memory for a new inventory*/
  inv = (Inventory*) malloc(sizeof(Inventory));
  /* Error control*/
  if(!inv){
    return NULL;
  }

  inv->objs = set_create();
  /* Error control */
  if(inv->objs == NULL){
    return NULL;
  }
  
  inv->max_objs = MAX_INV;

  return inv;
}

/* Destroys an inventory*/
STATUS inventory_destroy(Inventory *inventory){
  /* Error control*/
  if (inventory == NULL){
    return ERROR;
  }
    
  set_destroy(inventory->objs);

  free(inventory);
  return OK;
}

/* Gets the maximun number of objects the inventory has*/

int inventory_get_maxobjs(Inventory *inventory) {
  /* Error control */
  if (!inventory){
    return NO_ID;
  }

  return inventory->max_objs;
}

/* Adds an objevt to the inventory*/
STATUS inventory_set_obj(Inventory *inventory, Id id){
  /* Error control*/
  if(!inventory || id == NO_ID){
    return ERROR;
  }

  set_add_id(inventory->objs, id);

  return OK;
}

/* Deletes an object from the inventory*/

STATUS inventory_del_object(Inventory *inventory, Id object){
  /* Error control */
  if(!inventory || !object){
    return ERROR;
  }

  return set_del_id(inventory->objs,object);
}

/* Gets a set with all the objects of the inventory*/
Set *inventory_get_objs(Inventory *inventory){

  /* Error control */
  if(!inventory){
    return NULL;
  }

  return inventory->objs;
  
}

/* Prints alla the information of the inventory (max obejcts,objects)*/
STATUS inventory_print(Inventory *inventory){

  if(!inventory){
    return ERROR;
  }

  fprintf(stdout, "Max_objects in the inventory: %d",inventory->max_objs);
  fprintf(stdout, " Objects in the inventory:");

  /* Prints the set of all the objects*/
  if(set_print_set(inventory->objs)==ERROR){
    return ERROR;
  }

  return OK;
}


/* Searchs if these is a given object in the inventory*/
BOOL inventory_find_object(Inventory *inventory, Id object){

  /*Control error*/
  if (!inventory || !object){
    return FALSE;
  }
  if (set_id_exists(inventory->objs, object) == TRUE){
    return TRUE;
  }

  return FALSE;
}
