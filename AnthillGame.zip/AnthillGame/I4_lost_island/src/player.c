/** 
 * @brief it implements the player interface 
 * 
 * @file player.c
 * @author Noelia Rincon
 * @version 1.0 
 * @date 14-02-2023 
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "player.h"
#define HEALTH 10

/**
 * @brief Player
 *
 * This struct stores all the information of a player.
 */
  
struct _Player{
  Id id;                    
  char name[WORD_SIZE];     
  Id location;              
  Inventory *objects;     
  int health;             
};


/* allocates memory for a new player and initializes its members */

Player* player_create(Id id){
  Player *newPlayer = NULL;

  /* Error control */
  if (id == NO_ID){
    return NULL;
  }

  newPlayer = (Player *) malloc(sizeof (Player));
  if (newPlayer == NULL){
    return NULL;
  }

  /* Initialization of an empty player*/
  
  newPlayer->id = id;
  newPlayer->name[0] = '\0';
  newPlayer->location = NO_ID;
  newPlayer->objects = inventory_create();
  if(!newPlayer->objects){
    player_destroy(newPlayer);
  }
  newPlayer->health = 5;


  return newPlayer;
}

/*frees the previous memory allocation for a player */
STATUS player_destroy(Player* player){
  if (!player){
    return ERROR;
  }

  inventory_destroy(player->objects);
  player->objects = NULL;
  
  free(player);
  player = NULL;
  return OK;
}

 /*It gets the id of a player*/
Id player_get_id(Player *player){
  
  if (!player){
    return NO_ID;
  }

  return player->id;
}

/*It sets the id of a player*/
STATUS player_set_id(Player *player, Id id){

  if (!player || id == NO_ID){
    return ERROR;
  }

  player->id = id;
  return OK;
}

/** It sets the name of a player*/
STATUS player_set_name(Player *player, char *name){ 
  if (!player || !name){
    return ERROR;
  }

  if (!strcpy(player->name, name)){
    return ERROR;
  }

  return OK;
}

/** It gets the name of a player*/
const char *player_get_name(Player *player){
  if (!player){
    return NULL;
  }

  return player->name;
}

/** It gets the the location of a player*/
Id player_get_location(Player *player){
  
  if (!player){
    return NO_ID;
  }

  return player->location;
}

/** It sets the location of a player*/
STATUS player_set_location(Player *player, Id location){

  /* Error control */
  if (!player || location == NO_ID){
    return ERROR;
  }

  player->location = location;
  return OK;
}

/* Adds a new object to the inventory of the player */
STATUS player_set_object(Player *player, Id id){

  /* Error control */
  if (!player || id == NO_ID){
    return ERROR;
  }

  inventory_set_obj(player->objects, id);

  return OK;
}

/* It deletes an object from the player inventory */
STATUS player_delete_object(Player *player, Id id) {

  /* Error control */
  if (!player || id == NO_ID){
    return ERROR;
  }

  if(inventory_del_object(player->objects,id)==ERROR){
    return ERROR;
  }

  return OK;
}

/* Prints all the information of the player */
STATUS player_print(Player *player){

  /* Error control */
  if (!player){
    return ERROR;
  }

  fprintf(stdout, "-->player (id: %ld; name: %s; location: %ld; health:%d; Inventory::", player->id, player->name, player->location, player->health);
  fprintf(stdout, "Inventory: ");
  inventory_print(player->objects);
  fprintf(stdout, ") \n");

  return OK;
}

/* Gets the health of the player */
int player_get_health(Player *player){

  /* Error control */
  if (!player){
    return -1;
  }

  return player->health;
}

/* Sets the health of the player */
STATUS player_set_health(Player *player, int health){
  
  /* Error control */
  if (!player || !health || health<0 ){
    return ERROR;
  }

  player->health = health;

  return OK;
}

/* It gets the set of the ids of the objects the player has in the inventory*/
STATUS player_get_inventory_ids(Player *player, Id *id){
  
  /* Error control */
  if (!player || !id){
    return ERROR;
  }

  set_id_objects(inventory_get_objs(player->objects), id);

  return OK;
}

/* Gets the number of objects the player has in its inventory */

int player_num_objects_inventory(Player *player){
  int num = 0;

  /* Error control */
  if (!player){
    return -1;
  }

  num = set_total_id(inventory_get_objs(player->objects));

  return num;
}


/* Gets the inventory of the player */
Inventory *player_get_inventory(Player *player){

  /* Error control */
  if (!player){
    return NULL;
  }

  return player->objects;
}

/* Sets the player inventory */
STATUS player_set_inventory(Player *player, Inventory *inventory){
  
  /* Error control */
  if (!player || !inventory){
    return ERROR;
  }

  player->objects = inventory;

  return OK;
}

/* Seachs for an object in the inventory of the player */
BOOL player_find_object_inventory(Player *player, Id id){

  /* Error control */
  if (!player || id == NO_ID){
    return FALSE;
  }

  /* Finds the object */
  if (inventory_find_object(player->objects, id) == TRUE){
    return TRUE;
  }

  /* Does not find the object */
  return FALSE;
}



