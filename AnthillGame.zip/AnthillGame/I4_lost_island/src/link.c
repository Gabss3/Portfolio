/**
 * @brief  It implements the link module and all the associated calls
 * for each command
 *
 * @file link.c
 * @author Blanca Matas
 * @version 1.0
 * @date 12-03-2023
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "link.h"

/* Delcares the link structure */
struct _Link{
    Id id;                      
    char name[WORD_SIZE + 1];   
    Id origin;                 
    Id destination;                
    DIRECTION direction;        
    ACCESS status;             
};

/* Creates a new link */
Link *link_create(Id id){
  Link *l = NULL;

  /* Error control */
  if (id == NO_ID){
      return NULL;
  }

  /* Allocates memory for a new link */
  l = (Link*)malloc(sizeof(Link));
  /* Error control */
  if (!l){
      return NULL;
  }

  /* Initialices all the link modules */
  l->id = id;
  l->name[0] = '\0';
  l->origin = NO_ID;
  l->destination = NO_ID;
  l->direction = NO_DIRECTION;
  l->status = -1;

  /* returns the newly created link */
  return l;
}

/* Destroys a given link */
STATUS link_destroy(Link *link){
  /* Error control */
  if(!link){
    return ERROR;
  }
  /* frees the previously allocated memory */
  free(link);
  return OK;
}

/* gets the link id */
Id link_get_id(Link *l){
  /* Error control */
  if(!l){
    return NO_ID;
  }
  
  return l->id;
}

/* Gets the name of the link */
char *link_get_name(Link *l){
  /* Error control */
  if(!l){
    return NULL;
  }
  return l->name;
}

/* Gets the origin of a given link */
Id link_get_origin(Link *l){
  /* Error control */
  if(!l){
    return NO_ID;
  }
  return l->origin;
}

/* Gets the destination of a links */
Id link_get_destination(Link *l){
  /* Error control */
  if(!l){
    return NO_ID;
  }
  return l->destination;
}

/* Gets the direction of a link */
DIRECTION link_get_direction(Link *l){
  /* Error control */
  if(!l){
    return NO_DIRECTION;
  }
  return l->direction;
}

/* Gets the status of a link */
ACCESS link_get_status(Link *link){
  /* Error control */
  if (!link){
      return -1;
  }

  return link->status;
}

/* Sets the id of a link */
STATUS link_set_id(Link *l, Id id){
  /* Error control */
  if(!l || id<0){
    return ERROR;
  }
  l->id = id;
  return OK;
}

/* Sets the name of a link */
STATUS link_set_name(Link *l, char *name){
  /* Error control */
   if(!l || !name){
    return ERROR;
  }
  strcpy(l->name, name);
  return OK;
}

/* Sets the origin of a link */
STATUS link_set_origin(Link *l, Id origin){
  /* Error control */
   if(!l || origin<0){
    return ERROR;
  }
  l->origin = origin;
  return OK;
}

/* Sets the destination of a link */
STATUS link_set_destination(Link *l, Id destination){
  /* Error control */
  if(!l || destination<0){
    return ERROR;
  }
  l->destination = destination;
  return OK;
}

/* Sets the direction of a link */
STATUS link_set_direction(Link *l, DIRECTION direction){

  /* Error control */
  if(!l || direction<0){
    return ERROR;
  }
  l->direction = direction;
  return OK; 
}


/* Sets the status os a link */
STATUS link_set_status(Link *link, ACCESS status){

  /* Error control */
  if(!link || status < 0 || status > 1){
    return ERROR;
  }

  link->status = status;

  return OK;
}


/* Prints all the link information*/

STATUS link_print(Link *l){
  /* Error control */
  if(!l){
    return ERROR;
  }

  fprintf(stdout, "%ld, %s, %ld, %ld, %d, %d", l->id, l->name, l->origin, l->destination, l->direction, l->status);
  return OK;
}



