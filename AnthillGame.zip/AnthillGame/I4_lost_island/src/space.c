/**
 * @brief It implements the space module and all the associated calls
 * for each command
 *
 * @file space.c
 * @author Profesores PPROG, Gabriella Leaño, Blanca Matas, Noelia Rincón
 * @version 3.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "space.h"
#include "set.h"

/**
 * @brief Space
 *
 * This struct stores all the information of a space.
 */
struct _Space{
  Id id;                          /*!< Id number of the space, it must be unique */  
  char name[WORD_SIZE + 1];       /*!< Name of the space */
  Set *objects;                   /*!< Whether the space has objects or not */
  char description[WORD_SIZE];    /*!< description of the space*/
  char gdesc[TAM1][TAM2];         /*!< gdesc module */
  BOOL light;                     /*!< Whether the space has light or not */
};

/* allocates memory for a new space and initializes its members*/
Space* space_create(Id id){
  Space *newSpace = NULL;
  int i;

  /* Error control */
  if (id == NO_ID)
    return NULL;

  newSpace = (Space *) malloc(sizeof (Space));
  if (newSpace == NULL) {
    return NULL;
  }

  /* Initialization of an empty space*/
  newSpace->id = id;
  newSpace->name[0] = '\0';
  newSpace->objects = set_create();
  newSpace->description[0] = '\0';

  for (i = 0; i < TAM1; i++){
    strcpy(newSpace->gdesc[i], "         ");
  }
  
  return newSpace;
}


/* frees the previous memory allocation for a space */
STATUS space_destroy(Space* space) {

  /* Error control */
  if (!space) {
    return ERROR;
  }
  
  set_destroy(space->objects);
  free(space);
  space = NULL;
  return OK;
}
/** It gets the name of a space */
STATUS space_set_id(Space *space, Id id){
  /* Error control */
  if(!space){
    return ERROR;
  }
  space->id = id;
  return OK;
  
}

/** It gets the id of a space */

Id space_get_id(Space* space){
  /* Error control */
  if (!space){
    return NO_ID;
  }
  return space->id;
}


/** It sets the name of a space */
STATUS space_set_name(Space* space, char* name){
  /* Error control */  
  if (!space || !name){
    return ERROR;
  }

  if (!strcpy(space->name, name)){
    return ERROR;
  }
  return OK;
}
/** It gets the name of a space */
const char * space_get_name(Space* space){

  
  /* Error control */  
  if (!space){
    return NULL;
  }
  return space->name;
}

/** It an object in the space*/
STATUS space_set_object(Space* space, Id id){
  /* Error control */
  if (!space){
    return ERROR;
  }

  
  set_add_id(space->objects, id);
  return OK;
}

/* It gets the number of objects in the space */
int space_num_objects(Space* space){
  int num_ob;

  /* Error control */
  if(!space){
    return -1;
  }

  num_ob = set_total_id(space->objects);

  return num_ob;
}

/** It prints the space information */
STATUS space_print(Space* space) {
  int i;
  long *ids = NULL;

  /* Error Control */
  if (!space) {
    return ERROR;
  }

  /* 1. Print the id and the name of the space */
  fprintf(stdout, "--> Space (Id: %ld; Name: %s)\n", space->id, space->name);
 
  /* 2. Print if there is an object in the space or not */

  if(space_num_objects(space) == 0){
    fprintf(stdout, "--->No objects in the space\n");
  }
  space_id_objects(space, ids);

  for(i=0; i < space_num_objects(space); i++){
    
    fprintf(stdout, "---> Object %ld in the space.\n",ids[i]);
    
  }

  return OK;
}

/* It gets the set of objects in the space */
Set *space_get_array(Space *space){

  /* Error control */
  if (!space){
    return NULL;
  }
  return space->objects;
}

/* It gets the description of the space */
char *space_get_description(Space *space){

  /* Error control */
  if (!space){
    return NULL;
  }

  return space->description;
}

/* It sets the description of the space */
STATUS space_set_description(Space *space, char *description){

  /* Error control */
  if (!space || !description){
    return ERROR;
  }

  if (!strcpy(space->description, description)){
    return ERROR;
  }

  return OK;
}


/* It deletes an object in the space */
STATUS space_del_object(Space *s, Id id){
  /* Error control */
  if (!s || !id){
    return ERROR;
  }

  if (!set_del_id(s->objects, id)){
    return ERROR;
  }

   return OK;
}

/* It searchs for an object in an space */
BOOL space_has_object(Space *s, Id id){

  /* Error control */
  if (!s){
    return FALSE;
  }
  if (set_id_exists(s->objects, id) == FALSE){
    return FALSE;
  }

  return TRUE;
}

/* It gets the ids of the objects in the space */
STATUS space_id_objects(Space *space, Id *ids){

  /* Error control */
  if (!space || !ids){
    return ERROR;
  }
  set_id_objects(space->objects, ids);

  return OK;
}


/* It sets the space gdesc */

STATUS space_set_gdesc(Space *space, char *string, int position){
  /* Error control */
  if (!space || !string || position < 0 ){
    return ERROR;
  }

  if (strlen(string) == TAM2 - 1){
    strcpy(space->gdesc[position], string);
    return OK;
  }

  return ERROR;
  
}

/* It gets the space gdesc */
char *space_get_gdesc(Space *space, int position){
  
  /* Error control */
  if (!space || position < 0){
    return NULL;
  }

  return space->gdesc[position];
  
}

/* It sets the objects in the space */
STATUS space_set_set(Space *space, Set *set){

  /* Error control */
  if (!space || !set){
    return ERROR;
  }

  space->objects = set;
  return OK;
}


/* It sets the light of the space */
STATUS space_set_light(Space *space, BOOL light) { 

  /* Error control */
  if (!space){
    return ERROR;
  }

  space->light = light;
  return OK;
}

/* It gets the light of the space */
BOOL space_get_light(Space *space) {

  /* Error control */
  if (!space){
    return FALSE;
  }

  return space->light;
}

/* It prints the state of the light in the space */
STATUS space_light_print(Space *space){
  
  /* Error control */
  if (!space){
    return ERROR;
  }
  if(space_get_light(space) == TRUE){
    fprintf(stdout, "Light is on");
  }
  else{
    fprintf(stdout, "Light is off");
  }
  fprintf(stdout, ") \n");

  return OK;
}

