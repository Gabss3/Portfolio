/**
 * @brief It implements the object module and all the associated calls
 * for each command
 *@file object.c
 * @author Noelia Rincón, Blanca Matas
 * @version 1.0
 * @date 09-02-2023
 * This struct stores all the information of an object.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "object.h"

/**
 * @brief structure of an object
 */
struct _Object
{
  Id id;                            /*!< Id, id of an object */
  char name[WORD_SIZE];             /*!< name of an object */
  char desc[WORD_SIZE];             /*!< Description of an object */
  BOOL hidden;                      /*!< Characteristic of the object */
  BOOL movable;                     /*!< Characteristic of the object */
  Id dependency;                    /*!< Characteristic of the object */
  Id open;                          /*!< Characteristic of the object */
  BOOL turnedon;                    /*!< Characteristic of the object */
  BOOL light;                       /*!< Characteristic of the object */
};



/* allocates memory for a new object */
Object *object_create(Id id)
{
   Object *object = NULL;

  /* Error control */
  if (id == NO_ID){
    return NULL;
  }
  /*Allocates memory for the object*/
  object = (Object *) malloc(sizeof (Object));
  if (object == NULL) {
    return NULL;
  }

  /* Initialization of an object*/
  object->id = id;
  object->name[0] = '\0';
  object->desc[0] = '\0';

  return object;
}

/*frees the previous memory allocation for an object */

STATUS object_destroy(Object *object) {
  /*Error control*/
  if (!object){
    return ERROR;
  }

/*frees memory of object*/
  free(object);
  object = NULL;
  return OK;
}

/*Sets the object id*/
STATUS object_set_id(Object* object, Id id) {
  if(!object || id == NO_ID){
    return ERROR;
  }

  object->id = id;
  return OK;
}

/*Gets the id of the object*/
Id object_get_id(Object* object){
  
  if (!object){
    return NO_ID;
  }
  
  return object->id;
}

STATUS object_set_name(Object *object, char *name) {
  /*Error control*/
 if (!object || !name){
    return ERROR;

 }
  /*Makes sure the name of the object has been set correctly*/
  if (!strcpy(object->name, name)){
    return ERROR;
  }

  return OK;
}

/*Gets the name of the object*/
const char * object_get_name(Object* object){
  /*Error control*/
  if (!object) {
    return NULL;
  }
  return object->name;
}

/* Sets the description of an object */
STATUS object_set_description(Object* object, const char* descr) 
{
  /* Error control */
  if (!object || !descr){
    return ERROR;
  }

  strcpy(object->desc, descr);
  strcat(object->desc, "\0");

  return OK;
}

/* Gets the description of an object */
const char* object_get_description(Object* object) {

  /*Error control*/
  if (!object){
    return NULL;
  }

  return object->desc;
}

/* Prints all the object information */
STATUS object_print(Object *object){
  /* Error control */
  
  if (!object){
    return ERROR;
  }

  fprintf(stdout, "%ld, %s)\n", object->id, object->name);

  return OK;
}

/* deletes the name of an object if its name coincides with the name given*/

STATUS object_del_obj_name(Object *object, char* name){
  /* Error control */
  if (!object || !name){
    return ERROR;
  }

  if(strcmp(object->name, name) == 0){
    strcpy(object->name, " ");
  }
  return OK;
    
}

/* checks if the object has light*/

BOOL object_has_light(Object *object){
  
  /* Error control */
  if (!object){
    return FALSE;
  } 

  return object->light;
}

/*sets the object's light*/

STATUS object_set_light(Object *object, BOOL light){
   /* Error control */
  if (!object){
    return ERROR;
  }

  object->light = light;
  return OK;
}

/* checks if the object is hidden*/

BOOL object_is_hidden(Object *object){
   /* Error control */
  if (!object){
    return FALSE;
  } 

  return object->hidden;
}

/*sets the object's hiddeness*/

STATUS object_set_hidden(Object *object, BOOL hidden){
  /* Error control */
  if (!object){
    return ERROR;
  }

  object->hidden = hidden;
  return OK;
}
/* checks if the object is movable*/
BOOL object_is_movable(Object *object){
  /* Error control */
  if (!object){
    return FALSE; 
  } 

  return object->movable;
}
/*sets the object's movility*/
STATUS object_set_movable(Object *object, BOOL movable){
  if (!object){
    return ERROR;
  }

  object->movable = movable;
  return OK; 
}

/* checks if the object is dependent*/
BOOL object_is_dependent(Object *object){
   /* Error control */
  if (!object){
    return FALSE; 
  } 

  return object->dependency;
}
/*sets the object's dependency*/

STATUS object_set_dependency(Object *object, Id dependency){
  /* Error control */
  if (!object){
    return ERROR;
  }

  object->dependency = dependency;
  return OK; 
}
/* checks if the object can open a door*/
BOOL object_can_open(Object *object){
  /* Error control */
  if (!object){
    return FALSE; 
  } 
  if(object->open != -1){
    return TRUE;
  }

  return FALSE;
}
/*gets what thing can the object open*/

Id object_get_open(Object *object){
  /* Error control */
  if(!object){
    return -1;
  }

  return object->open;

}
/*sets the object's ability to open*/

STATUS object_set_open(Object *object, Id open){
  /* Error control */
  if (!object){
    return ERROR;
  }

  object->open = open;
  return OK; 
}
/* checks if the object is turnedon*/

BOOL object_is_turnedon(Object *object){
  /* Error control */
  if (!object){
    return FALSE; 
  } 

  return object->turnedon;
}

/*sets the object's ability to turn on*/
STATUS object_set_turnedon(Object *object, BOOL turnedon){
  if (!object){
    return ERROR;
  }

  object->turnedon = turnedon;
  return OK; 
}

/* finds the object dependency*/
BOOL object_find_dependence(Object *object, Inventory *inventory){
/* Error control */
  if (!object || !inventory){
    return FALSE;
  }


  if (object->dependency != NO_ID){
    return set_id_exists(inventory_get_objs(inventory), object->dependency);
  }

  return TRUE;
}

/* finds the object dependency id*/

Id object_dependency_id(Object *object){
  /* Error control */
  if(!object){
    return -1;
  }
  return object->dependency;
}