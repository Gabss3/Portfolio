/** 
 * @brief It implements the game interface and all the associated calls
 * for each command
 * 
 * @file game.c
 * @author Profesores PPROG, Blanca Matas, Noelian Rincón, Gabriella Leaño
 * @version 3.0 
 * @date 26-01-2023 
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "game.h"
#include "game_rules.h"
#include "game_management.h"
#define TAM 100

/**
 * @brief The game structure
 *
 * Stores all the information of the game
 */
struct _Game
{
  Player *player;              /* Player in the game */
  Object *object[MAX_OBJECTS]; /* Objects in the game */
  Space *spaces[MAX_SPACES];   /* Spaces of the game */
  T_Command command;           /* Command of the game */
  Enemy *enemy;                /* enemy in the game */
  Link *links[MAX_LINKS];      /* Links of the game */
  STATUS st;                   /* State for the commands */
  char *description;           /* Sctual description that is asked for command */
  Dialogue *d;                 /* Dialogue of the game*/
  int cherry;                  /* Number of times a player moves to the cherries space*/
};


/** PRIVATE FUNCTIONS: COMMANDS OF THE GAME*/

/**
 * @brief Executes the command unknown
 * @author Profesores PPROG
 *
 * @param game pointer to the game
 */
void game_command_unknown(Game *game);

/**
 * @brief Executes the command exit game
 * @author Profesores PPROG
 *
 * @param game pointer to the game
 */
void game_command_exit(Game *game);

/**
 * @brief Executes the command south
 * @author Blanca Matas
 *
 * @param game pointer to the game
 */
void game_command_south(Game *game);

/**
 * @brief Executes the command north
 * @author Blanca Matas
 *
 * @param game pointer to the game
 */
void game_command_north(Game *game);

/**
 * @brief Executes the command up
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 */

void game_command_up(Game *game);

/**
 * @brief Executes the command down
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 */
void game_command_down(Game *game);

/**
 * @brief Executes the command take
 * @author Noelia Rincón
 *
 * @param game pointer to the game
 */
STATUS game_command_take(Game *game);

/**
 * @brief Executes the command drop
 * @author Noelia Rincón
 *
 * @param game pointer to the game
 */
STATUS game_command_drop(Game *game);

/**
 * @brief Executes the command east
 * @author Blanca Matas
 *
 * @param game pointer to the game
 */
void game_command_east(Game *game);

/**
 * @brief Executes the command west
 * @author Blanca Matas
 *
 * @param game pointer to the game
 */
void game_command_west(Game *game);

/**
 * @brief Executes the command attack
 * @author Blanca Matas
 *
 * @param game pointer to the game
 */
void game_command_attack(Game *game);

/**
 * @brief Executes the command move
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 */
void game_command_move(Game *game);

/**
 * @brief Executes the command inspect
 * @author gabriella Leano
 *
 * @param game pointer to the game
 */
void game_command_inspect(Game *game);

/**
 * @brief Executes the command open
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 */
STATUS game_command_open(Game *game);



/**GAME INTERFACE IMPLEMENTATION*/

/*Creates the game*/
Game *game_create(){
  Game *game=NULL;
  int i=0;

  game = (Game *)malloc(sizeof(Game));
  if (!game){
    return NULL;
  }

  /* it initializes the maximun number of spaces defined previously*/
  for (i = 0; i < MAX_SPACES; i++){
    game->spaces[i] = NULL;
  }

  /* it initializes the maximun number of objects defined previously*/
  for (i = 0; i < MAX_OBJECTS; i++){
    game->object[i] = NULL;
  }

  /* It initializes the comand*/
  game->command = NO_CMD;

  /* It initializes the maximun number of links defines previously */
  for (i = 0; i < MAX_LINKS; i++){
    game->links[i] = NULL;
  }

  /* It initializes the player, the enemy and the state of the command*/
  game->player = NULL;
  game->enemy = NULL;
  game->st = OK;

  game->description = (char *)malloc(WORD_SIZE * sizeof(char));
  if (!(game->description)){  
    return NULL;
  }

  game->d = dialogue_create();
  if (!(game->d)){
    return NULL;
  }

  game->cherry = 0;

  return game;
}

/* Destroys a game*/
STATUS game_destroy(Game *game){
  int i=0;

  /* Error control*/
  if (!game){
    return OK;
  }

  /* It destroys the spaces that had been created */
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    space_destroy(game->spaces[i]);
  }

  /* It destroys the objects, the player and the enemy */
  for (i = 0; i < MAX_OBJECTS; i++){
    object_destroy(game->object[i]);
  }

  player_destroy(game->player);
  enemy_destroy(game->enemy);

  /* It destroys the links that had been created */
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    link_destroy(game->links[i]);
  }

  if (game->enemy != NULL){
    game->enemy = NULL;
  }

  dialogue_destroy(game->d);

  free(game->description);
  free(game);

  return OK;
}



/**Game Player Functions*/

/* Gets the plater in the game*/
Player *game_get_player(Game *game){
  /* Error control*/
  if (!game){
    return NULL;
  }

  return game->player;
}

/* Adds a player to the game*/
STATUS game_add_player(Game *game, Player *player){
  /* Error control*/
  if (!game || !player){
    return ERROR;
  }

  game->player = player;

  return OK;
}

/* Sets the location of the player in the game*/
STATUS game_set_player_location(Game *game, Id id){
  /* Error control*/
  if (!game || id== NO_ID){
    return ERROR;
  }

  /* sets the id to the player location*/
  player_set_location(game->player, id);

  return OK;
}

/* Gets the location where the player is*/
Id game_get_player_location(Game *game){
  /* Error control */
  if (!game){
    return NO_ID;
  }
  return player_get_location(game->player);
}

/* Gets the space where the player is*/
Space *game_get_player_space(Game *game, Player *player){
  int i;
  Space *p_space = NULL;
  Id p_location;
  
  /* Error control */
  if (!game || !player){
    return NULL;
  }

  /*gets the id of the space where the player is */
  p_location = game_get_player_location(game);

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    /* searchs for the space corresponding to the id and saves the position */
    if (p_location == space_get_id(game->spaces[i])){
      p_space = game->spaces[i];
      return p_space;
    }
  }

  return NULL;
}



/**Game Object Functions*/

/* Gets the id of an object given its name*/
Id _game_get_object_id_from_name(Game *game, char *name){
  int i = 0;
  Id id = NO_ID;
  BOOL f = FALSE;

  for(i=0; i < TAM && f == FALSE; i++){
    
    if (object_get_name(game->object[i]) != NULL){
      
      if (strcmp(object_get_name(game->object[i]), name) == 0){
        id = object_get_id(game->object[i]);
        f = TRUE;
      }
    }
  }
  return id;
}

/* Gets an object in the game given its id*/
Object *game_get_object(Game *game, Id id){
  int i = 0;
  
  /* Error control */
  if (!game || id == NO_ID){
    return NULL;
  }
  /* Searchs in the object array for an object corresponding to that id*/
  for (i = 0; i < MAX_OBJECTS && game->object[i] != NULL; i++){
    if (object_get_id(game->object[i]) == id){
      return game->object[i];
    }
  }

  return NULL; /* The object doesnt exists */
}

/*Gets the id of an object given its position in the object array of the game*/
Id game_get_object_id_at(Game *game, int position){
  if (!game){
    return NO_ID;
  }

  return object_get_id(game->object[position]);
}

/* Adds an object to the game*/
STATUS game_add_object(Game *game, Object *object){
  int i = 0;

  /* Error control */
  if (!game || !object){
    return ERROR;
  }

  /* Searchs for a free position in the object array */
  for(i=0; i<MAX_OBJECTS && game->object[i]!=NULL; i++){
    if(i>=MAX_OBJECTS){
      return ERROR;
    }
  }
   /* if it isnt full it adds an object to the game */
  game->object[i] = object;

  return OK;
}

/* Sets the location of an object*/
STATUS game_set_object_location(Game *game, Id space_id, Id object_id){
  int i=0;

  /* Error control */
  if (!game || object_id == NO_ID || space_id == NO_ID){
    return ERROR;
  }

  /* Searchs for the space corresponding to the id space*/
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    if (space_get_id(game->spaces[i]) == space_id){
      /* Adds the object to the space*/
      return space_set_object(game->spaces[i], object_id);
    }
  }
  return OK;
}

/* Gets the location of an object given its id*/ 
Id game_get_object_location(Game *game, Id id){
  int i;
  Id obj_Id = NO_ID, obj_location = NO_ID;

  /* Error control */
  if (!game || id == NO_ID){
    return NO_ID;
  }

  /* Seachs for the object in the objecr array */
  for (i = 0; i < MAX_OBJECTS; i++){
    obj_Id = object_get_id(game->object[i]);
    /* finds the object*/
    if (obj_Id == id){
      break; 
    }
  }

  /*Searchs if the object is in any of the game spaces */
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){

    if (space_has_object(game->spaces[i], obj_Id) == TRUE){
      /* returns the space id if it finds it */
      obj_location = space_get_id(game->spaces[i]);

      return obj_location;
    }
  }
  return NO_ID; /* returns NO_ID if it doesnt find it because is the player who has it */
}

/* Gets the ids of the objects in a game*/
STATUS game_get_objects_ids(Game *game, Id *ids){
  Id *aux_ids;
  int i, j, k;
   /* Error control */
  if (!game || !ids){
    return ERROR;
  }

  /* Allocate memory for ids auxiliar */
  aux_ids = (Id*)malloc(MAX_SET_IDS*sizeof(Id));
  if (!aux_ids){
    return ERROR;
  }
  
  /* goes though all the spaces array*/
  for (i = 0, j = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    /* gets the array of ids of the space */
    space_id_objects(game->spaces[i], aux_ids);

    /* goes though the id array*/
    for (k = 0; aux_ids[k] != NO_ID && aux_ids[k] != 0; j++, k++){
      /* adds all the ids to the id array of the gamee */
      ids[j] = aux_ids[k];
    }
  }
  free(aux_ids);
  return OK;
}

/* It gets an object given its name*/
Object *game_get_object_by_name(Game *game, char *name){
  int i=0;

  /* Error control */
  if (!game || !name || name[0] == '\0'){
    return NULL;
  }
  /*goes though all the objects and if it finds it, returns it*/
  for (i = 0; i < MAX_OBJECTS && game->object[i] != NULL; i++){
    if (strcmp(object_get_name(game->object[i]), name) == 0){
      return game->object[i];
    }
  }
  return NULL; /* there is no object with that name in the game */
}



/**Game cherry functions*/

/* Sets the number of times the player visits the cherry*/
STATUS game_set_cherry(Game *game, int cherry){
  if(!game || cherry<0){
    return ERROR;
  }
  game->cherry = cherry;
  return OK;
}

/* Gets the number of times the player has visited the cherry*/
int game_get_cherry(Game *game){
  if(!game){
    return -1;
  }
  return game->cherry;
}



/**Game Space Functions*/

/* Adds a space to the game*/
STATUS game_add_space(Game *game, Space *space){
  int i = 0;

  /* Error control */
  if (!game || !space){
    return ERROR;
  }

  /* searchs for a free position in the space array to create the new space*/
  while (i < MAX_SPACES && game->spaces[i] != NULL){
    i++;
  }

  /* If the array of spaces is not full it initializes a new space*/
  game->spaces[i] = space;

  return OK;
}

/* Gets the id of a space given its position in the space array of the game*/
Id game_get_space_id_at(Game *game, int position){
  /* Error control */
  if (!game || position < 0 || position >= MAX_SPACES){
    return NO_ID;
  }

/*Returns the id of a space*/
  return space_get_id(game->spaces[position]);
}

/* Gets the space given its id*/
Space *game_get_space(Game *game, Id id){
  int i = 0;

  /* Error control */
  if (!game || id == NO_ID){
    return NULL;
  }

  /* Searchs for the space th id corresponds to, and returns it*/
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    if (id == space_get_id(game->spaces[i])){
      return game->spaces[i];
    }
  }
  
  return NULL;
}



/**Game Link Functions*/

/* Adds a link to the game */
STATUS game_add_link(Game *game, Link *link){
  int i = 0;

/* Error control */
  if (!game || !link){
    return ERROR;
  }

  for(i=0; i<MAX_LINKS && game->links[i]!=NULL; i++){
    if(i>=MAX_LINKS){
      return ERROR;
    }
  }

  /* If there is a free position it adds the link to the game*/
  game->links[i] = link;

  return OK;
}

/* It gets a link in the game*/
Link *game_get_link(Game *game, Id id){
  int i = 0;

/* Error control */
  if (!game || id == NO_ID){
    return NULL;
  }

/*Searchs for the link th id corresponds to, and returns it*/
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    
    if (id == link_get_id(game->links[i])){
      return game->links[i];
    }
  }

  return NULL;
}

/* Gets the id of a link given its position in the link array of the game*/
Id game_get_link_id_at(Game *game, int position){
  if (!game){
    return NO_ID;
  }

  return link_get_id(game->links[position]);
}

/* Gets a link given its name*/
Link *game_get_link_by_name(Game* game, char *name){
  int i = 0;

  /* Error control */
  if (!game || !name || name[0] == '\0'){
    return NULL;
  }
  /*goes though all the objects and if it finds it, returns it*/
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    if (strcmp(link_get_name(game->links[i]), name) == 0){
      return game->links[i];
    }
  }
  return NULL;
}

/* Gets a destiny of a connection of a link in the game*/
Id game_get_connection(Game *game, Id origin, DIRECTION dir){
  int i = 0;

  /* Error control */
  if (!game || origin == NO_ID){
    return NO_ID;
  }

  /*Searchs for the  given link, and return its destination id*/
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    if ((origin == link_get_origin(game->links[i])) && (dir == link_get_direction(game->links[i]))){
      return link_get_destination(game->links[i]);
    }
  }
  return NO_ID; /* The connection doesnt exists */
}

/* It gets the connection status, open or closed*/
ACCESS game_get_connection_status(Game *game, Id origin, DIRECTION dir){
  int i = 0;

  /* Error control */
  if (!game || origin == NO_ID){
    return -1;
  }
  /* search for the link and return its status*/
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    if ((origin == link_get_origin(game->links[i])) && (dir == link_get_direction(game->links[i]))){
      return link_get_status(game->links[i]);
    }
  }
  return -1;
}

/* Sets the access status between two spaces, opened or closed */
STATUS game_set_connection_status(Game *game, Id origin, DIRECTION dir, ACCESS acc){
  int i=0;
  /*ERROR CONTROL*/
  
  if (!game || origin == NO_ID){
    return ERROR;
  }

  /*Searchs for a link with the origin and direction given and sets the status*/
  for (i = 0; i < MAX_LINKS && game->links[i] != NULL; i++){
    if ((origin == link_get_origin(game->links[i])) && (dir == link_get_direction(game->links[i]))){
      link_set_status(game->links[i], acc);
      return OK;
    }
  }
  /*If something goes wrong it returns error*/
  return ERROR;
}



/**Game Enemy Functions*/

/* Adds an enemy to the game*/
STATUS game_add_enemy(Game *game, Enemy *enemy){
  /* Error control */
  if (!game || !enemy){
    return ERROR;
  }

  game->enemy = enemy;
  
  return OK;
}

/* Gets the enemy in the game*/
Enemy *game_get_enemy(Game *game){
  /* Error control */
  if (!game){
    return NULL;
  }

  return game->enemy;
}



/**Game Description Functions*/

/*sets the actual description*/
STATUS game_set_act_description(Game *game, char *desc){
  /* Error control*/
  if (!game || !desc || desc[0] == '\0'){
    return ERROR;
  }

  strcpy(game->description, desc);

  return OK;
}

/*Gets the actual description*/
char *game_get_act_description(Game *game){
  /* Error control*/
  if (!game){
    return NULL;
  }
  return game->description;
}



/**Game Command Functions Implementation*/

/* if the game has ended or not */
BOOL game_is_over(Game *game){
  /* Error control*/
  if (!game){
    return FALSE;
  }
  /* the game ends if the player health is -1 */
  if (player_get_health(game->player) == -1){
    return TRUE;
  }

  return FALSE;
}

/* Updates the game depending on the introduced command */
STATUS game_update(Game *game, T_Command cmd){
  game->command = cmd;

  /* Error control */
  if (!game){
    return ERROR;
  }

   /* Executes the introduced command */
  switch (cmd){
  case UNKNOWN:
    game_command_unknown(game);
    break;

  case EXIT:
    game_command_exit(game);
    break;

  case TAKE:
    game->st = game_command_take(game);
    break;

  case DROP:
    game->st = game_command_drop(game);
    break;

  case ATTACK:
    game_command_attack(game);
    break;

  case MOVE:
    game_command_move(game);
    break;

  case INSPECT:
    game_command_inspect(game);
    break;

  case OPENED:
    game->st = game_command_open(game);
    break;

  case TURNON:
    game->st = game_command_turnon(game);
    break;

  case TURNOFF:
    game->st = game_command_turnoff(game);
    break;
  case SAVE:
    game_command_save(game);
    break;
  case LOAD:
    game_command_load(game);
    break;

  default:
    break;
  }

  return OK;
}

/* gets the last command introduced*/
T_Command game_get_last_command(Game *game){
  if(!game){
    return NO_CMD;
  }
  return game->command;
}

/* Function called when the command introduced is unknown */
void game_command_unknown(Game *game){
  game->st = ERROR;
}

/* Function called when the command introduced is exit*/
void game_command_exit(Game *game){}

/* Function called when the command introduced is south, if possible moves the player south*/
void game_command_south(Game *game){
  Id id = NO_ID;
  Space *space = NULL;
  
  /* gets the actual space of the player */
  space = game_get_player_space(game, game->player);

  /* Error control*/
  if (!space){
    return;
  }

  id = game_get_connection(game, space_get_id(space), S);

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), S) == OPEN)){
    game_set_player_location(game, id);
    
    game_set_player_location(game, id);
    
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is north, if possible moves the player north*/
void game_command_north(Game *game){
  Id id = NO_ID;
  Space *space= NULL;


  /* gets the actual space of the player*/
  space = game_get_player_space(game, game->player);

  /* Error control*/
  if (!space){
    return;
  }

  id = game_get_connection(game, space_get_id(space), N);

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), N) == OPEN)){
    game_set_player_location(game, id);
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is east, if possible moves the player east*/
void game_command_east(Game *game){
  
  Id id = NO_ID;
  Space *space = NULL;
  
  /* gets the actual space of the player*/
  space = game_get_player_space(game, game->player);

  /*Error control*/
  if (!space){
    return;
  }
  id = game_get_connection(game, space_get_id(space), E);

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), E) == OPEN)){
    game_set_player_location(game, id);
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is west, if possible moves the player west*/
void game_command_west(Game *game){
  Id id = NO_ID;
  Space *space = NULL;

  /* gets the actual space of the player*/
  space = game_get_player_space(game, game->player);

  /* Error control */
  if (!space){
    return;
  }

  id = game_get_connection(game, space_get_id(space), W);

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), W) == OPEN)){
    game_set_player_location(game, id);
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is up, if possible moves the player up*/
void game_command_up(Game *game){
  Id id = NO_ID;
  Space *space = NULL;

  /* gets the actual space of the player*/
  space = game_get_player_space(game, game->player);

  /* Error control */
  if (!space){
    return;
  }
  id = game_get_connection(game, space_get_id(space), U);

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), U) == OPEN)){
    game_set_player_location(game, id);
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is down, if possible moves the player down*/
void game_command_down(Game *game){
  Id id = NO_ID;
  Space *space = NULL;


  /* gets the actual space of the player*/
  space = game_get_player_space(game, game->player);

  /*Error control*/  
  if (!space){
    return;
  }
  id = game_get_connection(game, space_get_id(space), D);

  if(id == 33){
    game_set_player_location(game, id);
    gm_teletransport_player(game);
    return;
  }

  if (id != NO_ID && (game_get_connection_status(game, space_get_id(space), D) == OPEN)){
    game_set_player_location(game, id);
    game->st = OK;
  }
  else{
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is take, if possible takes the specified object*/
STATUS game_command_take(Game *game){
 int i, flag=0;
  Space *space = NULL;
  char name[TAM +1];
  Id id;

  /*saves the name of the object*/
  if (scanf(" %s", name) == 0){
    return ERROR;
  }
    /*gets the id of the object*/
  id = _game_get_object_id_from_name(game, name);

   if (game == NULL || id == NO_ID){
    return ERROR;
  }
  
  for (i = 0; i < TAM; i++){
    if (object_get_id(game->object[i]) == id){
      flag++;
    }
  }
  if (flag == 0){
    return ERROR;
  }
 
  /*makes sure that the object is in the space where the player is*/
  if (space_has_object(game_get_space(game, game_get_player_location(game)),id) == FALSE){ 
    return ERROR;
 }
  if ((space = game_get_space(game, game_get_player_location(game))) == NULL){
    return ERROR;
  }

  if(strcmp(name, "berry") == 0){
    player_set_health(game->player, player_get_health(game->player) - 1);
    player_set_object(game->player, id);
    space_del_object(space, id);
    return OK;
  }
  if(strcmp(name, "cherry") == 0 && gm_cherry_hidden(game)==FALSE){
    player_set_health(game->player, player_get_health(game->player) + 1);
    player_set_object(game->player, id);
    space_del_object(space, id);  
    return OK;
  }

  if(object_is_movable(game_get_object(game, id)) == FALSE){
    return ERROR;
  }

  if(object_is_hidden(game_get_object(game, id))==TRUE){
    return ERROR;
  }

  if(object_is_dependent(game_get_object(game, id)) != NO_ID){
    if (object_find_dependence(game_get_object(game, id), player_get_inventory(game->player)) == FALSE){
      return ERROR;
    }
  }

  /* deletes the object from the space and adds it to the player*/
  space_del_object(space, id);
  player_set_object(game->player, id);
  
  return OK;
}

/* Function called when the command introduced is drop, if possible drops the specified object*/
STATUS game_command_drop(Game *game){
  char name[TAM +1];
  Id id;
  int i;
  int flag = 0;
  Space *space = NULL;

   /* Error control */
  if(!game){
    return ERROR;
  }
   /* saves the name of the objecr*/
  if (scanf(" %s", name) == 0){
    return ERROR;
  }
  /* save sthe id of the object*/
  id = _game_get_object_id_from_name(game, name);

  /* makes sure the object is in the game*/
  for (i = 0; i < TAM; i++) {
    if (object_get_id(game->object[i]) == id){
      flag=1;
    }
  }
  if (flag == 0){
    return ERROR;
  }

  if(strcmp(name, "cherry")==0){
    gm_cherry_drop(game);
    return OK;
  }

  /* gets the space of the player*/
  space = game_get_space(game, game_get_player_location(game));

    /* deletes the object from the player and adds it to the space where the player is*/
    player_delete_object(game->player, id);
    space_set_object(space, id);

    return OK;
}

/* Function called when the command introduced is attack, if possible attacks the enemy*/
void game_command_attack(Game *game){
  
  int attack;
  
  /* Error control */
  if (!game){
    return;
  }
  /* deletes the description because a new command has been introduced */
  game_set_act_description(game, "  ");

  /* generates a number between 0 to 9 */
  attack = rand() % 10;

  if (enemy_get_location(game->enemy) == game_get_player_location(game)){
    /* if the number is between 0-4, the enemy attacks*/
    if (attack >= ATTACK_MIN && attack <= ATTACK_MED){
        /* if the player is attacked, its health decreases by 1, and if its health is 0, the game ends */
      if (game_is_over(game) == FALSE){
        player_set_health(game->player, player_get_health(game->player) - 1);
    
        game->st = OK;
        return;
        
      }
    }

     /* if the number is between 5-9, the player attacks */
    
    if (attack > ATTACK_MED && attack <= ATTACK_MAX && enemy_get_location(game->enemy) == game_get_player_location(game)){
      
      if (enemy_get_health(game->enemy) > 0){
          enemy_set_health(game->enemy, enemy_get_health(game->enemy) - 1);
    
          game->st = OK;

        if (enemy_get_health(game->enemy) == 0){
          
          enemy_destroy(game->enemy);
          game->enemy = NULL;
          gm_masterkey_appearing(game);
        }
        return;
      }
    }
  }
  else{  
    
    game->st = ERROR;
  }
  return;
}

/* Function called when the command introduced is move*/
void game_command_move(Game *game){
  char direction[WORD_SIZE];

  if (!game){
    return;
  }
  /* The description is removed beacause a new command had been introduced */
  game_set_act_description(game, "  ");
  if (scanf(" %s", direction) == 0){
    return;
  }
   /* depending on the description a command is executed*/
  if (strcmp("w", direction) == 0 || strcmp("west", direction) == 0){
    game_command_west(game);
    return;
  }

  if (strcmp("e", direction) == 0 || strcmp("east", direction) == 0){
    game_command_east(game);
    return;
  }

  if (strcmp("n", direction) == 0 || strcmp("north", direction) == 0){
    game_command_north(game);
    return;
  }

  if (strcmp("s", direction) == 0 || strcmp("south", direction) == 0){
    game_command_south(game);
    return;
  }
  if (strcmp("u", direction) == 0 || strcmp("up", direction) == 0){
    game_command_up(game);
    return;
  }
  if (strcmp("d", direction) == 0 || strcmp("down", direction) == 0){
    game_command_down(game);
    return;
  }
  game->st = ERROR;
  return;
}

/* Function called when the command introduced is inspect, if possible inspects the space or object specified*/
void game_command_inspect(Game *game){ 
  Space *player_space = NULL;
  Id objects[MAX_OBJECTS];
  char *description = NULL;
  char name[WORD_SIZE + 1];
  Object *object = NULL;
  int i;

  /*Error control*/
  if (!game){
    return;
  }

  /* allocates memory for the description */
  description = (char *)malloc(WORD_SIZE * sizeof(char));
  if (!description){
    return;
  }
  if (scanf(" %s", name) == 0){
    return;
  }

  player_space = game_get_player_space(game, game->player);
  game_get_objects_ids(game, objects);

  /* if is introduced "s" or "space", the game will save the description of the space where the player is 
   */
  
  if (strcmp(name, "s") == 0 || strcmp(name, "space") == 0){
    if(space_get_light(player_space) == FALSE){
      strcpy(description, "The space does not have light, try to find something to illuminate it.");
    }
    /* The description is added to the game */
    game_set_act_description(game, description);
  
    for(i=0; i<MAX_OBJECTS; i++){
      if((game_get_player_location(game) == game_get_object_location(game, objects[i])) && object_is_hidden(game_get_object(game, objects[i])) == TRUE){
        
        if(strcmp("masterkey", object_get_name(game_get_object(game, objects[i])))==0 || strcmp("cherry", object_get_name(game_get_object(game, objects[i])))==0){
          game->st = OK;
          free(description);
          return;
        }
        else
        object_set_hidden(game_get_object(game, objects[i]), FALSE);
      }
    }
    
    game->st = OK;

    free(description);

    return;
  }

  /* if instead, we want to inspect an object and the name isnt any of the name of the objects in the game the command doesnt work */
  if (strncmp("shell", name, sizeof(char)) != 0 && strncmp("rock", name, sizeof(char)) != 0 && strncmp("palm", name, sizeof(char)) != 0 && strncmp("scissors", name, sizeof(char)) != 0&& strncmp("fruit", name, sizeof(char)) != 0&& strncmp("scissors", name, sizeof(char)) != 0&& strncmp("scissors", name, sizeof(char)) != 0&& strncmp("fan", name, sizeof(char)) != 0&& strncmp("rope", name, sizeof(char)) != 0&& strncmp("dog", name, sizeof(char)) != 0&& strncmp("pliers", name, sizeof(char)) != 0&& strncmp("key", name, sizeof(char)) != 0&& strncmp("orange", name, sizeof(char)) != 0&& strncmp("seagull", name, sizeof(char)) != 0&& strncmp("flash", name, sizeof(char)) != 0&& strncmp("battery", name, sizeof(char)) != 0 && strncmp("cherry", name, sizeof(char)) != 0 && strncmp("masterkey", name, sizeof(char)) != 0){
    game->st = ERROR;
    free(description);
    return;
  }

  object = game_get_object_by_name(game, name);

  /* If the object does exist in the game, it must be in the player location or in the player inventory in order to be inspected*/
  if ((space_has_object(player_space, object_get_id(object)) == TRUE) || (player_find_object_inventory(game->player, object_get_id(object)) == TRUE)){
    strcpy(description, object_get_description(object));

    /* the description is added to the game */
    game_set_act_description(game, description);

    game->st = OK;

    free(description);

    return;
  }

  game->st = ERROR;

  free(description);

  return;
}


/* Function called when the command introduced is open, if possible opens the access of a link*/
STATUS game_command_open(Game *game){

  char link[WORD_SIZE], aux[WORD_SIZE], object[WORD_SIZE];
  Link *l=NULL;
  

  /*Error control*/
  if(!game){
    return ERROR;
  }

 if(scanf("%s %s %s", link, aux, object)!=3){
   return ERROR;
 }

  l = game_get_link_by_name(game, link);

  if(!l){
    return ERROR;
  }

  if(link_get_status(l)==OPEN){
    return ERROR;
  }
/*If the object isnt in the player inventory returns error*/
  if(inventory_find_object(player_get_inventory(game_get_player(game)), object_get_id(game_get_object_by_name(game, object)))==FALSE){
    return ERROR;
  }
  
  /*If the player does not find the space where the link wants to be opened, return error*/
  if(game_get_player_location(game)!= link_get_origin(l)){
    return ERROR;
  }
/*If the object cannot open the link return ERROR*/
  if(object_get_open(game_get_object_by_name(game, object))!=link_get_id(l)){
    return ERROR;
  }

  else{
    link_set_status(l, OPEN);
    return OK;
  }
  
}

/* Function called when the command introduced is turnon, if possible turns on an object*/
STATUS game_command_turnon(Game *game){

  char object[WORD_SIZE];

  Object *object_aux;

  /*Error control*/
  if(!game){
    return ERROR;
  }

  if(scanf(" %s", object) != 1){
   return ERROR;
 }

  object_aux = game_get_object_by_name(game, object);

  /* If the player has the object in the inventory*/
  if (player_find_object_inventory(game->player, object_get_id(object_aux)) == TRUE){
    /*Sets the light of the object to on*/
    if(object_has_light(object_aux) == TRUE){
      if(object_is_turnedon(object_aux) == FALSE){
      object_set_turnedon(object_aux, TRUE);
      return OK;
      }
    }

  }

  return ERROR;
}

/* Function called when the command introduced is turnoff, if possible turns off an object*/
STATUS game_command_turnoff(Game *game){

  char object[WORD_SIZE];

  Object *object_aux;

  /*Error control*/
  
  if(!game){
    return ERROR;
  }

  if(scanf(" %s", object) != 1){
   return ERROR;
 }

  object_aux = game_get_object_by_name(game, object);

  /* If the player has the object in the inventory*/
  
  if (player_find_object_inventory(game->player, object_get_id(object_aux)) == TRUE){
    /*Sets the light of the object to off*/
    if(object_has_light(object_aux) == TRUE){
      if(object_is_turnedon(object_aux) == TRUE){
      object_set_turnedon(object_aux, FALSE);
      return OK;
      }
    }
  }

  return ERROR;
}

/* Function called when the command introduced is save, it saves a game*/
void game_command_save(Game *game){

  char string[WORD_SIZE];
  
  if (!game){
    return;
  }

  if(scanf(" %s", string) != 1){
   return;
 }

  game_management_save(game, string);

}

/* Function called when the command introduced is load, it loads a game*/
void game_command_load(Game *game){
  
  char string[WORD_SIZE];
  
  if (!game){
    return;
  }

  if(scanf(" %s", string) != 1){
   return;
  }

  game_management_load_game(game, string);

  return; 
}



/**Other Game Functions*/

/* Gets the dialogue of the game*/
Dialogue *game_get_dialogue(Game *game){
  if (!game){
    return NULL;
  }

  return game->d;
}

/* Gets the inventory of the game*/
Inventory* game_get_inventory(Game *game){
  
  if(!game){
    return NULL;
  }

   return player_get_inventory(game->player);
}

/* Creates a new game when the purpose is to load an already existing saved game*/
STATUS game_new(Game *game){
 game_destroy(game);

  game = game_create();

  return OK;
  
}

/* gets the state of the commands of the game*/
STATUS game_get_st(Game *game){

  /* Error control */
  if (!game){
    return ERROR;
  }
  
  return game->st;
}

/* Prints all the information of the game*/
void game_print_data(Game *game){
  int i=0;

  printf("\n\n-------------\n\n");

  printf("=> Spaces: \n");

  /*prints the spaces*/
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    space_print(game->spaces[i]); /* Tantos espacios como haya */
  }

  /* prints the objects */
  for (i = 0; i < MAX_OBJECTS; i++){
    printf("=> Object %d location: %d\n", i + 1, (int)game_get_object_location(game, object_get_id(game->object[i])));
  }

  /* prints the playes location */
  printf("=> Player location: %d\n", (int)game_get_player_location(game));
}