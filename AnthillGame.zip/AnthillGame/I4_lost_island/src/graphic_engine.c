/**
 * @brief It defines a textual graphic engine
 *
 * @file graphic_engine.c
 * @author Profesores PPROG, Blanca Matas, Gabriella Leaño
 * @version 3.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "graphic_engine.h"
#include "libscreen.h"
#include "command.h"
#include "space.h"
#include "types.h"
#include "game_rules.h"


#define ROWS 25
#define COLUMNS 80
#define MAX 128

#define MAP_WIDTH 15

/*This creates a structure for the graphic engine*/

struct _Graphic_engine {
  Area *map, *descript, *banner, *help, *feedback;
};


Graphic_engine *graphic_engine_create(){
  static Graphic_engine *ge = NULL;

  if (ge) {
    return ge;
  }

  /*This reserves dynamic memory for the graphic engine if the process fails returns NULL*/
  
  screen_init(ROWS, COLUMNS);
  ge = (Graphic_engine *)malloc(sizeof(Graphic_engine));

  if (ge == NULL){
    return NULL;
  }

  ge->map = screen_area_init(1, 1, 38, 15);
  ge->descript = screen_area_init(40, 1, 39, 15);
  ge->banner = screen_area_init(28, 17, 23, 1);
  ge->help = screen_area_init(1, 18, 78, 2);
  ge->feedback = screen_area_init(1, 21, 78, 2);

  return ge;
}
/** graphic_engine_destroy frees the previous memory allocation 
  *  of the graphic engine
  */

void graphic_engine_destroy(Graphic_engine *ge){
  if (!ge){
    return;
  }

  screen_area_destroy(ge->map);
  screen_area_destroy(ge->descript);
  screen_area_destroy(ge->banner);
  screen_area_destroy(ge->help);
  screen_area_destroy(ge->feedback);
  screen_destroy();
  free(ge);
}

/*it paints all the information from the file in the game*/

void graphic_engine_paint_game(Graphic_engine *ge, Game *game, FILE *f){
  Id id_act = NO_ID, id_back = NO_ID, id_next = NO_ID, id_right = NO_ID, id_left = NO_ID, id_up = NO_ID, id_down = NO_ID;
  char str_left, str_right, str_back, str_next, str_up, str_down;
  Id object_location = NO_ID;
  Id enemy_location = NO_ID;
  Id *ids = NULL, *inventory_ids = NULL, *objects_ids = NULL;
  char *objects_draw = NULL; 
  Space *space_actual = NULL;
  Set *space_set = NULL;
  char *gdesc[TAM1];
  char str[MAX], str2[MAX], enemy[MAX - 100], status[MAX / 2];
  T_Command last_cmd = UNKNOWN;
  extern char *cmd_to_str[N_CMD][N_CMDT];
  int i = 0;
  int flag = 0;
  Dialogue *d = NULL;
  int cherry;

  /*It paints the map area*/

  screen_area_clear(ge->map); 

  /*Gets the id where the player is */
  
  if ((id_act = game_get_player_location(game)) != NO_ID){
  /*Gets the space where the player is */
    space_actual = game_get_space(game, id_act);
  /*Gets the surroundings where the player is */
    id_back = game_get_connection(game, id_act, N);
    id_next = game_get_connection(game, id_act, S);
    id_right = game_get_connection(game, id_act, E);
    id_left = game_get_connection(game, id_act, W);
    id_up = game_get_connection(game, id_act, U);
    id_down = game_get_connection(game, id_act, D);
    
  /*gets the game dialogue*/
    d = game_get_dialogue(game);
    
  /*Gets the enemy location and then paints the enemy if the enemy is the same space the player is */
  enemy_location = enemy_get_location(game_get_enemy(game));
     if (enemy_location == id_act){
      sprintf(enemy, "/%coo/%c", 92, 92);
    }
    else{
      sprintf(enemy, "      ");
    }

    /*Paint the gdesc if the gdesc is the same space the player is */
    /*and if there is light in the room*/

    if((space_get_light(space_actual) == TRUE) || ((space_get_light(space_actual) == FALSE && flag == 1))){
    
    for (i = 0; i < TAM1; i++){
      gdesc[i] = NULL;
    }
    for (i = 0; i < TAM1; i++){
      gdesc[i] = space_get_gdesc(space_actual, i);
    }

    }

/*Gets the objects in the room if there are any, first allocates memory and then prints them*/

    objects_draw = (char *)malloc(OBJ_ARRAY * sizeof(char));
    if (!objects_draw){
      return;
    }

    strcpy(objects_draw, "\0");
/*gets the objects from the actual space*/
    
    objects_ids = (Id *)malloc(MAX_SET_IDS * sizeof(Id));
    if (!objects_ids){
      free(objects_draw);
      return;
    }
/*allocates memory for the objects inside the inventroy*/
    
    inventory_ids = (Id *)malloc(MAX_SET_IDS * sizeof(Id));
  if (!inventory_ids){
    free(objects_draw);
    free(objects_ids);
    return;
  }

  player_get_inventory_ids(game_get_player(game), inventory_ids);

    /* Gets the objects of the space */
    space_set = space_get_array(space_actual);
    
    /* Saves the ids of the objects of the spcae */
    set_id_objects(space_set, objects_ids);

    /* If there are objects in the space, it paints them */

    flag = 0;
    for (i = 0; inventory_ids[i] != NO_ID; i++){
        if (object_is_turnedon(game_get_object(game, inventory_ids[i])) == TRUE){
          flag = 1;
          break;
        }
      }
    /*of the actual space has light or the flash is turned on it prints the objects*/

    if((space_get_light(space_actual) == TRUE) || ((space_get_light(space_actual) == FALSE && flag == 1))){
    
    if (space_set != NULL){
      for (i = 0; i < set_total_id(space_set); i++){
        if (objects_ids[i] != NO_ID &&  (object_is_hidden(game_get_object(game, objects_ids[i])) == FALSE)){
          sprintf(str2, "%s ", object_get_name(game_get_object(game, objects_ids[i])));
          strcat(objects_draw
         , str2);
        }
        else{
          sprintf(str2, " ");
          strcat(objects_draw
         , str2);
        }
      }
    }

    }

    /* STARTS PAINTING ROOMS*******************************************************************/
    
    /*Paints the back room if there is one, also checks is the room is locked or not */

    
    if (id_back != NO_ID){

       if (game_get_connection_status(game, space_get_id(space_actual), N) == CLOSED){
        for (i = 0; inventory_ids[i] != NO_ID; i++){
          if(object_can_open(game_get_object(game, inventory_ids[i])) == TRUE){
            if(object_get_open(game_get_object(game, inventory_ids[i])) == space_get_id(space_actual)){
              game_set_connection_status(game, space_get_id(space_actual), N, OPEN);
            }
          }
        }
      }

      
      if (game_get_connection_status(game, space_get_id(space_actual), N) == CLOSED){
        str_back = 'X';
      }
      else{
        str_back = '^';
      }
    }
    else{
      str_back = ' ';
    }

    if (id_back != NO_ID){
      sprintf(str, "  |                     %2d|", (int)id_back);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |                       |");
      screen_area_puts(ge->map, str);
      sprintf(str, "  +-----------------------+");
      screen_area_puts(ge->map, str);
      sprintf(str, "              %c", str_back);
      screen_area_puts(ge->map, str);
    }





    
  /*Paints the left room's arrow if you can go left, also checks is the room is locked or not */
    if (id_left != NO_ID){
      
        if (game_get_connection_status(game, space_get_id(space_actual), W) == CLOSED){
        for (i = 0; inventory_ids[i] != NO_ID; i++){
          if(object_can_open(game_get_object(game, inventory_ids[i])) == TRUE){
            if(object_get_open(game_get_object(game, inventory_ids[i])) == space_get_id(space_actual)){
              game_set_connection_status(game, space_get_id(space_actual), W, OPEN);
            }
          }
        }
      }
      if (game_get_connection_status(game, space_get_id(space_actual), W) == CLOSED){
        str_left = 'X';
      }
      else{
        str_left = '<';
      }
    }
    else{
      str_left = ' ';
    }




    

   /*Paints the right room's arrow if you can go right, also checks is the room is locked or not */
    if (id_right != NO_ID){
      
     if (game_get_connection_status(game, space_get_id(space_actual), E) == CLOSED){
        for (i = 0; inventory_ids[i] != NO_ID; i++){
          if(object_can_open(game_get_object(game, inventory_ids[i])) == TRUE){
            if(object_get_open(game_get_object(game, inventory_ids[i])) == space_get_id(space_actual)){
              game_set_connection_status(game, space_get_id(space_actual), E, OPEN);
            }
          }
        }
      }
      
      if (game_get_connection_status(game, space_get_id(space_actual), E) == CLOSED){
        str_right = 'X';
      }
      else{
        str_right = '>';
      }
    }
    else{
      str_right = ' ';
    }





    

    if (id_up != NO_ID){
      if (game_get_connection_status(game, space_get_id(space_actual), U) == CLOSED){
        str_up = 'X';
      }
      else{
        str_up = '^';
      }
    }
    else{
      str_up = ' ';
    }






    

    if (id_down != NO_ID){

       if (game_get_connection_status(game, space_get_id(space_actual), D) == CLOSED){
        for (i = 0; inventory_ids[i] != NO_ID; i++){
          if(object_can_open(game_get_object(game, inventory_ids[i])) == TRUE){
            if(object_get_open(game_get_object(game, inventory_ids[i])) == space_get_id(space_actual)){
              game_set_connection_status(game, space_get_id(space_actual), D, OPEN);
            }
          }
        }
      }
      
      if (game_get_connection_status(game, space_get_id(space_actual), D) == CLOSED){
        str_down = 'X';
      }
      else{
        str_down = 'v';
      }
    }
    else{
      str_down = ' ';
    }





    

    /*Paints the actual room if there is one, also checks is the room is locked or not */
    /*It also paints the ant and the gdesc of the room*/

    if(space_get_light(space_actual) == FALSE && flag == 0 ){
      gdesc[0] = "         ";
      gdesc[1] = "         ";
      gdesc[2] = "         ";
      gdesc[3] = "         ";
      gdesc[4] = "         ";
      
    }
    if (id_act != NO_ID) {
      sprintf(str, "  +-----------------------+");
      screen_area_puts(ge->map, str);

      
      sprintf(str, "  |  m0^     %s      %d| %c", enemy, (int)id_act, str_up);
      screen_area_puts(ge->map, str);
      if (strcmp(objects_draw
     , "\0") != 0){
        sprintf(str, "  |       %s           |", objects_draw
       );
      }
      else{
        sprintf(str, "  |                       |");
      }
      screen_area_puts(ge->map, str);
      sprintf(str, "%c |          %s    | %c", str_left, gdesc[0], str_right);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |          %s    |", gdesc[1]);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |          %s    |", gdesc[2]);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |          %s    |", gdesc[3]);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |          %s    | %c", gdesc[4], str_down);
      screen_area_puts(ge->map, str);
      sprintf(str, "  +-----------------------+");
      screen_area_puts(ge->map, str);
    }



     
    
      


   

    /*Paints the next room if there is one, also checks is the room is locked or not */
    
    if (id_next != NO_ID){

      if (game_get_connection_status(game, space_get_id(space_actual), S) == CLOSED){
        for (i = 0; inventory_ids[i] != NO_ID; i++){
          if(object_can_open(game_get_object(game, inventory_ids[i])) == TRUE){
            if(object_get_open(game_get_object(game, inventory_ids[i])) == space_get_id(space_actual)){
              game_set_connection_status(game, space_get_id(space_actual), S, OPEN);
            }
          }
        }
      }
      
      if (game_get_connection_status(game, space_get_id(space_actual), S) == CLOSED){
        str_next = 'X';
      }
      else{
        str_next = 'V';
      }
    }
    else{
      str_next = ' ';
    }

    if (id_next != NO_ID){
      sprintf(str, "              %c", str_next);
      screen_area_puts(ge->map, str);
      sprintf(str, "  +-----------------------+");
      screen_area_puts(ge->map, str);
      sprintf(str, "  |                      %d|", (int)id_next);
      screen_area_puts(ge->map, str);
      sprintf(str, "  |                       |");
      screen_area_puts(ge->map, str);
    }
  }

   /* FINISHING PAINTING ROOMS*******************************************************************/

  /* STARTS PAINTING THE DESCRIPTION*******************************************************************/
  
  /*clears the area */
  screen_area_clear(ge->descript); 

  
  sprintf(str2, "  Objects location: ");
  screen_area_puts(ge->descript, str2);

  /* Allocates memory for an id array for all the ids of the objects in the game */
  ids = (Id *)malloc(MAX_SET_IDS * sizeof(Id));
  if (!ids){
    free(objects_draw
   );
    free(objects_ids);
    free(inventory_ids);
    return;
  }

  /* gets all the objects in the game */
  if (game_get_objects_ids(game, ids) == ERROR){
    free(ids);
    free(objects_draw);
    free(objects_ids);
    free(inventory_ids);
    return;
  }

  /* prints some of the objects with their corresponding ids and the id space where they are at */
  for (i = 0; ids[i] != NO_ID && ids[i] != 0; i++){
    if (i == 0){
      sprintf(str, " ");
    }
  
  

    if ((object_location = game_get_object_location(game, ids[i])) != NO_ID){
      sprintf(str, "  %s: %ld", object_get_name(game_get_object(game, ids[i])), game_get_object_location(game, ids[i]));
    }

    screen_area_puts(ge->descript, str);
  }

  

  sprintf(str, "                   ");
  screen_area_puts(ge->descript, str);
  

  /* Prints the player location */
  
  sprintf(str, "  Player location: %ld", player_get_location(game_get_player(game)));
  screen_area_puts(ge->descript, str);
    

  /* Prints the player health */
  sprintf(str, "  Player health: %d", player_get_health(game_get_player(game)));
  screen_area_puts(ge->descript, str);
  

 
  /* Prints the inventory*/
  sprintf(str, "  Inventory: ");
  screen_area_puts(ge->descript, str);

  

  for (i = 0; i < player_num_objects_inventory(game_get_player(game)); i++){
    sprintf(str, "  %s ", object_get_name(game_get_object(game, inventory_ids[i])));
    screen_area_puts(ge->descript, str);
  }

  sprintf(str, "                   ");
  screen_area_puts(ge->descript, str);

  if (enemy_get_health(game_get_enemy(game)) > 0){
    
    /* Prints the enemy location */
  /* Prints the enemy health if the enemy is still alive */
    
    sprintf(str, "  Enemy location: %ld", enemy_get_location(game_get_enemy(game)));
    screen_area_puts(ge->descript, str);
    sprintf(str, "  Enemy health: %d", enemy_get_health(game_get_enemy(game)));
  }
  else
  {
    /* Prints whether the enemy is killed or not */
    sprintf(str, "  Enemy has been killed");
  }
  screen_area_puts(ge->descript, str);

  sprintf(str, "                   ");
  screen_area_puts(ge->descript, str);
  
  /*Prints the descriptions */
  sprintf(str, "  Description: ");
  screen_area_puts(ge->descript, str);
  sprintf(str, "  %s", space_get_description(game_get_space(game, game_get_player_location(game))));
  screen_area_puts(ge->descript, str);
  

  sprintf(str, "  %s", game_get_act_description(game));
  screen_area_puts(ge->descript, str);
  /* Paints the title */
  screen_area_puts(ge->banner, "   THE LOST ISLAND ");

  /* Paints the help and information of commands*/
  
  screen_area_clear(ge->help); 
  sprintf(str, " The commands you can use are:");
  screen_area_puts(ge->help, str);
  sprintf(str, "     Exit or e, Move or m, Take or t, Drop or d, Attack or a, Inspect or i          ");
  screen_area_puts(ge->help, str);
  /*
  sprintf(str, "     Open or o, Turnon or tn, Turnoff or tf, Save or s, Load or l, inspect or i     ");
  screen_area_puts(ge->help, str);
  */
  

/*paints the dialogue text*/
  dialogue_string(d, game_get_last_command(game), game_get_st(game), str);
  screen_area_puts(ge->feedback, str);

/* paints the status */
  if (game_get_st(game) == ERROR){
    sprintf(status, "ERROR");
  }
  else{
    sprintf(status, "OK");
  }

  last_cmd = game_get_last_command(game);
  
  sprintf(str, " %s (%s): %s", cmd_to_str[last_cmd - NO_CMD][CMDL], cmd_to_str[last_cmd - NO_CMD][CMDS], status);
  screen_area_puts(ge->feedback, str);

  
  if (f){
    if (last_cmd == TAKE || last_cmd == DROP){
      fprintf(f, "%s %d: %s\n", cmd_to_str[last_cmd - NO_CMD][CMDL], game_get_last_command(game), status);
    }
    else{
      fprintf(f, "%s: %s\n", cmd_to_str[last_cmd - NO_CMD][CMDL], status);
    }
  }

/*paints the functions related to the game_rules module*/
      
 if(gm_volcano_message(game, str)==OK){
   screen_area_puts(ge->descript, str);
 }
 if(gm_killed_message(game, str)==OK){
  screen_area_puts(ge->descript, str);
 }
 if(gm_escaped_message(game,str)==OK){
   screen_area_puts(ge->descript, str);
 }
  
  if(gm_player_at_cherry(game) == TRUE){
    cherry = game_get_cherry(game);
    if((cherry >= 0 && cherry <2) && gm_cherry_hidden(game)==TRUE){
    sprintf(str, "Magic cherry is growing. Come back in a while.");
    screen_area_puts(ge->descript, str);
    game_set_cherry(game, cherry+1);    
    }
    if(cherry == 1){
      gm_cherry_growing(game);
    }
    if(cherry == 2){
    sprintf(str, "OH A MAGIC CHERRY!");
    screen_area_puts(ge->descript, str);
    game_set_cherry(game, 0);
  }
}
  
/* paints in the terminal */
  screen_paint();
  printf("prompt:> ");

  /*frees the memory of all the structures needed*/
  free(ids);
  free(inventory_ids);
  free(objects_draw);
  free(objects_ids);

  return;
}