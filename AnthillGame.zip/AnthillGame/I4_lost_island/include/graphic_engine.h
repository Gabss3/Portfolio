/**
 * @brief It defines the textual graphic engine interface
 *
 * @file graphic_engine.h
 * @author Profesores PPROG, Blanca Matas, Gabriella Leaño
 * @version 2.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#ifndef GRAPHIC_ENGINE_H
#define GRAPHIC_ENGINE_H

#include <stdio.h>
#include "game.h"
#include "libscreen.h"
#include "types.h"
#include "inventory.h"

/**
 * @brief declaration of the graphic engine structure
 */
typedef struct _Graphic_engine Graphic_engine;


/**
 * @brief creates a graphic engine
 * @author Profesores PPROG
 */
Graphic_engine *graphic_engine_create();

/**
  * @brief It destroys the map, the descript, the banner, the help and the feedback, freeing the allocated memory
  * @author Profesores PPROG
  * 
  * @param space a pointer to the graphic engine that must be destroyed  
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
void graphic_engine_destroy(Graphic_engine *ge);

/**
  * @brief It paints the map area, the description area, the banner area, the help area, the feedback area and then dumps it to the terminal
  * @author Profesores PPROG
  * 
  * @param space a pointer to the graphic engine that must be painted
  * @param space a pointer to the game  
  * @return OK, if everything goes well or ERROR if there was some mistake
  */

void graphic_engine_paint_game(Graphic_engine *ge, Game *game, FILE *f);

#endif
