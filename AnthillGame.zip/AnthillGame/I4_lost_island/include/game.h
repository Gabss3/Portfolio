/**
 * @brief It defines the game interface
 *
 * @file game.h
 * @author Profesores PPROG
 * @version 2.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#ifndef GAME_H
#define GAME_H


/* macro that defines the minimun random number for the attack command */
#define ATTACK_MIN 0
/*macro that defines the maximun random nunber for the attack command*/
#define ATTACK_MAX 9

/* macro that defines the half of the random numbers for the attack command*/
#define ATTACK_MED 4


#include "command.h"
#include "space.h"
#include "types.h"
#include "player.h"
#include "enemy.h"
#include "link.h"
#include "object.h"
#include "set.h"
#include "dialogue.h"
#include <time.h>


/*Struct that contains the game information*/
typedef struct _Game Game;



/**Game Create and Destroy Functions*/

/**
  * @brief It creates a new game, allocating memory and initializing its members
  * @author Profesores PPROG
  * 
  * @param game a pointer to the game
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
Game *game_create(); 

/**
  * @brief It destroys the game
  * @author Profesores PPROG
  * 
  * @param game a pointer to the game
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_destroy(Game *game); 



/** Game Space Functions*/

/**
  * @brief It adds a space to the game
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  * 
  * @param game a pointer to the game
  * @param space a pointer to the space
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_add_space(Game *game, Space *space);

/**
  * @brief It gets the space of the game
  * @author Profesores PPROG
  * 
  * @param space a pointer to the game
  * @param id the id of the game
  * @return a pointer to space
  */
Space *game_get_space(Game *game, Id id);

/**
  * @brief It gets the id of a space given its postion in the space array of the game
  * @author Blanca Matas
  * 
  * @param space a pointer to the game
  * @param space an int to the position
  * @return Id of the space, if everything goes well or -1 if there was some mistake
  */
Id game_get_space_id_at(Game *game, int position);



/** Game Object Functions*/

/**
  * @brief Adds an object to the game's object list of the game's objects (graph nodes)
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game  
  * @param id the id of the object we want to add
  * @returns returns OK if the object was successfully added or ERROR otherwise
  */
STATUS game_add_object(Game* game, Object* object);

/**
  * @brief It sets the location of the object in the game
  * @author Blanca Matas
  * 
  * @param game a pointer to the game
  * @param space an id that will contain the id of the object location
  * @param object the id of the object we want to set the location
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_set_object_location(Game* game, Id space, Id object);

/**
  * @brief It gets the location of the object in the game
  * @author Profesores PPROG
  * 
  * @param game a pointer to the game
  * @param the id of the object we want to get the location
  * @return the id of the object location
  */
Id game_get_object_location(Game *game, Id id);

/**
  * @brief It gets the id of an object given its postion in the object array of the game
  * @author Gabriella Leano
  * 
  * @param space a pointer to the game
  * @param space an int to the position
  * @return Id of the object, if everything goes well or -1 if there was some mistake
  */
Id game_get_object_id_at(Game *game, int position);

/**
  * @brief Gets the object at a specified position in the game's objects array
  * @author Noelia Rincon
  *
  * @param game a pointer to the game
  * @param id the id of the object in the game
  * @returns returns a pointer to the object, or NULL if not found
  */
Object* game_get_object(Game* game, Id id);

/**
 * @brief Gets the ids of all the objects in the game
 * @author Gabriella Leano
 * 
 * @param game pointer to the game
 * @param ids array with all the ids of the objects
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS game_get_objects_ids(Game *game, Id *ids);

/**
  * @brief Gets a pointer to an object with a specified name in the game's object list of the game's objects 
  * @author Blanca Matas
  * 
  * @param game a pointer to the game  
  * @param name the name of the object to be retrieved
  * @returns returns a pointer to the object with the specified name, or NULL if no object is found
  */
Object *game_get_object_by_name(Game *game, char *name);



/**Game Player Functions*/

/**
  * @brief Gets the player object from the game structure
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game
  * @returns returns a pointer to the player object
  */
Player *game_get_player(Game *game);

/**
  * @brief It adds a player to the game
  * @author Noelia Rincon
  * 
  * @param game a pointer to the game 
  * @param pleyer a pointer to the player we want to add
  * @returns returns OK if the player was added succesfully or ERROR if it was not
  */
STATUS game_add_player(Game *game, Player *player);

/**
 * @brief sets the player location
 * @author Profesores PPROG
 *
 * @param game pointer to the game
 * @param id location of the player
 * @returns returns OK if the location was successfully set or ERROR otherwise
 */
STATUS game_set_player_location(Game *game, Id id);

/**
  * @brief It gets the location of the player in the game
  * @author Profesores PPROG
  * 
  * @param game a pointer to the game
  * @return the id of the player location
  */
Id game_get_player_location(Game *game);

/**
 * @brief gets the player space
 * @author Noelia Rincón
 *
 * @param game pointer to the game
 * @param player pointer to the player
 * @return a pointer to the space where the player is, or NULL otherwise
 */
Space *game_get_player_space(Game *game, Player *player);



/**Game Link Functions*/

/**
  * @brief Gets the link between two spaces from a specified space id in the game's link list 
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  * 
  * @param game a pointer to the game  
  * @param id the id of the space where the link starts
  * @returns returns a pointer to the link between the spaces, or NULL if no link is found
  */
Link *game_get_link(Game *game, Id id);

/**
  * @brief Adds a link to the game's link list of links between spaces 
  * @author Blanca Matas
  * 
  * @param game a pointer to the game  
  * @param link a pointer to the link to be added
  * @returns returns OK if the link was successfully added or ERROR otherwise
  */
STATUS game_add_link(Game *game, Link *link);

/**
  * @brief It gets the id of an link given its postion in the link array of the game
  * @author Gabriella Leano
  * 
  * @param space a pointer to the game
  * @param space an int to the position
  * @return Id of the link, if everything goes well or -1 if there was some mistake
  */
Id game_get_link_id_at(Game *game, int position);

/**
  * @brief Searchs for a link in the game with the name given
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game  
  * @param name the name of the link we are searching for
  * @returns returns a pointer to the link , or NULL if no link is found
  */
Link *game_get_link_by_name(Game* game, char *name);

/**
  * @brief returns the id of the destination
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game  
  * @param space_act the id of the space from which the connection starts
  * @param direccion the direction of the connection
  * @returns returns the id of the connected space if found, or NO_ID otherwise
  */
Id game_get_connection(Game *game, Id space_act, DIRECTION direccion);

/**
  * @brief sets the access status between to spaces
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game  
  * @param origin if of the space from which the connection starts
  * @param dir the direction of the connection
  * @param a the access of the link we want to set
  * @returns returns OK if everything goes well and ERROR otherwise
  */
STATUS game_set_connection_status(Game *game, Id origin, DIRECTION d, ACCESS a);

/**
  * @brief gets the access status between to spaces
  * @author Gabriella Leano
  * 
  * @param game a pointer to the game  
  * @param space the id of the space from which the connection starts
  * @param dir the direction of the connection
  * @returns returns the access status of the connection (CLOSED, OPEN, or NO_CONNECTION) if found, or NO_CONNECTION otherwise
  */
ACCESS game_get_connection_status(Game *game, Id space, DIRECTION dir);



/**Game Enemy Functions*/

/**
  * @brief Sets the enemy object in the game structure
  * @author Blanca Matas
  * @param game a pointer to the game
  * @param enemy a pointer to the enemy object
  * @returns returns OK if the enemy object was successfully set, or ERROR otherwise
  */
STATUS game_add_enemy(Game *game, Enemy *enemy);

/**
  * @brief Gets the enemy object from the game structure
  * @author Blanca Matas
  *
  * @param game a pointer to the game
  * @returns returns a pointer to the enemy object
  */
Enemy *game_get_enemy(Game *game);



/**Game Description Functions*/


/**
  * @brief Sets the enemy object in the game structure
  * @author Blanca Matas
  * @param game a pointer to the game
  * @param enemy a pointer to the enemy object
  * @returns returns OK if the enemy object was successfully set, or ERROR otherwise
  */
STATUS game_add_enemy(Game *game, Enemy *enemy);

/**
  * @brief Gets the description of the current game state as a string, including the description of the current space and any objects in it or carried by the player, and their respective descriptions
  * @author Noelia Rincon
  * 
  * @param game a pointer to the game  
  * @returns returns a pointer to a string containing the description of the game state, or NULL if an error occurs
  */
char* game_get_act_description(Game *game);

STATUS game_set_act_description(Game *game, char *desc);



/**Game Command Funtions*/

/**
  * @brief Gets the current status of the game
  * @author Noelia Rincon
  *
  * @param game a pointer to the game
  * @returns returns the current status of the game as a STATUS enumeration value
  */
STATUS game_get_st(Game *game);

/**
  * @brief It updates the game
  * @author Profesores PPROG
  * 
  * @param game a pointer to the game
  * @param a command
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_update(Game *game, T_Command cmd); 

/**
  * @brief It indicates that the game is over
  * @author Profesores PPROG
  * 
  * @param space a pointer to the game
  * @return TRUE, if everything goes well or FALSE if there was some mistake
  */
BOOL game_is_over(Game *game); 

/**
  * @brief It saves a game
  * @author Blanca Matas
  * 
  * @param space a pointer to the game
  */
void game_command_save(Game *game);

/**
  * @brief It loads a game
  * @author Blanca Matas
  * 
  * @param space a pointer to the game
  */
void game_command_load(Game *game);

/**
  * @brief It sets the light of an object to on
  * @author Blanca Matas
  * 
  * @param game a pointer to the game
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_command_turnon(Game *game);

/**
  * @brief It sets the light of an object to off
  * @author Blanca Matas
  * 
  * @param game a pointer to the game
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS game_command_turnoff(Game *game);

/**
  * @brief It gets the last command inputed by the player
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  * 
  * @param game a pointer to the game
  * @return a command
  */
T_Command game_get_last_command(Game *game);

/**
 * @brief Creates a new game from an existing one
 * @author Blanca Matas
 *
 * @param game pointer to the game
 * @returns returns OK if the game was successfully created or ERROR otherwise
 */
STATUS game_new(Game *game);



/**Other Game Functions*/

/**
  * @brief It gets the dialogue of the game
  * @author Gabriella Leano
  * 
  * @param space a pointer to the game
  * @return Pointer to a Dialogue, if everything goes well or NULL if there was some mistake
  */
Dialogue *game_get_dialogue(Game *game);

/**
  * @brief It gets the inventory of the game
  * @author Noelia Rincon
  * 
  * @param space a pointer to the game
  * @return Pointer to an Inventory, if everything goes well or Null if there was some mistake
  */
Inventory* game_get_inventory(Game *game);

/**
 * @brief sets the number of times the player has visited the growing cherry
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 * @param int with the number to be set
 * @returns returns OK if the number was successfully set or ERROR otherwise
 */
STATUS game_set_cherry(Game *game, int cherry);

/**
 * @brief Gets the number of times the player has visited the growing cherry
 * @author Gabriella Leano
 *
 * @param game pointer to the game
 * @returns returns an int if everything went alright or -1 otherwise
 */
int game_get_cherry(Game *game);

/**
  * @brief It prints the game data
  * @author Profesores PPROG
  * 
  * @param space a pointer to the game
  */
void game_print_data(Game *game);

#endif
