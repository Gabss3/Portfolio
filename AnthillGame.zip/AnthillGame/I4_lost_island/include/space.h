/**
 * @brief It defines the space interface
 *
 * @file space.h
 * @author Profesores PPROG
 * @version 2.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#ifndef SPACE_H
#define SPACE_H

#include "types.h"
#include "set.h"

/**
 * @brief macro of number of rows of gdesc in the space
 */
#define TAM1 6

/**
 * @brief macro of number of character per row of gdesc in the space
 */
#define TAM2 10

/**
 * @brief Declaration of the space structure
 */
typedef struct _Space Space;

/**
  * @brief It creates a new space, allocating memory and initializing its memebers
  * @author Profesores PPROG
  * 
  * @param id the identification number for the new space
  * @return a new space, initialized
  */
Space* space_create(Id id);


/**
  * @brief It destroys a space, freeing the allocated memory
  * @author Profesores PPROG
  * 
  * @param space a pointer to the space that must be destroyed  
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS space_destroy(Space* space);

/**
  * @brief sets the id of the space
  * @author Noelia RIncón
  * 
  * @param space pointer to the space
  * @param id id of the space
  * @return OK if everything works succesfully or ERROR if otherwise
  */
STATUS space_set_id(Space* space, Id id);
/**
  * @brief It gets the id of a space
  * @author Profesores PPROG
  * 
  * @param space a pointer to the space  
  * @return the id of space
  */
Id space_get_id(Space* space);

/**
  * @brief It sets the name of a space
  * @author Profesores PPROG
  * 
  * @param space a pointer to the space
  * @param name a string with the name to store
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */
STATUS space_set_name(Space* space, char* name);


/**
  * @brief It gets the name of a space
  * @author Profesores PPROG
  * 
  * @param space a pointer to the space
  * @return  a string with the name of the space
  */


const char* space_get_name(Space* space);

/**
  * @brief It adds an object to the space
  * @author Profesores PPROG
  *
  * @param space a pointer to the space
  * @param value a boolean, specifying if in the space there is an object (TRUE) or not (FALSE)
  * @return OK, if everything goes well or ERROR if there was some mistake 
*/ 
STATUS space_set_object(Space* space, Id id);

/**
  * @brief It specifies the number of objects in a space
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  *
  * @param space a pointer to the space  
  * @return returns an integer with the number of objects in the space
  */
int space_num_objects(Space* space);

/**
  * @brief It prints the space information
  * @author Profesores PPROG
  *
  * This fucntion shows the id and name of the space, the spaces that surrounds it and wheter it has an object or not.
  * @param space a pointer to the space
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS space_print(Space* space);
/**
 * @brief It gets the set of objects in the space
 * @author Noelia RIncón
 * 
 * @param space pointer to the space
 * @return set of objects in the space
 */
Set *space_get_array(Space *space);

/**
 * @brief Retrieves the description of a Space
 * 
 * This function retrieves the description of the given Space.
 * 
 * @param space a pointer to the Space
 * @returns a pointer to the description string of the Space, or NULL if the Space is NULL or has no description
 */
char *space_get_description(Space *space);

/**
 * @brief Sets the description of a Space
 * 
 * This function sets the description of the given Space to the given string.
 * 
 * @param space a pointer to the Space
 * @param description the description string to set for the Space
 * @returns returns OK if the description was successfully set, or ERROR otherwise
 */
STATUS space_set_description(Space* space, char* descr);

/**
  * @brief It deletes an object from the space
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  *
  * @param space a pointer to the space
  * @param long with the id of the object
  * @return returns OK if the object was succesfully deleted or ERROR if it was not
  */


STATUS space_del_object(Space* space, Id id);

/**
 * @brief Checks if a Space has an object by ID
 * 
 * This function checks if the given Space has an object with the given ID.
 * 
 * @param s a pointer to the Space
 * @param id the ID of the object to check
 * @returns returns OK if the Space has the object, or ERROR otherwise
 */
BOOL space_has_object(Space* space, Id id);

/**
  * @brief gets the id array of the objects in an space
  *
  * @param space pointer to the space
  * @param ids id array of objects
  * @return OK if everything works well and ERROR if otherwise
  */
STATUS space_id_objects(Space *space, Id *ids);

/**
 * @brief establish the gdesc in a space
 * @author Blanca Matas
 * 
 * @param space pointer to the space
 * @param string gdesc,pointer to a string
 * @param pos position of the row where we want to put the descriptiom
 * @return OK  if everything works well or error otherwise
 */
STATUS space_set_gdesc(Space* space, char* string, int pos);

/**
 * @brief gets the gdesc in a space
 * @author Blanca Matas
 * 
 * @param space pointer to the space
 * @param pos position of the space
 * @return gdesc in a string 
 */
char* space_get_gdesc(Space* space, int pos);

/**
 * @brief It sets the set of objects in the space
 * @author Noelia RIncón
 * 
 * @param space pointer to the spaceç
 * @param set pointer to the set of objects
 * @return OK if everything works well, return ERROR if not
 */
STATUS space_set_set(Space *space, Set *set);

/**
 * @brief It sets the state of the light in the space
 * @author Blanca Matas
 * 
 * @param space pointer to the space
 * @param light boolean indicating the state we want to set 
 * @return Ok if everything works well, return ERROR if not
 */
STATUS space_set_light(Space *space, BOOL light);

/**
 * @brief It gets the state of the light in the space
 * @author Blanca Matas
 * 
 * @param space pointer to the space 
 * @return the state of the light
 */
BOOL space_get_light(Space *space);

/**
 * @brief It prints the state of the light in the space
 * @author Blanca Matas
 * 
 * @param space pointer to the space
 * @return OK if everything works well, return ERROR if not
 */
STATUS space_light_print(Space *space);

#endif
