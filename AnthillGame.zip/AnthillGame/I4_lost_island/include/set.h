/** 
 * @brief Defines the set interface
 * 
 * @file set.h
 * @author Gabriella Leaño
 * @version 1.0 
 * @date 14-02-2023
 * @copyright GNU Public License
 */

#ifndef SET_H
#define SET_H

#include "types.h"

/**
 * @brief Declaration of the set structure
 */
typedef struct _Set Set;

/**
  * @brief It creates a set, allocating memory and initializing its members
  * @author  Blanca Matas
  * 
  * @param it does not recieve any arguments 
  * @return a new set initialized
  */
Set* set_create();

/**
  * @brief It destroys a set, freeing the allocated memory
  * @author  Blanca Matas
  * 
  * @param space a pointer to the set that must be destroyed  
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS set_destroy(Set* s);

/**
  * @brief It adds an id to the set
  * @author Gabriella Leano, Noelia Rincon
  * 
  * @param it recieves a pointer to set 
  * @param a long with an id
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS set_add_id(Set *s, Id id);

/**
  * @brief It returns the number of ids
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  *
  * 
  * @param s a pointer to set
  * @return an integer with the number of ids
  */

int set_total_id(Set *s);

/**
  * @brief It indicates if the array of the set is full
  * @author Gabriella Leano, Noelia Rincon
  * 
  * @param s a pointer to set 
  * @return OK, if the set array is full or ERROR if it is not full
  */

STATUS set_array_full(Set *s);

/**
  * @brief It gets the id of a determinated position
  * @author Gabriella Leano, Noelia Rincon
  * 
  * @param s a pointer to set 
  * @param position_id a intenger of the position
  * @return OK, if the set array is full or ERROR if it is not full
  */

Id set_get_id(Set *s, int posicion_id);

/**
  * @brief It checks if an id already exists in the set
  * @author Gabriella Leano, Noelia Rincon
  * 
  * @param space a pointer to set
  * @param a long with the id
  * @return OK, if the id already exists or ERROR if the id does not exist
  */
BOOL set_id_exists(Set *s, Id id);

/**
  * @brief It deletes an id from an array
  * @author Gabriella Leano, Noelia Rincon
  *
  * @param space a pointer to set
  * @param space a long with the id to delate
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS set_del_id(Set *s, long id);

/**
  * @brief It prints the array
  * @author Noelia Rincon
  *
  * @param space a pointer to set
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS set_print_set(Set *s);


/**
  * @brief sets the set's ids array
  * @author Gabriella Leano, Noelia Rincon
  * 
  * @param s a pointer to a set
  * @param ids a pointer to the id array we want to set
  * @return OK, if everythings go well or ERROR otherwise
  */

STATUS set_id_objects(Set *s, Id *ids);


#endif