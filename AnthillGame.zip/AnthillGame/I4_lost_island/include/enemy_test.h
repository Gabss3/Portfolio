/** 
 * @brief It declares the tests for the enemy module
 * 
 * @file enemy_test.h
 * @author Noelia Rincón
 * @version 2.0 
 * @date 12-03-2021
 * @copyright GNU Public License
 */

#ifndef ENEMY_TEST_H
#define ENEMY_TEST_H

/**
 * @test Test enemy creation
 * @pre enemy ID 
 * @post Non NULL pointer to enemy 
 */
void test1_enemy_create();

/**
 * @test Test enemy creation
 * @pre enemy ID 
 * @post enemy_ID == Supplied enemy Id
 */
void test2_enemy_create();

/**
 * @test Test function for enemy_name setting
 * @pre String with enemy name
 * @post Ouput==OK 
 */
void test1_enemy_set_name();

/**
 * @test Test function for enemy_name setting
 * @pre pointer to enemy = NULL 
 * @post Output==ERROR
 */
void test2_enemy_set_name();

/**
 * @test Test function for enemy_name setting
 * @pre pointer to enemy_name = NULL (point to enemy = NON NULL) 
 * @post Output==ERROR
 */
void test3_enemy_set_name();

/**
 * @test Test function for getting enemy_name
 * @pre Non-NULL pointer to enemy with a valid name
 * @post Output == enemy_name
 */
void test1_enemy_get_name();

/**
 * @test Test function for getting enemy_name
 * @pre pointer to enemy = NULL 
 * @post Output == NULL
 */
void test2_enemy_get_name();

/**
 * @test Test function for getting enemy_location
 * @pre Non-NULL pointer to enemy with a valid location
 * @post Output == enemy_location
 */
void test1_enemy_get_location();

/**
 * @test Test function for getting enemy_location
 * @pre pointer to enemy = NULL 
 * @post Output == NULL
 */
void test2_enemy_get_location();

/**
 * @test Test function for getting enemy_id
 * @pre Non-NULL pointer to enemy with a valid ID
 * @post Output == enemy_id
 */
void test1_enemy_get_id();

/**
 * @test Test function for getting enemy_id
 * @pre pointer to enemy = NULL 
 * @post Output == -1
 */
void test2_enemy_get_id();

/**
 * @test Test function for getting enemy_health
 * @pre Non-NULL pointer to enemy with a valid health value
 * @post Output == enemy_health
 */
void test1_enemy_get_health();

/**
 * @test Test function for getting enemy_health
 * @pre pointer to enemy = NULL 
 * @post Output == -1
 */
void test2_enemy_get_health();

/**
 * @test Test function for setting enemy_location
 * @pre Non-NULL pointer to enemy, valid location
 * @post enemy_location == Supplied location
 */
void test1_enemy_set_location();

/**
 * @test Test function for setting enemy_location
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */
void test2_enemy_set_location();

/**
 * @test Test function for setting enemy_health
 * @pre Non-NULL pointer to enemy, valid health value
 * @post enemy_health == Supplied health value
 */
void test1_enemy_set_health();

/**
 * @test Test function for setting enemy_health
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */
void test2_enemy_set_health();
/**
 * @test Test function for destroying the enemy
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */

void test1_enemy_destroy();
/**
 * @test Test function for destroying the enemy
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */
void test2_enemy_destroy();
/**
 * @test Test function for setting the enemy id
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */
void test1_enemy_set_id();
/**
 * @test Test function for setting the enemy id
 * @pre pointer to enemy = NULL 
 * @post Output == ERROR
 */
void  test2_enemy_set_id();

#endif