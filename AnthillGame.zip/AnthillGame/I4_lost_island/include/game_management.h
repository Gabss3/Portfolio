/** 
 * @brief It defines the information from a file to implement in the game 
 * 
 * @file game_management.h
 * @author Blanca Matas
 * @version 2.0 
 * @date 30/04/2023
 * @copyright GNU Public License
 */

#ifndef GAME_MANAGEMENT_H
#define GAME_MANAGEMENT_H

#include "game.h"
#include "link.h"


/**
  * @brief loads a space in the game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_spaces(Game *game, char *filename);

/**
  * @brief loads the objects of the game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_objects(Game *game, char *filename);

/**
  * @brief loads the enemy of the game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_enemy(Game *game, char *filename);

/**
  * @brief loads the player of the game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_player(Game *game, char *filename);

/**
  * @brief loads a link
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_links(Game *game, char *filename);

/**
  * @brief saves the spaces
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */


STATUS game_management_save_spaces(Game *game, char *filename);

/**
  * @brief saves the player
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_save_player(Game *game, char *filename);
/**
  * @brief saves the enemy
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_save_enemy(Game *game, char *filename);
/**
  * @brief saves the links
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_save_links(Game *game, char *filename);
/**
  * @brief saves the entire game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_save(Game *game, char *filename);
/**
  * @brief loads the entire game
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_game(Game *game, char *filename);
/**
  * @brief loads the player's inventory
  * @author Blanca Matas
  *
  * @param game pointer to the game
  * @param filename string of the name of the file
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */

STATUS game_management_load_inventory(Game *game, char *filename);

#endif