
/** 
 * @brief It declares the tests for the link module
 * 
 * @file link_test.h
 * @author Noelia Rincón Roldán
 * @version 2.0 
 * @date 02-04-2023
 * @copyright GNU Public License
 */

#ifndef LINK_TEST_H
#define LINK_TEST_H

/**
 * @test Test link creation
 * @pre None
 * @post Non-NULL pointer to link 
 */
void test1_link_create();

/**
 * @test Test link creation
 * @pre None
 * @post link_ID == Supplied link Id
 */
void test2_link_create();

/**
 * @test Test link destruction
 * @pre Non-NULL pointer to link
 * @post link is properly destroyed
 */
void test1_link_destroy();

/**
 * @test Test link destruction
 * @pre NULL pointer to link
 * @post No changes in memory
 */
void test2_link_destroy();

/**
 * @test Test function for getting link_id
 * @pre Non-NULL pointer to link with a valid ID
 * @post Output == link_id
 */
void test1_link_get_id();

/**
 * @test Test function for getting link_id
 * @pre NULL pointer to link
 * @post Output == -1
 */
void test2_link_get_id();

/**
 * @test Test function for getting link_name
 * @pre Non-NULL pointer to link with a valid name
 * @post Output == link_name
 */
void test1_link_get_name();

/**
 * @test Test function for getting link_name
 * @pre NULL pointer to link
 * @post Output == NULL
 */
void test2_link_get_name();

/**
 * @test Test function for getting link_origin
 * @pre Non-NULL pointer to link with a valid origin
 * @post Output == link_origin
 */
void test1_link_get_origin();

/**
 * @test Test function for getting link_origin
 * @pre NULL pointer to link
 * @post Output == NULL
 */
void test2_link_get_origin();

/**
 * @test Test function for getting link_destination
 * @pre Non-NULL pointer to link with a valid destination
 * @post Output == link_destination
 */
void test1_link_get_destination();

/**
 * @test Test function for getting link_destination
 * @pre NULL pointer to link
 * @post Output == NULL
 */
void test2_link_get_destination();

/**
 * @test Test function for getting link_direction
 * @pre Non-NULL pointer to link with a valid direction
 * @post Output == link_direction
 */
void test1_link_get_direction();

/**
 * @test Test function for getting link_direction
 * @pre NULL pointer to link
 * @post Output == NULL
 */
void test2_link_get_direction();

/**
 * @test Test function for getting link_status
 * @pre Non-NULL pointer to link with a valid status
 * @post Output == link_status
 */
void test1_link_get_status();

/**
 * @test Test function for getting link_status
 * @pre NULL pointer to link
 * @post Output == NULL
 */
void test2_link_get_status();

/**
 * @test Test function for setting link_id
 * @pre Non-NULL pointer to link, valid ID
 * @post link_id == Supplied ID
 */
void test1_link_set_id();

/**
 * @test Test function for setting link_id
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_id();

/**
 * @test Test function for setting link_name
 * @pre Non-NULL pointer to link, valid name
 * @post link_name == Supplied name
 */
void test1_link_set_name();

/**
 * @test Test function for setting link_name
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_name();

/**
 * @test Test function for setting link_origin
 * @pre Non-NULL pointer to link, valid origin
 * @post link_origin == Supplied origin
 */
void test1_link_set_origin();

/**
 * @test Test function for setting link_origin
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_origin();

/**
 * @test Test function for setting link_destination
 * @pre Non-NULL pointer to link, valid destination
 * @post link_destination == Supplied destination
 */
void test1_link_set_destination();

/**
 * @test Test function for setting link_destination
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_destination();

/**
 * @test Test function for setting link_direction
 * @pre Non-NULL pointer to link, valid direction
 * @post link_direction == Supplied direction
 */
void test1_link_set_direction();

/**
 * @test Test function for setting link_direction
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_direction();

/**
 * @test Test function for setting link_status
 * @pre Non-NULL pointer to link, valid status
 * @post link_status == Supplied status
 */
void test1_link_set_status();

/**
 * @test Test function for setting link_status
 * @pre NULL pointer to link
 * @post Output == ERROR
 */
void test2_link_set_status();

#endif

