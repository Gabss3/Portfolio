/** 
 * @brief It declares the tests for the game_management module
 * 
 * @file game_management_test.h
 * @author Noelia Rincón ROldán
 * @version 0.2
 * @date 05/05/2023
 * @copyright GNU Public License
 */

#ifndef GAME_MANAGEMENT_TEST_H
#define GAME_MANAGEMENT_TEST_H

/**
 * @test Test to load spaces
 * @pre pointer to the game 
 * @post Output == ERROR or OK
 */
void test1_game_management_load_spaces();
/**
 * @test Test to load spaces
 * @pre pointer to the game 
 * @post Output == ERROR or OK
 */
void test2_game_management_load_spaces();
/**
 * @test Test to load objects
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test1_game_management_load_objects();
/**
 * @test Test to load objects
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test2_game_management_load_objects();
/**
 * @test Test to load enemy
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test1_game_management_load_enemy();
/**
 * @test Test to load enemy
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test2_game_management_load_enemy();
/**
 * @test Test to load player
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test1_game_management_load_player();
/**
 * @test Test to load player
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test2_game_management_load_player();
/**
 * @test Test to load links
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test1_game_management_load_links();
/**
 * @test Test to load links
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test2_game_management_load_links();
/**
 * @test Test to save the game
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test1_game_management_save();
/**
 * @test Test to save
 * @pre pointer to the game 
 * @post Output == ERROR or OK 
 */
void test2_game_management_save();





#endif