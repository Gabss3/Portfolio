/**
 * @brief defines the player interface
 *
 * @file player.h
 * @author Blanca Matas, Noelia Rincón
 * @version 2.0
 * @date 14-02-2023
 * @copyright GNU Public License
 */

#ifndef PLAYER_H
#define PLAYER_H

#include "types.h"
#include "inventory.h"


/**
 * @brief declaration of the player structure
 */
typedef struct _Player Player;


/**
 * @brief It creates a new player, allocating memory and initializing its
 * members
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param id the identification number for the new player
 * @return a new player, initialized
 */
Player* player_create(Id id);

/**
 * @brief It destroys a player, freeing the allocated memory
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player that must be destroyed
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_destroy(Player* player);


/**
 * @brief It gets the id of a player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @return the id of player
 */
Id player_get_id(Player* player);

/**
 * @brief It sets the id of a player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @param id id of the player
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_set_id(Player* player, Id id);

/**
 * @brief It sets the name of a player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @param name a string with the name to store
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_set_name(Player* player, char* name);

/**
 * @brief It gets the name of the player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @return the string with the player's name or NULL if there was some mistake
 */
const char* player_get_name(Player* player);

/**
 * @brief It gets the location of the player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @return the id of the location of the player
 */
Id player_get_location(Player* player);

/**
 * @brief It sets the location of the player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * @param space a pointer to the player
 * @param id id of the location of the player
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_set_location(Player* player, Id id);

/**
 * @brief Adds an object to the player inventory
 * @author Noelia RIncón
 * 
 * @param player pointer to the player 
 * @param id id of the object we want to add
 * @returns returns OK if the id was successfully set, or ERROR otherwise
 */
STATUS player_set_object (Player* player, Id id);

/**
 * @brief deletes an object from the player inventory
 * @author Noelia Rincón
 * 
 * @param player pointer to the player 
 * @param id id of the object we want to delete
 * @returns returns OK if the id was successfully deleted, or ERROR otherwise
 */
STATUS player_delete_object(Player* player, Id id);

/**
 * @brief It prints the player information
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 *
 * This function shows the id and name of the player, the player location,  and
 * wheter it has an object or not.
 * @param space a pointer to the player
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_print(Player* player);

/**
 * @brief gets the health of the player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 * 
 * This function gets the current health value of the given Player.
 * 
 * @param player a pointer to the player
 * @returns the current health value of the player
 */
int player_get_health(Player* player);

/**
 * @brief sets the health of a Player
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 * 
 * This function sets the health value of the given player to the given value.
 * 
 * @param player a pointer to the player
 * @param health the health value to set for the player
 * @returns returns OK if the health value was successfully set, or ERROR otherwise
 */
STATUS player_set_health(Player* player, int health);



/**
 * @brief gets the ids of the objects the player has in the inventory
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 * 
 * @param player pointer to the player
 * @param ids pointer to the id array
 *@return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS player_get_inventory_ids(Player* player, Id *ids);

/**
 * @brief gets the number of objects the player has in the inventory
 * @author Gabriella Leano, Blanca Matas, Noelia Rincon
 * 
 * @param player pointer to the player
 * @return number of objects of the player
 */
int player_num_objects_inventory(Player* player);

/**
 * @brief gets the player's inventory
 * @author Blanca Matas
 * 
 * @param player pointer to the player 
 * @return the inventory
 */
Inventory *player_get_inventory(Player* player);

/**
 * @brief sets the player inventory
 * @author Blanca Matas
 * 
 * @param player pointer to the player
 * @param inventory inventory we want to set
 * @return OK, if the inventory sets succesfully, or ERROR otherwise 
 */
STATUS player_set_inventory(Player* player, Inventory* inventory);

/**
 * @brief find an object in the player's inventory
 * @author Gabriella Leaño
 * 
 * @param player pointer to the player
 * @param id id of the object we want to find
 * @return TRUE if the object is in the inventory or FALSE if it is not
 */
BOOL player_find_object_inventory(Player* player, Id id);



#endif