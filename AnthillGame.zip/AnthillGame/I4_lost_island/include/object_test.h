

/** 
 * @brief It declares the tests for the link module
 * 
 * @file object_test.h
 * @author Noelia Rincón Roldán
 * @version 0.2 
 * @date 02-04-2023
 * @copyright GNU Public License
 */

#ifndef OBJECT_TEST_H
#define OBJECT_TEST_H

/**
 * @test Test object creation
 * @pre None
 * @post Non-NULL pointer to object
 */
void test1_object_create();

/**
 * @test Test object creation
 * @pre None
 * @post Object is successfully created with default values
 */
void test2_object_create();

/**
 * @test Test object destruction
 * @pre Non-NULL pointer to object
 * @post Object is successfully destroyed
 */
void test1_object_destroy();

/**
 * @test Test object destruction
 * @pre NULL pointer to object
 * @post No action is taken
 */
void test2_object_destroy();

/**
 * @test Test function for setting object ID
 * @pre Non-NULL pointer to object, valid object ID
 * @post Object ID is successfully set
 */
void test1_object_set_id();

/**
 * @test Test function for setting object ID
 * @pre NULL pointer to object
 * @post Output == ERROR
 */
void test2_object_set_id();

/**
 * @test Test function for getting object ID
 * @pre Non-NULL pointer to object
 * @post Output == Object ID
 */
void test1_object_get_id();

/**
 * @test Test function for getting object ID
 * @pre NULL pointer to object
 * @post Output == NO_ID
 */
void test2_object_get_id();

/**
 * @test Test function for setting object name
 * @pre Non-NULL pointer to object, valid name
 * @post Object name is successfully set
 */
void test1_object_set_name();

/**
 * @test Test function for setting object name
 * @pre NULL pointer to object
 * @post Output == ERROR
 */
void test2_object_set_name();

/**
 * @test Test function for getting object name
 * @pre Non-NULL pointer to object
 * @post Output == Object name
 */
void test1_object_get_name();

/**
 * @test Test function for getting object name
 * @pre NULL pointer to object
 * @post Output == NULL
 */
void test2_object_get_name();

/**
 * @test Test function for setting object description
 * @pre Non-NULL pointer to object, valid description
 * @post Object description is successfully set
 */
void test1_object_set_description();

/**
 * @test Test function for setting object description
 * @pre NULL pointer to object
 * @post Output == ERROR
 */
void test2_object_set_description();

/**
 * @test Test function for getting object description
 * @pre Non-NULL pointer to object
 * @post Output == Object description
 */
void test1_object_get_description();

/**
 * @test Test function for getting object description
 * @pre NULL pointer to object
 * @post Output == NULL
 */
void test2_object_get_description();

/**
 * @test Test function for deleting a name of an object if it coincides
 * @pre Non-NULL pointer to object
 * @post Output == OK
 */
void test1_object_del_obj_name();

/**
 * @test Test function for deleting a name of an object if it coincides
 * @pre NULL pointer to object
 * @post Output == ERROR
 */
void test2_object_del_obj_name();

/**
 * @test Test function for determining if the object has light
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */
void test1_object_has_light();

/**
 * @test Test function for determining if the object has light
 * @pre NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_has_light();
/**
 * @test Test function for setting the light
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_light();
/**
 * @test Test function for setting the light
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_light();
/**
 * @test Test function for determining if the object os hidden
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */

void test1_object_is_hidden();
/**
 * @test Test function for determining if the object os hidden
 * @pre Non-NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_is_hidden();
/**
 * @test Test function for setting the hideness
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_hidden();
/**
 * @test Test function for setting the hideness
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_hidden();
/**
 * @test Test function for determining if the object is movable
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */

void test1_object_is_movable();
/**
 * @test Test function for determining if the object is movable
 * @pre Non-NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_is_movable();
/**
 * @test Test function for setting the movility
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_movable();
/**
 * @test Test function for setting the movility
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_movable();
/**
 * @test Test function for determining if the object is dependent
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */
void test1_object_is_dependent();
/**
 * @test Test function for determining if the object is dependent
 * @pre Non-NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_is_dependent();
/**
 * @test Test function for setting the dependency
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_dependency();
/**
 * @test Test function for setting the dependency
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_dependency();
/**
 * @test Test function for determining if the object can open a door
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */

void test1_object_can_open();
/**
 * @test Test function for determining if the object can open a door
 * @pre Non-NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_can_open();
/**
 * @test Test function for setting if an object can open a door
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_open();
/**
 * @test Test function for setting if an object can open a door
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_open();
/**
 * @test Test function for getting the space an object can open
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_get_open();
/**
 * @test Test function for getting the space an object can open
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_get_open();
/**
 * @test Test function for determining if the object can be turned on
 * @pre Non-NULL pointer to object
 * @post Output == TRUE
 */

void test1_object_is_turnedon();
/**
 * @test Test function for determining if the object can be turned on
 * @pre Non-NULL pointer to object
 * @post Output == FALSE
 */
void test2_object_is_turnedon();
/**
 * @test Test function for setting if an object can be turned on
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_set_turnedon();
/**
 * @test Test function for setting if an object can be turned on
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_set_turnedon();
/**
 * @test Test function fto find the dependency of an object
 * @pre NULL pointer to object
 * @post pointer to NULL
 */

void test1_object_find_dependence();
/**
 * @test Test function fto find the dependency of an object
 * @pre NULL pointer to object
 * @post pointer to NULL
 */
void test2_object_find_dependence();




#endif
