/**
 * @brief It defines object interface
 *
 * @file object.h
 * @author Noelia Rincón, Blanca Matas
 * @version 2.0
 * @date 09/02/2022
 * @copyright GNU Public License
 */

#ifndef OBJECT_H
#define OBJECT_H

#include "types.h"
#include "inventory.h"
#include "set.h"

/**
 * @brief declaration of the object structure
 */
typedef struct _Object Object;

/**
  * @brief It creates a new object, allocating memory and initializing its members
  * @author Noelia Rincon
  * 
  * @param id the identification number for the new object
  * @return a new object, initialized
  */
Object *object_create(Id id);

/**
  * @brief It destroys a object, freeing the allocated memory
  * @author Noelia RIncon
  * 
  * @param space a pointer to the object that must be destroyed  
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_destroy(Object *object);

/**
  * @brief it sets the id of an object
  * @author Noelia RIncon
  *
  * @param object pointer to the object
  * @param id id that we want to set to the object
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_set_id(Object *object, Id id);

/**
  * @brief It gets the id of a object
  * @author Noelia Rincon
  * 
  * @param object a pointer to the object  
  * @return the id of object
  */
Id object_get_id(Object *object);

/**
  * @brief It sets the name of an object
  * @author Noelia Rincon
  * 
  * @param object a pointer to the object
  * @param name a string with the name to store
  * @return OK, if everything goes well or ERROR if there was some mistake 
  */
STATUS object_set_name(Object *object, char *name);

/**
  * @brief It gets the name of an object
  * @author Noelia Rincon
  * 
  * @param object a pointer to the object
  * @return  a string with the name of the object
  */
const char *object_get_name(Object *object);

/**
  * @brief Sets the description of an Object
  * @author Noelia Rincon
  * 
   * This function sets the description of the given Object to the given description string.
   * 
  * @param object a pointer to the Object
  * @param desc a pointer to the description string to set for the Object
  * @returns returns OK if the description was successfully set, or ERROR otherwise
*/

STATUS object_set_description(Object *object, const char *descr);

/**
  * @brief Retrieves the description of an Object
  * @author Noelia Rincon
  * 
  * This function returns the description of the given Object as a string.
  * 
  * @param object a pointer to the Object
  * @returns a pointer to the description string of the Object, or NULL if the Object is NULL or has no description
 */
const char *object_get_description(Object *object);

/**
  * @brief It prints the object information
  * @author Noelia Rincon
  *
  * This fucntion shows the id and name of the object
  * @param space a pointer to the object
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_print(Object *object);

/**
  * @brief It deletes the name of an object if it coincides with the name given in the argument
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return OK, if everything goes well or ERROR if there was some mistake
  */

STATUS object_del_obj_name(Object *object, char* name);
 /**
  * @brief it checks the light of the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */

BOOL object_has_light(Object *object);

/**
  * @brief It sets the light of the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param light a boolean showing to what we wat to set our light
  * @return OK, if everything goes well or ERROR if there was some mistake
  */

STATUS object_set_light(Object *object, BOOL light);
 /**
  * @brief it checks the object is hidden
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */

BOOL object_is_hidden(Object *object);
/**
  * @brief It sets the hidency of the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param hidden a boolean showing if the object i hidden or not
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_set_hidden(Object *object, BOOL hidden);
 /**
  * @brief it checks the object is movable
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */
BOOL object_is_movable(Object *object);
/**
  * @brief It sets the movility of the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param movable a boolean showing if the object is movable or not
  * @return OK, if everything goes well or ERROR if there was some mistake
  */

STATUS object_set_movable(Object *object, BOOL movable);
/**
  * @brief it checks the object is depedent
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */
BOOL object_is_dependent(Object *object);
/**
  * @brief It sets the dependency of the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param dependency the id of the dependency
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_set_dependency(Object *object, Id dependency);
/**
  * @brief it checks if the object can be used to open something
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */
BOOL object_can_open(Object *object);
/**
  * @brief It sets if an object can open
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param open the id of the open that can open the object
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_set_open(Object *object, Id open);
/**
  * @brief It gets the id of the space that can be opened with the object
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return the id of the object that can be opened or NULL if there was some mistake
  */
Id object_get_open(Object *object);
/**
  * @brief it checks if the object is turned on
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return TRUE, if the object has light or FALSE otherwise
  */
BOOL object_is_turnedon(Object *object);
/**
  * @brief It sets if an object is turned on
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param turnedon a boolean showing if the object is turnedon or not
  * @return OK, if everything goes well or ERROR if there was some mistake
  */
STATUS object_set_turnedon(Object *object, BOOL turnedon);
/**
  * @brief it finds the object dependence
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @param inv inventory of the player where the depedency is searched
  * @return TRUE, if the object has light or FALSE otherwise
  */
BOOL object_find_dependence(Object *object, Inventory *inv);
/**
  * @brief It gets the id of the object dependency
  * @author Noelia Rincon
  *
  * @param object a pointer to the object
  * @return the id of the object dependence or NULL if there was some mistake
  */
Id object_dependency_id(Object *object);

#endif