/**
 * @brief It defines de command interface
 *
 * @file command.h
 * @author Noelia Rincón
 * @date 07-05-2023
 * @copyright GNU Public License
*/

#ifndef DIALOGUE_H
#define DIALOGUE_H

#include "types.h"
#include <stdio.h>
#include <strings.h>




#endif