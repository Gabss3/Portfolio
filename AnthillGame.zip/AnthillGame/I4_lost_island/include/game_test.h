/** 
 * @brief It declares the tests for the game module
 * 
 * @file game_test.h
 * @author Noelia Rincón ROldán
 * @version 0.2
 * @date 04/05/2023
 * @copyright GNU Public License
 */

#ifndef GAME_TEST_H
#define GAME_TEST_H

/**
 * @test Test function for creating the game
 * @pre a pointer to the game
 * @post a pointer to NULL
 */
void test1_game_create();
/**
 * @test Test function for creating the game
 * @pre a pointer to the game
 * @post output ERROR or OK
 */
void test2_game_create();
/**
 * @test Test function for destroying the game
 * @pre a pointer to the game
 * @post output ERROR or OK
 */

void test1_game_destroy();
/**
 * @test Test function for destroying the game
 * @pre a pointer to the game
 * @post output ERROR or OK
 */
void test2_game_destroy();
/**
 * @test Test function for adding a space
 * @pre a pointer to the game
 * @post output ERROR or OK
 */

void test1_game_add_space();
/**
 * @test Test function for adding a space
 * @pre a pointer to the game
 * @post output ERROR or OK
 */
void test2_game_add_space();
/**
 * @test Test function for getting a space
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_space();
/**
 * @test Test function for getting a space
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_space();
/**
 * @test Test function for getting a link
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_link();
/**
 * @test Test function for getting a link
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_link();
/**
 * @test Test function for getting a link
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_link_by_name();
/**
 * @test Test function for getting a link
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_link_by_name();
/**
 * @test Test function for getting a connection
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_connection();
/**
 * @test Test function for getting a connection
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_connection();
/**
 * @test Test function for getting the connection's status
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_connection_status();
/**
 * @test Test function for getting the connection's status
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_connection_status();
/**
 * @test Test function for adding a link
 * @pre a pointer to the game
 * @post output ERROR or OK
 */

void test1_game_add_link();
/**
 * @test Test function for adding a link
 * @pre a pointer to the game
 * @post output ERROR or OK
 */
void test2_game_add_link();
/**
 * @test Test function for getting the player
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_player();
/**
 * @test Test function for getting the player
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test2_game_get_player();
/**
 * @test Test function for adding the player
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_add_player();
/**
 * @test Test function for adding the player
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_add_player();
/**
 * @test Test function for getting the player location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test1_game_get_player_location();
/**
 * @test Test function for getting the player location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_player_location();
/**
 * @test Test function for getting the enemy
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test1_game_get_enemy();
/**
 * @test Test function for getting the player
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_enemy();
/**
 * @test Test function for adding the enemy
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test1_game_add_enemy();

/**
 * @test Test function for adding the enemy
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_add_enemy();
/**
 * @test Test function for adding an object
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_add_object();
/**
 * @test Test function for adding an object
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_add_object();
/**
 * @test Test function for getting the object location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_object_location();
/**
 * @test Test function for getting the object location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_object_location();
/**
 * @test Test function for setting the object location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_set_object_location();
/**
 * @test Test function for setting the object location
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_set_object_location();
/**
 * @test Test function for getting a object 
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_object();
/**
 * @test Test function for getting a object 
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_object();
/**
 * @test Test function for getting a the object's ids 
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_objects_ids();
/**
 * @test Test function for getting a the object's ids 
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_objects_ids();
/**
 * @test Test function for getting a the object by their name
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_object_by_name();
/**
 * @test Test function for getting a the object by their name
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_object_by_name();
/**
 * @test Test function for getting the last command
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_last_command();
/**
 * @test Test function for getting the last command
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_last_command();
/**
 * @test Test function for getting the status os the game
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_st();
/**
 * @test Test function for getting the status os the game
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_st();
/**
 * @test Test function for getting the description
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_act_description();
/**
 * @test Test function for getting the description
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_act_description();
/**
 * @test Test function for setting the description
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_set_act_description();
/**
 * @test Test function for setting the description
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_set_act_description();
/**
 * @test Test function for updating the game
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_update();
/**
 * @test Test function for updating the game
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_update();
/**
 * @test Test function for getting the dialogue
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */

void test1_game_get_dialogue();
/**
 * @test Test function for getting the dialogue
 * @pre a pointer to the game
 * @post output a pointer to NULL
 */
void test2_game_get_dialogue();
/**
 * @test Test function for getting the space's id
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_get_space_id_at();
/**
 * @test Test function for getting the space's id
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_get_space_id_at();
/**
 * @test Test function for setting the connection status
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_set_connection_status();
/**
 * @test Test function for setting the connection status
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_set_connection_status();
/**
 * @test Test function for terminating the game
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */

void test1_game_is_over();
/**
 * @test Test function for terminating the game
 * @pre a pointer to the game
 * @post output to OK or ERROR
 */
void test2_game_is_over();


#endif