/**
 * @brief It defines de dialogue interface
 *
 * @file dialogue.h
 * @author Noelia Rincón
 * @date 01-05-2023
 * @copyright GNU Public License
*/

#ifndef DIALOGUE_H
#define DIALOGUE_H

#include "types.h"
#include "command.h"
#include "space.h"


/**
 * @brief dialogue structure
 */
typedef struct _Dialogue Dialogue;
/**
 * @brief creates a new dialogue
 * @author Noelia Rincón
 *
 * @return pointer to the new dialogue, or NULL if something went worng
 */
Dialogue *dialogue_create();
/**
 * @brief destroys the dialogue
 * @author Noelia Rincón
 *
 * @return @return OK, if everything goes well or ERROR if there was some mistake 
 */
STATUS dialogue_destroy(Dialogue *d);
/**
 * @brief creates the message that will be show in the game
 * @author Noelia Rincón
 *
 * @return @return OK, if everything goes well or ERROR if there was some mistake 
 */
STATUS dialogue_string(Dialogue *d, T_Command cmd, STATUS st, char *str);


#endif