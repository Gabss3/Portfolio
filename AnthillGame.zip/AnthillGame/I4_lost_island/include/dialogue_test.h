/** 
 * @brief It declares the tests for the dialogue module
 * 
 * @file dialogue_test.h
 * @author Noelia Rincón ROldán
 * @version 2.0 
 * @date 05-05-2023
 * @copyright GNU Public License
 */

#ifndef DIALOGUE_TEST_H
#define DIALOGUE_TEST_H

/**
 * @test Test dialogue creation
 * @pre pointer to dialogue = NULL 
 * @post Non NULL pointer to dialogue 
 */
void test1_dialogue_create();
/**
 * @test Test function for destroying the dialogue
 * @pre pointer to dialogue = NULL 
 * @post Output == ERROR
 */
void test1_dialogue_destroy();
#define DIALOGUE_TEST_H


#endif