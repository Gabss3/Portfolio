/** 
 * @brief It declares the tests for the inventory module
 * 
 * @file inventory_test.h
 * @author Blanca Matas Gavira
 * @version 0.2 
 * @date 23-03-2023
 * @copyright GNU Public License
 */

#ifndef INVENTORY_TEST_H
#define INVENTORY_TEST_H


/**
 * @test Test inventory creation
 * @pre None
 * @post Non-NULL pointer to inventory
 */
void test1_inventory_create();

/**
 * @test Test inventory creation
 * @pre None
 * @post Inventory is empty (NULL)
 */
void test2_inventory_create();

/**
 * @test Test inventory destruction
 * @pre Non-NULL pointer to inventory
 * @post Inventory is successfully destroyed
 */
void test1_inventory_destroy();

/**
 * @test Test inventory destruction
 * @pre NULL pointer to inventory
 * @post No action is taken
 */
void test2_inventory_destroy();

/**
 * @test Test function for setting an object in inventory
 * @pre Non-NULL pointer to inventory, valid object IDs
 * @post Object is successfully set in inventory
 */
void test1_inventory_set_obj();

/**
 * @test Test function for setting an object in inventory
 * @pre NULL pointer to inventory
 * @post Output == ERROR
 */
void test2_inventory_set_obj();

/**
 * @test Test function for getting objects from inventory
 * @pre Non-NULL pointer to inventory
 * @post Output == Array of object IDs in inventory
 */
void test1_inventory_get_objs();

/**
 * @test Test function for getting objects from inventory
 * @pre NULL pointer to inventory
 * @post Output == NULL
 */
void test2_inventory_get_objs();

/**
 * @test Test function for getting maximum number of objects in inventory
 * @pre Non-NULL pointer to inventory
 * @post Output == maximun Number of objects in inventory
 */
void test1_inventory_get_maxobjs();

/**
 * @test Test function for getting maximun number of objects in inventory
 * @pre NULL pointer to inventory
 * @post Output == -1
 */
void test2_inventory_get_maxobjs();

/**
 * @test Test function for deleting object from inventory
 * @pre Non-NULL pointer to inventory, valid object ID
 * @post Object is successfully deleted from inventory
 */
void test1_inventory_del_object();

/**
 * @test Test function for deleting object from inventory
 * @pre NULL pointer to inventory
 * @post Output == ERROR
 */
void test2_inventory_del_object();

/**
 * @test Test function for checking if an object with a given ID exists in the inventory
 * @pre Non-NULL pointer to inventory, valid index
 * @post Output == TRUE
 */
void test1_inventory_find_object();

/**
 * @test Test function for getting object ID from inventory
 * @pre NULL pointer to inventory
 * @post Output == FALSE
 */
void test2_inventory_find_object();


#endif
