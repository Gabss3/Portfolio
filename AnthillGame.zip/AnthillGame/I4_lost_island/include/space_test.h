/** 
 * @brief It declares the tests for the space module
 * 
 * @file space_test.h
 * @author Profesores Pprog
 * @version 2.0 
 * @date 09-03-2021
 * @copyright GNU Public License
 */

#ifndef SPACE_TEST_H
#define SPACE_TEST_H

/**
 * @test Test function for space creation
 * @pre Space ID is supplied
 * @post Non-NULL pointer to space is returned
 */
void test1_space_create();

/**
 * @test Test function for space creation
 * @pre Space ID is supplied
 * @post Space_ID == Supplied Space Id
 */
void test2_space_create();

/**
 * @test Test function for setting space name
 * @pre String with space name
 * @post Output == OK
 */
void test1_space_set_name();

/**
 * @test Test function for setting space name
 * @pre Pointer to space is NULL
 * @post Output == ERROR
 */
void test2_space_set_name();

/**
 * @test Test function for setting space name
 * @pre Pointer to space name is NULL (point to space is NON-NULL)
 * @post Output == ERROR
 */
void test3_space_set_name();

/**
 * @test Test function for getting space name
 * @pre Non-NULL pointer to space
 * @post Output == Space name
 */
void test1_space_get_name();

/**
 * @test Test function for getting space name
 * @pre NULL pointer to space
 * @post Output == NULL
 */
void test2_space_get_name();

/**
 * @test Test function for destroying space
 * @pre Non-NULL pointer to space
 * @post Space is successfully destroyed
 */
void test1_space_destroy();

/**
 * @test Test function for destroying space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_destroy();

/**
 * @test Test function for removing an object from space
 * @pre Non-NULL pointer to space, valid object ID
 * @post Object is successfully removed from space
 */
void test1_space_del_object();

/**
 * @test Test function for removing an object from space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_del_object();



/**
 * @test Test function for getting number of objects in space
 * @pre Non-NULL pointer to space
 * @post Output == Number of objects in space
 */
void test1_space_num_objects();

/**
 * @test Test function for getting number of objects in space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_num_objects();

/**
 * @test Test function for setting space description
 * @pre Non-NULL pointer to space, valid description
 * @post Space description is set to the supplied value
 */
void test1_space_set_description();

/**
 * @test Test function for setting space description
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_set_description();


/**
 * @test Test function for getting space ID
 * @pre Non-NULL pointer to space
 * @post Output == Space ID
 */
void test1_space_get_id();

/**
 * @test Test function for getting space ID
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_get_id();

/**
 * @test Test function for setting an object in space
 * @pre Non-NULL pointer to space, valid object ID
 * @post Object is successfully set in space
 */
void test1_space_set_object();

/**
 * @test Test function for setting an object in space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_set_object();

/**
 * @test Test function for getting the array of object IDs in space
 * @pre Non-NULL pointer to space
 * @post Returns the array of object IDs in space
 */
void test1_space_id_objects();

/**
 * @test Test function for getting the array of object IDs in space
 * @pre NULL pointer to space
 * @post Returns NULL
 */
void test2_space_id_objects();

/**
 * @test Test function for getting the description of a space
 * @pre Non-NULL pointer to space
 * @post Returns the description of the space
 */
void test1_space_get_description();

/**
 * @test Test function for getting the description of a space
 * @pre NULL pointer to space
 * @post Returns NULL
 */
void test2_space_get_description();

/**
 * @test Test function for setting a set in space
 * @pre Non-NULL pointers to space and set, valid set ID
 * @post Set is successfully set in space
 */
void test1_space_set_set();

/**
 * @test Test function for setting a set in space
 * @pre NULL pointers to space and set
 * @post Output == ERROR
 */
void test2_space_set_set();

/**
 * @test Test function for setting the light status of a space
 * @pre Non-NULL pointer to space
 * @post Light status of the space is successfully set
 */
void test1_space_set_light();

/**
 * @test Test function for setting the light status of a space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_set_light();

/**
 * @test Test function for getting the light status of a space
 * @pre Non-NULL pointer to space
 * @post Returns the light status of the space
 */
void test1_space_get_light();

/**
 * @test Test function for getting the light status of a space
 * @pre NULL pointer to space
 * @post Output == FALSE
 */
void test2_space_get_light();

/**
 * @test Test function for setting the ID of a space
 * @pre Non-NULL pointer to space, valid ID
 * @post ID of the space is successfully set
 */
void test1_space_set_id();

/**
 * @test Test function for setting the ID of a space
 * @pre NULL pointer to space
 * @post Output == ERROR
 */
void test2_space_set_id();

#endif
