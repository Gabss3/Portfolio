/**
 * @brief It defines the command interface
 *
 * @file command.h
 * @author Profesores PPROG, Blanca Matas
 * @version 3.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#ifndef COMMAND_H
#define COMMAND_H
#include "types.h"
#define N_CMDT 2
#define N_CMD 15

typedef enum enum_CmdType {
  CMDS,
  CMDL
} T_CmdType;

/**
 * @brief Different commands that can be used in the game
 * 
*/
typedef enum enum_Command {
  NO_CMD = -1,     /*no command*/ 
  UNKNOWN,         /*no recognized command*/ 
  EXIT,            /*exit game*/
  TAKE,            /*take an object*/
  DROP,            /*drop an object*/
  ATTACK,          /*attack the enemie */
  MOVE,            /*move player location*/
  INSPECT,         /*inspect the object or the space*/
  UP,              /*moves player location up*/
  DOWN,            /*moves player location down*/
  OPENED,          /*open locked rooms, if possible*/
  TURNON,          /*turns on the flash, if possible*/
  TURNOFF,         /*turns off the flash, if possible*/
  SAVE,            /*saves the game*/
  LOAD             /*loads the game*/
} T_Command;

/**
 * @brief Gets the user's input and compare it with the commands created
 * @author Blanca Matas
 * 
 * @return Returns the command, if it exits
*/
T_Command command_get_user_input();

#endif