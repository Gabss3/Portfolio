/**
 * @brief It defines enemy interface
 *
 * @file enemy.h
 * @author Noelia Rincón
 * @version 2.0
 * @date 14/04/2023
 * @copyright GNU Public License
 */

#ifndef enemy_H
#define enemy_H

#include "types.h"

/**
* @brief it indicates the number of enemys
*/
#define ENEMY_ID 1

/**
* @brief it indicates the maximun of health that the enemy can reach
*/
#define HEALTH_ENEMY 5

/**
 * @brief declaration of the enemy structure
 */
typedef struct _Enemy Enemy;

/**
 * @brief creates a new enemy
 * @author Noelia RIncón
 * 
 * 
 * @param id of the enemy created 
 * @return new enemy initialized
*/
Enemy* enemy_create(Id id);


/**
 * @brief frees the memory allocated for an enemy
 * @author Noelia Rincón
 * 
 * @param pointer to the enemy we want to destroy
 * @return OK, if everything goes well or ERROR if there was some mistake
*/
STATUS enemy_destroy(Enemy* enemy);


/**
 * @brief gets the id of the enemy
 * @author Noelia Rincón

 * @param pointer to the enemy we want to get its id
 * @return id of the enemy
*/
Id enemy_get_id(Enemy* enemy);

/**
 * @brief it sets the id of the enemy
 *  @author Noelia Rincón
 * 
 * @param enemy a pointer to the enemy
 * @param id a pointer to the id we want to set in the enemy
 * @return OK, if everything goes well or ERROR if there was some mistake 
*/
STATUS enemy_set_id(Enemy* enemy, Id id);

/**
 * @brief it sets the name of the enemy
 *  @author Noelia Rincón
 * 
 * @param enemy a pointer to the enemy
 * @param name a pointer to the name we want to set in the enemy
 * @return OK, if everything goes well or ERROR if there was some mistake 
*/
STATUS enemy_set_name(Enemy* enemy, char* name);

/**
 * @brief gets the name of the enemy
 * @author Noelia Rincón
 * 
 * @param enemy pointer to enemy
 * @return string with the name of the enemy
*/
const char* enemy_get_name(Enemy* enemy);

/**
 * @brief gets the enemy location
 * @author Noelia Rincón
 * 
 * @param enemy pointer to the enemy
 * @return id of the location of the enemy in the space
*/
Id enemy_get_location(Enemy* enemy);

/**
 * @brief sets the enemy location
 * @author Noelia Rincón
 * 
 * @param enemy pointer to the enemy
 * @param id id of the enemy
 * @return OK, if everything goes well or ERROR if there was some mistake 
*/
STATUS enemy_set_location(Enemy* enemy, Id id);

/**
 * @brief it gets the value of the health of the enemy
 * @author Noelia Rincón
 * 
 * @param enemy pointer to the enemy
 * @return int that indicates the health of the enemy
 */
int enemy_get_health(Enemy* enemy);

/**
 * @brief sets the value of the health of the enemy
 * @author Noelia Rincón
 * 
 * @param enemy pointer to the enemy
 * @param health int that represents the value of health we want the enemy to have 
 * @return OK, if everything goes well or ERROR if there was some mistake 
*/
STATUS enemy_set_health(Enemy* enemy, int health);

/**
 * @brief prints the enemy information
 * @author Noelia RIncon
 * 
 * This function prints the id,name,location and health of the enemy
 * @param enemy pointer to the enemy
 * @return OK, if everything goes well or ERROR if there was some mistake  
*/
STATUS enemy_print(Enemy* enemy);

#endif