/**
 * @brief Interface where the different types used in the game are
 *
 * @file types.h
 * @author Profesores PPROG, Noelia Rincón
 * @version 2.0
 * @date 29-11-2021
 * @copyright GNU Public License
 */

#ifndef TYPES_H
#define TYPES_H

/**
* @brief Max word size
*/
#define WORD_SIZE 1000




/**
* @brief No_id 
*/

#define NO_ID -1

/**
* @brief Max max spaces
*/
#define MAX_SPACES 100


/**
* @brief Max objects
*/
#define MAX_OBJECTS 100

/**
 * @brief Max inventory
 */
#define MAX_INVENTORY 100

/**
* @brief Max object array size
*/
#define OBJ_ARRAY 100


/**
* @brief Max set ids size
*/
#define MAX_SET_IDS 150

/**
 * @brief Max links
 */
#define MAX_LINKS 200




/**
 * @brief Max the subtitutes Id
 */
typedef long Id; 

/**
 * @brief Boolean, TRUE or FALSE
 */
typedef enum 
{
  FALSE, /* 0 */
  TRUE   /* 1 */
} BOOL;


/**
 * @brief STATE, ERROR or OK
 */
typedef enum 
{
  ERROR, /* 0 */
  OK     /* 1 */
} STATUS;


/**
 * @brief DIRECCIÓN, No direction, North, South, East, West, Up, Down
 */
typedef enum 
{ 
  NO_DIRECTION = -1, /*-1 */
  N, /*0 */
  S, /*1 */
  E, /*2 */
  W, /*3 */
  U, /*4 */
  D  /*5 */
} DIRECTION;

/**
 * @brief ACESS, OPEN or CLOSED
 */
typedef enum {
OPEN, /*0 */
CLOSED /*1 */
}ACCESS;

#endif
