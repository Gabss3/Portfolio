/**
 * @brief It defines inventory interface
 *
 * @file inventory.h
 * @author Noelia Rincón
 * @version 2.0
 * @date 13/03/2023
 * @copyright GNU Public License
 */

#ifndef INVENTORY_H
#define INVENTORY_H

#include "types.h"
#include "set.h"

/**
 * @brief declaration of the inventory structure  
 */
typedef struct _Inventory Inventory;
/**
  * @brief It creates an inventory, allocating memory and initializing its members
  * @author  Blanca Matas
  * 
  * @param it does not recieve any arguments 
  * @return a new inventory initialized
  */
Inventory *inventory_create();

/**
  * @brief It destroys an Inventory freeing its alocated memory
  * @author Blanca Matas
  * 
  * @param pointer to an inventory
  * @return OK if memory was freed succesfully or ERROR otherwise
  */
STATUS inventory_destroy(Inventory *inventory);

/**
 * @brief sets a new object in the inventory
 * @author Blanca Matas
 * 
 * @param inventory pointer to the inventory
 * @param id id of the object we want to add
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
STATUS inventory_set_obj(Inventory *inventory, Id id);

/**
 * @brief Deletes an object from the inventory
 * @author Blanca Matas

 * 
 * @param pointer to the inventory
 * @param Id with the id of the object to be removed
 * @return OK if the object was deleted succesfully or ERROR otherwise
 */
STATUS inventory_del_object(Inventory *inventory, Id object);

/**
 * @briefit gets the objects in the inventory
 * @author Blanca Matas
 * 
 * @param inventory pointer to the inventory
 * @return set of objects in the inventory
 */
Set *inventory_get_objs(Inventory* inventory);

/*
 *@brief Gets the maximum number of objects in the inventory
 * @author Blanca Matas
 *@param inventory a pointer to the inventory
 *@return an integer representing the maximum number of objects in the inventory
*/
int inventory_get_maxobjs(Inventory *inventory);

/**
  * @brief Prints an inventory
  * @author Blanca Matas
  * 
  * @param pointer to an inventory
  * @return OK if the inventory was printed succesfully or ERROR otherwise
  */
STATUS inventory_print(Inventory *inventory);

/*
 * @brief Checks if an object with a given ID exists in the inventory
 * @author Blanca Matas
 * @param inventory a pointer to the inventory
 * @param object the ID of the object
 * @returns returns OK if the object with the given ID exists in the inventory, or ERROR otherwise
*/
BOOL inventory_find_object(Inventory *inventory, Id object);

#endif