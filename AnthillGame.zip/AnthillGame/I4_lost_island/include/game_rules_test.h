/** 
 * @brief It declares the tests for the game_rules module
 * 
 * @file game_rules_test.h
 * @author Noelia Rincón ROldán
 * @version 0.2
 * @date 07/05/2023
 * @copyright GNU Public License
 */

#ifndef GAME_RULES_TEST_H
#define GAME_RULES_TEST_H

  void test1_gm_player_at_cherry();
  void test2_gm_player_at_cherry();
  void test1_gm_cherry_hidden();
  void test2_gm_cherry_hidden();
/*
  void test1_gm_cherry_drop();
  void test2_gm_cherry_drop();
  void test1_gm_masterkey_appearing();
  void test2_gm_masterkey_appearing();
  void test1_gm_escaped_message();
  void test2_gm_escaped_message(); 
  void test1_gm_killed_message();
  void test2_gm_killed_message();
  void test1_gm_volcano_message();
  void test2_gm_volcano_message();
  void test1_gm_teletransport_player();
  void test2_gm_teletransport_player();
*/


/************************Informe Manual*******************************
  Estas funciones no pueden ser comprobadas mediante el uso de tests, pero su funcionalidad se puede probar en el juego completo 
**********************************************/
#endif
