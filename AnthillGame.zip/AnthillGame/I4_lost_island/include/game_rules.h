#include "game.h"
#include "object.h"
#include "player.h"
#include "space.h"

/**
  * @brief It sets the object named cherry to not hidden
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  */
void gm_cherry_growing(Game *game);

/**
  * @brief It returns wether the player is at the same space as the object named cherry
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  * @returns returns TRUE if the player is at the same space or FALSE otherwise
  */
BOOL gm_player_at_cherry(Game *game);

/**
  * @brief It returns wether the object named cherry is hidden or not
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  * @returns returns TRUE if the cherry is hidden or FALSE otherwise
  */
BOOL gm_cherry_hidden(Game *game);

/**
  * @brief It drops the object named cherry
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  */
void gm_cherry_drop(Game *game);

/**
  * @brief It sets the object named masterkey to not hidden
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  */
void gm_masterkey_appearing(Game *game);

/**
  * @brief It sets an escaped message
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  * @param char a pointer to a string
  * @returns returns OK if the message was succesfully set or ERROR otherwise
  */
STATUS gm_escaped_message(Game *game, char *str);

/**
  * @brief It sets a killed message
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  * @param char a pointer to a string
  * @returns returns OK if the message was succesfully set or ERROR otherwise
  */
STATUS gm_killed_message(Game *game, char *str);

/**
  * @brief It sets a volcano message
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  * @param char a pointer to a string
  * @returns returns OK if the message was succesfully set or ERROR otherwise
  */
STATUS gm_volcano_message(Game *game, char *str);

/**
  * @brief It sets the player to a random space of the game
  * @author Gabriella Leano
  *
  * @param game a pointer to the game
  */
void gm_teletransport_player(Game *game);



