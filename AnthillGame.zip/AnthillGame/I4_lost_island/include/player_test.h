/** 
 * @brief It declares the tests for the link module
 * 
 * @file player_test.h
 * @author Noelia Rincón Roldán
 * @version 0.2 
 * @date 02-04-2023
 * @copyright GNU Public License
 */

#ifndef PLAYER_TEST_H
#define PLAYER_TEST_H


/**
 * @test Test function for creating a player
 * @pre None
 * @post New player is created with default values
 */
void test1_player_create();

/**
 * @test Test function for creating a player
 * @pre Non-NULL pointer to player
 * @post Output == NULL
 */
void test2_player_create();

/**
 * @test Test function for destroying a player
 * @pre Non-NULL pointer to player
 * @post Player is successfully destroyed
 */
void test1_player_destroy();

/**
 * @test Test function for destroying a player
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_destroy();

/**
 * @test Test function for getting player's ID
 * @pre Non-NULL pointer to player
 * @post Output == Player's ID
 */
void test1_player_get_id();

/**
 * @test Test function for getting player's ID
 * @pre NULL pointer to player
 * @post Output == -1
 */
void test2_player_get_id();

/**
 * @test Test function for getting player's name
 * @pre Non-NULL pointer to player
 * @post Output == Player's name
 */
void test1_player_get_name();

/**
 * @test Test function for getting player's name
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test2_player_get_name();

/**
 * @test Test function for getting player's location
 * @pre Non-NULL pointer to player
 * @post Output == Player's location
 */
void test1_player_get_location();

/**
 * @test Test function for getting player's location
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test2_player_get_location();

/**
 * @test Test function for checking if player has an object
 * @pre Non-NULL pointer to player, valid object ID
 * @post Output == true if player has the object, false otherwise
 */
void test1_player_find_object_inventory();

/**
 * @test Test function for checking if player has an object
 * @pre NULL pointer to player
 * @post Output == false
 */
void test2_player_find_object_inventory();

/**
 * @test Test function for getting player's health
 * @pre Non-NULL pointer to player
 * @post Output == Player's health
 */
void test1_player_get_health();

/**
 * @test Test function for getting player's health
 * @pre NULL pointer to player
 * @post Output == -1
 */
void test2_player_get_health();

/**
 * @test Test function for setting player's ID
 * @pre Non-NULL pointer to player, valid ID
 * @post Player's ID is set to the supplied value
 */
void test1_player_set_id();

/**
 * @test Test function for setting player's ID
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_id();

/**
 * @test Test function for setting player's name
 * @pre Non-NULL pointer to player, valid name
 * @post Player's name is set to the supplied value
 */
void test1_player_set_name();

/**
 * @test Test function for setting player's name
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_name();

/**
 * @test Test function for setting player's location
 * @pre Non-NULL pointer to player, valid location
 * @post Player's location is set to the supplied value
 */
void test1_player_set_location();

/**
 * @test Test function for setting player's location
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_location();

/**
 * @test Test function for adding an object to player's inventory
 * @pre Non-NULL pointer to player, valid object ID
 * @post Object is successfully added to player's inventory
 */
void test1_player_set_object();

/**
 * @test Test function for adding an object to player's inventory
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_object();

/**
 * @test Test function for setting player's health
 * @pre Non-NULL pointer to player, valid health value
 * @post Player's health is set to the supplied value
 */
void test1_player_set_health();

/**
 * @test Test function for setting player's health
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_health();

/**
 * @test Test function for removing an object from player's inventory
 * @pre Non-NULL pointer to player, valid object ID
 * @post Object is successfully removed from player's inventory
 */
void test1_player_delete_object();

/**
 * @test Test function for removing an object from player's inventory
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_delete_object();

/**
 * @test Test function for getting player's inventory
 * @pre Non-NULL pointer to player
 * @post Output == Player's inventory
 */
void test1_player_get_inventory();

/**
 * @test Test function for getting player's inventory
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test2_player_get_inventory();

/**
 * @test Test function for setting player's max inventory size
 * @pre Non-NULL pointer to player, valid max inventory size
 * @post Player's max inventory size is set to the supplied value
 */
void test1_player_set_inventory();

/**
 * @test Test function for setting player's max inventory size
 * @pre NULL pointer to player
 * @post Output == ERROR
 */
void test2_player_set_inventory();
/**
 * @test Test function for getting the object's ids
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test1_player_get_object_ids();
/**
 * @test Test function for getting the object's ids
 * @pre NULL pointer to player
 * @post Output == NULL
 */

void test2_player_get_object_ids();
/**
 * @test Test function for getting the number of objects
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test1_player_num_obj();
/**
 * @test Test function for getting the number of objects
 * @pre NULL pointer to player
 * @post Output == NULL
 */
void test2_player_num_obj();


#endif