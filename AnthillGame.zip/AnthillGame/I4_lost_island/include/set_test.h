/** 
 * @brief It declares the tests for the set module
 * 
 * @file set_test.h
 * @author Noelia Rincón
 * @version 0.2 
 * @date 11-03-2023
 * @copyright GNU Public License
 */

#ifndef SET_TEST_H
#define SET_TEST_H

/**
 * @test Test set creation
 * @pre Crear Set inicializado y destruirlo
 * @post OK
 */
void test1_set_create();

/**
 * @test Test set creation
 * @pre Crear Set que no sea NULL
 * @post OK
 */
void test2_set_create();

/**
 * @test Test set creation
 * @pre Crear Set con Algo Exacto
 * @post OK
 */
void test3_set_create();

/**
 * @test Test set destroy
 * @pre Destruir un set inicializado
 * @post OK
 */
void test1_set_destroy();

/**
 * @test Test set destroy
 * @pre Destruir un set sin inicializar 
 * @post ERROR
 */
void test2_set_destroy();

/**
 * @test Test set add object
 * @pre Añadir a un set inicializado un id
 * @post OK
 */
void test1_set_add_id();
/**
 * @test Test set add object
 * @pre Añadir a un set sin inicializar un id
 * @post ERROR
 */
void test2_set_add_id();
/**
 * @test Test set add object
 * @pre Añadir el mismo ID dos veces. 
 * @post ERROR
 */
void test3_set_add_id();
/**
 * @test Test set delete object
 * @pre Añade y elimina a un set inicializado
 * @post OK
 */
void test1_set_del_id();
/**
 * @test Test set delete object
 * @pre Elimina de un set inicializado, pero sin nada
 * @post ERROR
 */
void test2_set_del_id();
/**
 * @test Test set delete object
 * @pre Elimina de un set sin inicializar 
 * @post ERROR
 */
void test3_set_del_id();
/**
 * @test Test set delete object
 * @pre Añade y elimina dos veces el mismo valor
 * @post ERROR
 */
void test4_set_del_id();
/**
 * @test Test set delete object
 * @pre Añade x valores, pero elimina uno que no esta
 * @post ERROR
 */
void test5_set_del_id();


/**
 * @test Test get size
 * @pre Añade un objeto a un set inicializado y cuenta cuantos objetos hay en el set
 * @post 1
 */
void test1_set_total_id();

/**
 * @test Test get size
 * @pre Añade un objeto a un set inicializado y cuenta cuantos objetos hay en el set
 * @post 1
 */
void test2_set_total_id();

/**
 * @test Test get size
 * @pre Obtiene el numero de objetos en un set vacio
 * @post 0
 */
void test3_set_total_id();

/**
 * @test Test get size
 * @pre Obtiene el numero de objetos en un set sin inicializar
 * @post ,1
 */
void test4_set_total_id();
/**
 * @test Test function to know if an array is full
 * @pre NULL pointer to player
 * @post Output TRUE or FALSE
 */
void test1_set_array_full();
/**
 * @test Test function to know if an array is full
 * @pre NULL pointer to player
 * @post Output TRUE or FALSE
 */
void test2_set_array_full();
/**
 * @test Test function to know if an id exists
 * @pre NULL pointer to player
 * @post Output TRUE or FALSE
 */

void test1_set_id_exists();
/**
 * @test Test function to know if an id exists
 * @pre NULL pointer to player
 * @post Output TRUE or FALSE
 */
void test2_set_id_exists();







#endif