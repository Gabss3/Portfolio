/**
 * @brief It defines link interface
 *
 * @file link.h
 * @author Gabriella Leaño
 * @version 2.0
 * @date 12/03/2023
 * @copyright GNU Public License
 */

#ifndef LINK_H
#define LINK_H

#include "types.h"

/**
 * @brief Declaration of link structure
 */
typedef struct _Link Link;

/**
  * @brief Creates a new Link object and initializes its attributes to default values
  * @author Gabriella Leano
  * 
  * @returns returns a pointer to the newly created Link object, or NULL if memory allocation fails
  */
Link* link_create(Id id);

/**
  * @brief Destroys a Link object freeing up memory occupied by it 
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object to be destroyed
  * @returns returns OK if the link was successfully destroyed or ERROR otherwise
  */
STATUS link_destroy(Link* link);

/**
  * @brief sets the id of the link
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object to be destroyed
  * @param id the id we want to set in the link
  * @returns returns OK if the id was successfully se or ERROR otherwise
  */
STATUS link_set_id(Link *l, Id id);

/**
  * @brief Gets the ID of a Link object (graph edge)
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns the ID of the Link object
  */
Id link_get_id(Link* link);

/**
  * @brief Sets the name of a Link object 
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @param name a pointer to a string containing the name to set for the Link object
  * @returns returns OK if the name was successfully set, or ERROR otherwise
  */
STATUS link_set_name(Link *link, char *name);

/**
  * @brief Gets the name of a Link object as a string
  * @author Gabriella Leano, Blanca Matas, Noelia Rincon
  * 
  * @param l a pointer to the Link object
  * @returns returns a pointer to a string containing the name of the Link object, or NULL if an error occurs
  */
char *link_get_name(Link *link);

/**
  * @brief Sets the ID of the origin Space of a Link object to a given value, representing the starting point of the connection between two spaces
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @param origin the ID value to set for the origin Space of the Link object
  * @returns returns OK if the origin ID was successfully set, or ERROR otherwise
  */
STATUS link_set_origin(Link* link, Id origin);

/**
  * @brief Gets the ID of the origin Space  of a Link object , representing the starting point of the connection between two spaces
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns the ID of the origin Space  of the Link object
  */
Id link_get_origin(Link* link);

/**
  * @brief Gets the ID of the origin Space of a Link object
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns OK if the destination ID was successfully set, or ERROR otherwise
  */
STATUS link_set_destination(Link* link, Id destiny);

/**
  * @brief Gets the ID of the destination Space of a Link object, representing the ending point of the connection between two spaces
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns the ID of the destination Space (graph node) of the Link object
  */
Id link_get_destination(Link* link);

/**
  * @brief Sets the direction of the connection represented by a Link object to a given value, indicating the direction in which it allows movement between spaces (e.g., north, south, etc.)
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @param direction the direction value to set for the Link object
  * @returns returns OK if the direction was successfully set, or ERROR otherwise
  */
STATUS link_set_direction(Link* link, DIRECTION direction);

/**
  * @brief Gets the direction of the connection represented by a Link object, indicating the direction in which it allows movement between spaces (e.g., north, south, etc.)
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns the direction of the connection represented by the Link object
  */
DIRECTION link_get_direction(Link* link);

/**
  * @brief Sets the status of a Link object to a given value, indicating whether it is open or closed (or other possible statuses)
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @param status the status value to set for the Link object
  * @returns returns OK if the status was successfully set, or ERROR otherwise
  */
STATUS link_set_status(Link* link, ACCESS status);

/**
  * @brief Gets the status of a Link object, indicating whether it is open or closed (or other possible statuses)
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns the status of the Link object (OPEN OR CLOSED)
  */
ACCESS link_get_status(Link* link);

/**
  * @brief Prints the attributes of a Link object, such as its ID, name, origin Space, destination Space, direction, and status
  *
  * @author Gabriella Leano
  * 
  * @param l a pointer to the Link object
  * @returns returns OK if the Link object was successfully printed, or ERROR otherwise
  */
STATUS link_print(Link* link);

#endif