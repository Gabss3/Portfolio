package ejercicio3;

import java.util.List;
import java.util.Map;

import ejercicio2.*;

public class NewMenuTester extends NewPlatosTester{
	public static void main(String[] args) {
		NewMenuTester tester = new NewMenuTester();
		for (Menu menu : tester.newCrearMenus())
			System.out.println("* " + menu);
	}

	public List<Menu> newCrearMenus() {
		Map<String, Plato> platos = this.newCrearPlatos();
		Menu m1 = new Menu(platos.get("Sushi"), platos.get("Refresco de Sandía"));
		
		
		return List.of(m1);
	}
}
