package ejercicio1;


/**
 * Clase que representa la información nutricional de un alimento.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class InfoNutricional {
	public double calorias;
	public double hidratosCarbono;
	public double grasaTotal;
	public double grasaSaturada;
	public double proteinas;
	public double azucares;
	public double fibra;
	public double sodio;
	public int cantidad;

	/**
     * Constructor de la clase InfoNutricional.
     * @param calorias          Cantidad de calorías.
     * @param hidratosCarbono   Cantidad de hidratos de carbono.
     * @param grasaTotal        Cantidad de grasa total.
     * @param grasaSaturada     Cantidad de grasa saturada.
     * @param proteinas         Cantidad de proteínas.
     * @param azucares          Cantidad de azúcares.
     * @param fibra             Cantidad de fibra.
     * @param sodio             Cantidad de sodio.
     */
	public InfoNutricional(double calorias, double hidratosCarbono, double grasaTotal, double grasaSaturada,
			double proteinas, double azucares, double fibra, double sodio) {
		this.calorias = calorias;
		this.hidratosCarbono = hidratosCarbono;
		this.grasaTotal = grasaTotal;
		this.grasaSaturada = grasaSaturada;
		this.proteinas = proteinas;
		this.azucares = azucares;
		this.fibra = fibra;
		this.sodio = sodio;
	}

	/**
     * Método para obtener la cantidad de calorías.
     * @return Cantidad de calorías.
     */
	public double getCalorias() {
		return this.calorias;
	}

	/**
     * Método para obtener la cantidad de hidratos de carbono.
     * @return Cantidad de hidratos de carbono.
     */
	public double getHidratosCarbono() {
		return this.hidratosCarbono;
	}

	/**
     * Método para obtener la cantidad de grasa total.
     * @return Cantidad de grasa total.
     */
	public double getGrasaTotal() {
		return this.grasaTotal;
	}

	/**
     * Método para obtener la cantidad de grasa saturada.
     * @return Cantidad de grasa saturada.
     */
	public double getGrasaSaturada() {
		return this.grasaSaturada;
	}

	/**
     * Método para obtener la cantidad de proteínas.
     * @return Cantidad de proteínas.
     */
	public double getProteinas() {
		return this.proteinas;
	}

	/**
     * Método para obtener la cantidad de azúcares.
     * @return Cantidad de azúcares.
     */
	public double getAzucares() {
		return this.azucares;
	}

	/**
     * Método para obtener la cantidad de fibra.
     * @return Cantidad de fibra.
     */
	public double getFibra() {
		return this.fibra;
	}

	/**
     * Método para obtener la cantidad de sodio.
     * @return Cantidad de sodio.
     */
	public double getSodio() {
		return this.sodio;
	}

	/**
     * Método para establecer la cantidad.
     * @param cant Cantidad a establecer.
     */
	public void setCantidad(int cant) {
		this.cantidad = cant;
	}

	/**
     * Método para obtener la cantidad.
     * @return Cantidad.
     */
	public int getCantidad() {
		return this.cantidad;
	}

	/**
     * Método para sumar calorías.
     * @param calorias Calorías a sumar.
     */
	public void SumCalorias(double calorias) {
		this.calorias = this.calorias + calorias;
	}

	/**
     * Método para sumar hidratos de carbono.
     * @param hidratos Hidratos de carbono a sumar.
     */
	public void SumHidratosCarbono(double hidratos) {
		this.hidratosCarbono = this.hidratosCarbono + hidratos;
	}

	/**
     * Método para sumar grasa total.
     * @param grasaTot Grasa total a sumar.
     */
	public void sumGrasaTotal(double grasaTot) {
		this.grasaTotal = this.grasaTotal + grasaTot;
	}

	/**
     * Método para sumar grasa saturada.
     * @param grasaSat Grasa saturada a sumar.
     */
	public void SumGrasaSaturada(double grasaSat) {
		this.grasaSaturada = this.grasaSaturada + grasaSat;
	}

	 /**
     * Método para sumar proteínas.
     * @param proteinas Proteínas a sumar.
     */
	public void SumProteinas(double proteinas) {
		this.proteinas = this.proteinas + proteinas;
	}

	/**
     * Método para sumar azúcares.
     * @param azucares Azúcares a sumar.
     */
	public void SumAzucares(double azucares) {
		this.azucares = this.azucares + azucares;
	}

	/**
     * Método para sumar sodio.
     * @param sodio Sodio a sumar.
     */
	public void SumSodio(double sodio) {
		this.sodio = this.sodio + sodio;
	}

	/**
     * Método para sumar fibra.
     * @param fibra Fibra a sumar.
     */
	public void SumFibra(double fibra) {
		this.fibra = this.fibra + fibra;
	}

	/**
     * Representación en cadena de caracteres de la información nutricional.
     * @return Cadena de caracteres representando la información nutricional.
     */
	public String toString() {
		return String.format("Valor energetico: " + this.calorias + " kcal, Hidratos de carbono: "
				+ this.hidratosCarbono + " g, Grasas: " + this.grasaTotal + "g, Saturadas: " + this.grasaSaturada
				+ " g, Proteinas: " + this.proteinas + " g, Azucares: " + this.azucares + " g, Fibra: " + this.fibra
				+ " g, Sodio: " + this.sodio + " mg.");
	}
}