package ejercicio1;

import java.util.*;

public class NewIngredientesTester {
	public static void main(String args[]) {
		NewIngredientesTester tester = new NewIngredientesTester();
		for (Ingrediente ingrediente : tester.newCrearIngrediente().values()) {
			System.out.println("* " + ingrediente);
		}
	}

	public Map<String, Ingrediente> newCrearIngrediente() {
		Map<String, Ingrediente> ingredientes = new LinkedHashMap<>();

		ingredientes.put("Agua",
				new Ingrediente("Agua", "Agua", new InfoNutricionalPeso(10, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1)));

		ingredientes.put("Sandía", new Ingrediente("Sandía", TipoIngrediente.FRUTA_VERDURA,
				new InfoNutricionalUnidad(356, 50, 11, 5, 0.7, 83, 1, 4)));

		ingredientes.put("Salmon", new Ingrediente("Salmon", TipoIngrediente.PESCADO,
				new InfoNutricionalUnidad(432, 0, 100, 12.81, 90, 0, 0, 6)));

		ingredientes.put("Arroz", new Ingrediente("Arroz", TipoIngrediente.CEREAL,
				new InfoNutricionalPeso(100.6, 94, 32, 0.2, 6.89, 0.6, 20, 0.1)));

		return ingredientes;
	}

}
