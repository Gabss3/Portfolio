package ejercicio5;

import java.util.ArrayList;
import java.util.List;

import ejercicio1.Alergeno;
import ejercicio1.ElementoNutricional;
import ejercicio2.NewPlatosTester;
import ejercicio2.Plato;
import ejercicio3.Menu;

public class NewPlanificadorTester extends NewPlatosTester {
	public static void main(String[] args) {
		NewPlanificadorTester tester = new NewPlanificadorTester();
		List<Plato> platos = new ArrayList<>(tester.newCrearPlatos().values());
		PlanificadorMenu planificador = new PlanificadorMenu(platos).conMaximo(ElementoNutricional.GRASA_SATURADA, 500.0)
				.conMaximo(ElementoNutricional.AZUCARES, 500.0).sinAlergenos(Alergeno.GLUTEN, Alergeno.HUEVO);
// busqueda 1
		Menu menu = planificador.planificar(800, 2500);
		System.out.println("* " + menu);
// busqueda 2
		planificador = new PlanificadorMenu(platos).conMaximo(ElementoNutricional.HIDRATOSCARBONO, 100.0)
				.conMaximo(ElementoNutricional.AZUCARES, 60.0);
		menu = planificador.planificar(900, 50000);
		System.out.println("* " + menu);
}
	}
