package ejercicio5;

import ejercicio3.*;
import ejercicio2.*;
import ejercicio1.*;

import java.util.*;


/**
 * Clase que representa un planificador de menús.
 * Autores: Lia Lazaro, Gabriella Leano
 */
public class PlanificadorMenu{
	private List<Plato> platosDisponibles;
	private InfoNutricional maximoDe = new InfoNutricional(-1,-1,-1,-1,-1,-1,-1,-1);
	private Map<ElementoNutricional, Double> conMaximo = new HashMap<>();
	private List<Alergeno> alergenosExcluidos = new ArrayList<>();

	/**
     * Constructor de la clase PlanificadorMenu.
     * @param platosDisponibles Lista de platos disponibles para planificar menús.
     */
	public PlanificadorMenu(List<Plato> platosDisponibles){
		this.platosDisponibles = platosDisponibles;
	}

	/**
     * Método para establecer un límite máximo para un elemento nutricional específico.
     * @param elemento El elemento nutricional al que se le establecerá el límite máximo.
     * @param valor El valor máximo permitido para el elemento nutricional.
     * @return La instancia actual del PlanificadorMenu.
     */
	public PlanificadorMenu conMaximo(ElementoNutricional elemento, Double valor){
		if (elemento == ElementoNutricional.GRASA_SATURADA){
			this.maximoDe.SumGrasaSaturada(valor+1);
		} else if (elemento == ElementoNutricional.AZUCARES){
			this.maximoDe.SumAzucares(valor+1);
		} else if (elemento == ElementoNutricional.SODIO) {
			this.maximoDe.SumSodio(valor+1);
		} else if (elemento == ElementoNutricional.HIDRATOSCARBONO) {
			this.maximoDe.SumHidratosCarbono(valor+1);
		} else if (elemento == ElementoNutricional.GRASA_TOTAL) {
			this.maximoDe.sumGrasaTotal(valor+1);
		} else if (elemento == ElementoNutricional.PROTEINAS) {
			this.maximoDe.SumProteinas(valor+1);
		} else if (elemento == ElementoNutricional.FIBRA) {
			this.maximoDe.SumFibra(valor+1);
		}

		return this;
	}

	/**
     * Método para excluir alérgenos del menú planificado.
     * @param alergenos Lista de alérgenos a excluir.
     * @return La instancia actual del PlanificadorMenu.
     */
	public PlanificadorMenu sinAlergenos(Alergeno... alergenos) {
		for (Alergeno alergeno : alergenos) {
			this.alergenosExcluidos.add(alergeno);
		}
		return this;
	}

	/**
     * Método para planificar un menú dentro de un rango de calorías dado y con las restricciones establecidas.
     * @param caloriasMin Calorías mínimas permitidas en el menú.
     * @param caloriasMax Calorías máximas permitidas en el menú.
     * @return El menú planificado que cumple con las restricciones establecidas, o null si no es posible planificar un menú.
     */
	public Menu planificar(int caloriasMin, int caloriasMax) {
		List<Plato> menuPlanificado = new ArrayList<>();
		InfoNutricional info;
		int caloriasDisponibles = caloriasMax;
		int caloriasMenu = 0;
		int flag=0;
	
		for(Plato plato : platosDisponibles) {
			info = plato.getInfo();
			if(cumpleCriterios(plato)){
		
				for(Alergeno a : plato.getAlergenos()){
					if(alergenosExcluidos.contains(a)){
						flag=1;
						break;
					}
				}
									
				if(flag==0 && caloriasDisponibles-plato.getInfo().getCalorias()>0){
					caloriasMenu = caloriasMenu + (int)info.getCalorias();
					menuPlanificado.add(plato);
				}
												
			}
		}

		if (menuPlanificado.isEmpty() || caloriasMenu<caloriasMin) {
			return null;
		}

		Plato[] platosArray = menuPlanificado.toArray(new Plato[menuPlanificado.size()]);
		return new Menu(platosArray);

		 /*return new Menu(menuPlanificado);*/
	}

	 /**
     * Método interno para verificar si un plato cumple con los criterios de restricción establecidos.
     * @param plato El plato a verificar.
     * @return true si el plato cumple con los criterios de restricción, false en caso contrario.
     */
	private boolean cumpleCriterios(Plato plato){

		InfoNutricional info;
		
		info=plato.getInfo();
		
		List<Alergeno> alergenosDelPlato = plato.getAlergenos();
		
		if (alergenosExcluidos.containsAll(alergenosDelPlato)){
	        return false;
	    }
		
		if(maximoDe.getGrasaSaturada()>0){
			if(info.getGrasaSaturada()<= maximoDe.getGrasaSaturada()){
				maximoDe.SumGrasaSaturada(-info.getGrasaSaturada());
			}
			else{
				return false;
			}
		}
		
		if(maximoDe.getAzucares()>0){
			if((info.getAzucares() <= maximoDe.getAzucares())){
				maximoDe.SumAzucares(-info.getAzucares());
			}
			else{
				return false;
			}
		}

		if(maximoDe.getSodio()>0){
			if((info.getSodio() <= maximoDe.getSodio())){
				maximoDe.SumSodio(-info.getSodio());
			}
			else{
				return false;
			}
		}

		if(maximoDe.getGrasaTotal()>0){
			if(info.getGrasaTotal() <= maximoDe.getGrasaTotal()){
				maximoDe.sumGrasaTotal(-info.getGrasaTotal());
			}
			else{
				return false;
			}
		}

		if(maximoDe.getFibra()>0){
			if((info.getFibra()<= maximoDe.getFibra())){
				maximoDe.SumFibra(-info.getFibra());
			}
			else{
				return false;
			}
		}

		if(maximoDe.getHidratosCarbono()>0){
			if((info.getHidratosCarbono()<=maximoDe.getHidratosCarbono())){
				maximoDe.SumHidratosCarbono(-info.getHidratosCarbono());
			}
			else{
				return false;
			}

		}

		if(maximoDe.getProteinas()>0){
			if((info.getProteinas()<=maximoDe.getProteinas())){
				maximoDe.SumProteinas(-info.getProteinas());
			}
			else{
				return false;
			}
		}		
		
		return true;	 
	}

	public Map<ElementoNutricional, Double> getConMaximo() {
		return conMaximo;
	}

	public void setConMaximo(Map<ElementoNutricional, Double> conMaximo) {
		this.conMaximo = conMaximo;
	}
}