package ejercicio4;
import ejercicio3.*;
import ejercicio2.*;
import ejercicio1.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.util.Map.Entry;


/**
 * Clase para el manejo de ficheros en un sistema de gestión de menús y platos.
 * Permite guardar y leer información relacionada con ingredientes, platos y menús desde y hacia un archivo de texto.
 * Autores: Lia Lazaro y Gabriella Leano.
 */
public class ManejadorFicheros {
	private static Set<Ingrediente> ingredientesImpresos = new HashSet<>();
	private static Set<Plato> platosImpresos = new HashSet<>();
	private static List<Plato> platos = new ArrayList<>();
	private static Set<Menu> menus = new LinkedHashSet<>();
	private static Map<Ingrediente, Double> ingred = new HashMap<>();
	private static List<Alergeno> alergenos = Arrays.asList(Alergeno.values());

	/**
     * Obtiene los menús disponibles.
     * @return Conjunto de menús.
     */
	public static Set<Menu> getMenus() { 
		return ManejadorFicheros.menus;
	}

	/**
     * Establece los menús disponibles.
     * @param menus Conjunto de menús.
     */
	public static void setMenus(Set<Menu> menus) {
		ManejadorFicheros.menus = menus;
	}

	/**
     * Guarda la información de los menús en un fichero.
     * @param nombreFichero Nombre del fichero donde se guardará la información.
     * @param menusregist Lista de menús a guardar.
     */
	public static void guardarFichero(String nombreFichero, List<Menu> menusregist) {
		try {
			FileWriter salida = new FileWriter(nombreFichero);
			BufferedWriter buffer = new BufferedWriter(salida);

			for (Menu menu : menusregist) {
				platos = menu.getPlatos();

				for (Plato plato : platos) {
					if (platosImpresos.add(plato)) {
						// Este plato no ha sido impreso antes, así que imprímelo
						ingred = plato.getIngredientesCant();
						for (Ingrediente ingrediente : ingred.keySet()) {
							if (ingredientesImpresos.add(ingrediente)) {
								// Este ingrediente no ha sido impreso antes, así que imprímelo
								InfoNutricional infoI = ingrediente.getInfo();
								int unidad_peso = infoI.getCantidad();
								List<Alergeno> ale = ingrediente.getAlergenos();

								if (unidad_peso == 100) {
									buffer.write("INGREDIENTE_PESO;");
								} else if (unidad_peso == 1) {
									buffer.write("INGREDIENTE_UNIDAD;");
								}

								buffer.write(ingrediente.getNombre() + ";" + ingrediente.getTipo() + ";"
										+ infoI.getCalorias() + ";" + infoI.getHidratosCarbono() + ";"
										+ infoI.getGrasaTotal() + ";" + infoI.getGrasaSaturada() + ";"
										+ infoI.getProteinas() + ";" + infoI.getAzucares() + ";" + infoI.getFibra()
										+ ";" + infoI.getSodio() + ";");

								// Falta imprimir los alergenos
								int length = alergenos.size();
								for (Alergeno a1 : alergenos) {

									if (length > 1) {
										if (ale.contains(a1)) {
											buffer.write("S;");
										} else {
											buffer.write("N;");
										}
									} else {
										if (ale.contains(a1)) {
											buffer.write("S");
										} else {
											buffer.write("N");
										}
									}
									length = length - 1;
								}

								buffer.newLine();
							}
						}
						buffer.write("PLATO;" + plato.getNombre());

						if (!plato.getPlatos().isEmpty()) {
							for (Plato pi : plato.getPlatos()) {
								buffer.write(";PLATO " + pi.getNombre());
							}
						}

						for (Entry<Ingrediente, Double> ingredienteP : ingred.entrySet()) {
							InfoNutricional infoI = ingredienteP.getKey().getInfo();
							int unidad_peso = infoI.getCantidad();

							if (unidad_peso == 100) {
								buffer.write(";INGREDIENTE " + ingredienteP.getKey().getNombre() + ":"
										+ (ingredienteP.getValue() * 100));
							} else {
								buffer.write(";INGREDIENTE " + ingredienteP.getKey().getNombre() + ":"
										+ ingredienteP.getValue());
							}
						}
						buffer.newLine();
					}
				}

				buffer.write("MENU");
				for (Plato PlatoM : platos) {
					buffer.write(";" + PlatoM.getNombre());
				}
				buffer.newLine();
			}
			buffer.close();

			System.out.println("Archivo creado exitosamente.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
     * Lee la información de los menús desde un fichero.
     * @param nombreFichero Nombre del fichero del que se leerá la información.
     */
	public static void leerFichero(String nombreFichero) {
		List<Plato> platos = new ArrayList<>();
		List<Ingrediente> ingredientes = new ArrayList<>();

		try (FileReader fileReader = new FileReader(nombreFichero);
				BufferedReader bufferedReader = new BufferedReader(fileReader)) {

			String linea;
			while ((linea = bufferedReader.readLine()) != null) {
				String[] partes = linea.split(";");
				if (partes[0].equals("INGREDIENTE_PESO")) {

					if (partes[2].equals("Carne") || partes[2].equals("Fruta/Verdura") || partes[2].equals("Pescado")
							|| partes[2].equals("Legumbre") || partes[2].equals("Cereal") || partes[2].equals("Huevo")
							|| partes[2].equals("Lacteo") || partes[2].equals("Sodio")) {

						partes[2] = partes[2].toUpperCase();
						if (partes[2].equals("FRUTA/VERDURA")) {
							partes[2] = "FRUTA_VERDURA";
						}

						Ingrediente iP = new Ingrediente(partes[1], TipoIngrediente.valueOf(partes[2]),
								new InfoNutricionalPeso(Double.parseDouble(partes[3]), Double.parseDouble(partes[4]),
										Double.parseDouble(partes[5]), Double.parseDouble(partes[6]),
										Double.parseDouble(partes[7]), Double.parseDouble(partes[8]),
										Double.parseDouble(partes[9]), Double.parseDouble(partes[10])));
						for (int i = 0; i < 4; i++) {
							if (partes[i + 11].equals("S"))
								iP.getAlergenos().add(Alergeno.values()[i]);
						}

						ingredientes.add(iP);

					}

					else {
						Ingrediente iP = new Ingrediente(partes[1], partes[2],
								new InfoNutricionalPeso(Double.parseDouble(partes[3]), Double.parseDouble(partes[4]),
										Double.parseDouble(partes[5]), Double.parseDouble(partes[6]),
										Double.parseDouble(partes[7]), Double.parseDouble(partes[8]),
										Double.parseDouble(partes[9]), Double.parseDouble(partes[10])));
						for (int i = 0; i < 4; i++) {
							if (partes[i + 11].equals("S"))
								iP.getAlergenos().add(Alergeno.values()[i]);
						}
						ingredientes.add(iP);
					}

				}

				else if (partes[0].equals("INGREDIENTE_UNIDAD")) {
					if (partes[2].equals("Carne") || partes[2].equals("Fruta/Verdura") || partes[2].equals("Pescado")
							|| partes[2].equals("Legumbre") || partes[2].equals("Cereal") || partes[2].equals("Huevo")
							|| partes[2].equals("Lacteo") || partes[2].equals("Sodio")) {
						partes[2] = partes[2].toUpperCase();
						if (partes[2].equals("FRUTA/VERDURA")) {
							partes[2] = "FRUTA_VERDURA";
						}

						Ingrediente iU = new Ingrediente(partes[1], TipoIngrediente.valueOf(partes[2]),
								new InfoNutricionalUnidad(Double.parseDouble(partes[3]), Double.parseDouble(partes[4]),
										Double.parseDouble(partes[5]), Double.parseDouble(partes[6]),
										Double.parseDouble(partes[7]), Double.parseDouble(partes[8]),
										Double.parseDouble(partes[9]), Double.parseDouble(partes[10])));
						for (int i = 0; i < 4; i++) {
							if (partes[i + 11].equals("S"))
								iU.getAlergenos().add(Alergeno.values()[i]);
						}
						ingredientes.add(iU);
					} else {
						Ingrediente iU = new Ingrediente(partes[1], partes[2],
								new InfoNutricionalUnidad(Double.parseDouble(partes[3]), Double.parseDouble(partes[4]),
										Double.parseDouble(partes[5]), Double.parseDouble(partes[6]),
										Double.parseDouble(partes[7]), Double.parseDouble(partes[8]),
										Double.parseDouble(partes[9]), Double.parseDouble(partes[10])));
						for (int i = 0; i < 4; i++) {
							if (partes[i + 11].equals("S"))
								iU.getAlergenos().add(Alergeno.values()[i]);
						}

						ingredientes.add(iU);
					}
				}

				else if (partes[0].equals("PLATO")) {
					Plato p = new Plato(partes[1]);

					int tamaño = partes.length;
					for (int i = 2; i < tamaño; i++) {

						// datos es un array que contiene, por ejemplo: [INGREDIENTE, huevo:2.0]
						String[] datos = partes[i].split(" ");
						if (datos[0].equals("INGREDIENTE")) {
							// dats es un array que contiene, por ejemplo: [huevo, 2.0]
							String[] dats = datos[1].split(":");

							for (Ingrediente ing : ingredientes) {
								if (ing.getNombre().equals(dats[0])) {
									p.addIngrediente(ing, Double.parseDouble(dats[1]));
								}
							}
						} else if (datos[0].equals("PLATO")) {

							for (Plato pl : platos) {
								if (pl.getNombre().equals(datos[1])&&(!p.getPlatos().contains(pl))) {
									p.addPlato(pl);
								}
							}

							
						}
						platos.add(p);
					}
				}

				else if (partes[0].equals("MENU")) {

					Menu m = new Menu();

					for (String nombre : partes) {
						if (nombre != "MENU") {
							for (Plato pla : platos) {
								if (pla.getNombre().equals(nombre)) {
									m.addPlato(pla);
									break;
								}
							}
						}
					}
					ManejadorFicheros.menus.add(m);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}