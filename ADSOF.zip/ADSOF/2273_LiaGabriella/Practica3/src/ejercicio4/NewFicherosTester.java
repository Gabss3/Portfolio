package ejercicio4;
import java.util.List;

import ejercicio3.*;

public class NewFicherosTester extends NewMenuTester {
	public static void main(String[] args) {
		NewFicherosTester tester = new NewFicherosTester();
		List<Menu> menuu = tester.newCrearMenus();
		
// guardar lista de menús a fichero
		ManejadorFicheros.guardarFichero("comidaa.txt", menuu);
		
// leer lista de menús de fichero, e imprimirlos por pantalla
		ManejadorFicheros.leerFichero("comidaa.txt");
		
		for (Menu menu : ManejadorFicheros.getMenus())
			System.out.println("* " + menu);
	}
}
