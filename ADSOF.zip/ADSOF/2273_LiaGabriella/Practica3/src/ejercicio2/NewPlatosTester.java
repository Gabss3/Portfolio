package ejercicio2;
import ejercicio1.*;
import ejercicio1.NewIngredientesTester;
import java.util.Map;

public class NewPlatosTester extends NewIngredientesTester {

	public static void main(String[] args) {
		NewPlatosTester tester = new NewPlatosTester();

		for (Plato plato : tester.newCrearPlatos().values()) {
			System.out.println("* " + plato);
		}
	}

	public Map<String, Plato> newCrearPlatos() {
		Map<String, Ingrediente> ing = this.newCrearIngrediente();
		Plato p1, p2;

		p1 = new Plato("Sushi");
		if (p1.addIngrediente(ing.get("Arroz"), 90)) {
			System.out.println("Ingrediente repetido");
		}
		if (p1.addIngrediente(ing.get("Arroz"), 90)) {
			System.out.println("Ingrediente repetido");
		}
		if (p1.addIngrediente(ing.get("Salmon"), 4)) {
			System.out.println("Ingrediente repetido");
		}
		if (p1.addIngrediente(ing.get("Salmon"), 4)) {
			System.out.println("Ingrediente repetido");
		}
		
		p2 = new Plato("Refresco de Sandía");
		if (p2.addIngrediente(ing.get("Agua"), 50)) {
			System.out.println("Ingrediente repetido");
		}
		if (p2.addIngrediente(ing.get("Agua"), 50)) {
			System.out.println("Ingrediente repetido");
		}
		if (p2.addIngrediente(ing.get("Sandía"), 1)) {
			System.out.println("Ingrediente repetido");
		}
		if (p2.addIngrediente(ing.get("Sandía"), 1)) {
			System.out.println("Ingrediente repetido");
		}
		

		return Map.of("Sushi", p1, "Refresco de Sandía", p2);
	}


}
