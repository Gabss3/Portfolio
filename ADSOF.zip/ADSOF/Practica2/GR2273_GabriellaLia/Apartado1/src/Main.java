import java.util.List;
/**
* Esta aplicación muestra fuentes en diferentes estilos por pantalla
*
* @author Gabriella Leano y Lía Lazaro
*
*/

public class Main {
/**
* Punto de entrada a la aplicación.
* Este método imprime fuentes en dos formatos diferentes: APA y IEEE"
*
* @param args Los argumentos de la línea de comando
*/

    public static void main(String[] args) {
        Article Kaczorek2016 = new Article(List.of(new Author("Tadeusz", "Kaczorek")), 2016, 
                                        "Minimum energy control of fractional positive electrical circuits", 
                                            "Archives of Electrical Engineering", 65, 2); 
        
        Article Uchiyama2014 = new Article(List.of(new Author("Satoru", "Uchiyama"), new Author("Atsuto", "Kubo"),
                                            new Author("Hironori", "Washizaki"), new Author("Yoshiaki", "Fukazawa")), 2014, 
                                            "Detecting Design Patterns in Object-Oriented Program Source Code "+
                                            "by Using Metrics and Machine Learning", "Journal of Software Engineering and Applications", 7, 12); 
        
        List<Article> references = List.of(Kaczorek2016, Uchiyama2014);

        List<ArticleFormatter> formatters = List.of( new APAArticleFormatter(), new IEEEArticleFormatter()); 
        
        for (ArticleFormatter formatter : formatters) {
            System.out.println("Articles in "+formatter.getName()+" format:");
            System.out.println(formatter.format(references));
        }
    }
}