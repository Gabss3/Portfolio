import java.util.List;
/**
* Esta aplicación muestra fuentes en diferentes estilos por pantalla
*
* @author Gabriella Leano y Lía Lazaro
*
*/
public class IEEEArticleFormatter extends ArticleFormatter{
    public IEEEArticleFormatter(){super("IEEE");}
    /**
    * Punto de entrada a la aplicación.
    * Este método imprime fuentes en formato IEEE"
    *
    * @param args Los argumentos de la línea de comando
    */

    @Override public String formatAuthorsList(List<Author> authors){
        StringBuffer sb = new StringBuffer();
        for(Author a : authors){
            sb.append((sb.length()>0? ", " : ""));
            sb.append(a.getInitial() + ". "+ a.getLastName());
        }
        return sb.toString();
    }

    @Override public String formatReference(Article a) {
        return formatAuthorsList(a.getAuthors()) + ", \"" + a.getTitle() + "\"" + ", " + a.getJournal() + ", vol. " + a.getVolume() + ", no. " + a.getIssue() + ", "+ a.getYear() +".";
    }
}