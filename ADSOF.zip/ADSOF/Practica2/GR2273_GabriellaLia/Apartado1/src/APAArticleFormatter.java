import java.util.List;
/**
* Esta aplicación muestra fuentes en diferentes estilos por pantalla
*
* @author Gabriella Leano y Lía Lazaro
*
*/
public class APAArticleFormatter extends ArticleFormatter {
    public APAArticleFormatter() { super("APA"); }
    /**
    * Punto de entrada a la aplicación.
    * Este método imprime fuentes en formato APA"
    *
    * @param args Los argumentos de la línea de comando
    */
    
    @Override public String formatAuthorsList(List<Author> authors) {
        StringBuffer sb = new StringBuffer();
        for (Author a : authors) {
            sb.append((sb.length()>0)? ", " : "");
            sb.append(a.getLastName() + ", " + a.getInitial() + ".");
        }
        return sb.toString();
    }
    
    @Override public String formatReference(Article a) {
        return formatAuthorsList(a.getAuthors()) + " " + "(" + a.getYear() + "). " + a.getTitle() + ". " + a.getJournal() +
                                 ", " + a.getVolume() + "(" + a.getIssue() + ").";
    }
}
    