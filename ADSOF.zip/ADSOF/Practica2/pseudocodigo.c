float get_adeudo_menusal(Lector *lector){

    float precio_plan, descuento_plan, descuento_puntos, precio_a_descontar, adeudo;

    precio_plan = get_precio_plan(lector.plan);
    descuento_plan = get_descuento_plan(lector.plan);
    descuento_puntos = get_descuento_puntos(lector.puntos);

    for(saga in lector.saga){
        adeudo+= get_precio_saga(saga);
    }

    for(libro in lector.libro){
        adeudo+= get_precio_libro(libro);
    }

    for(acto in lector.acto){
        adeudo+= get_precio_acto(acto);
    }

    precio_a_descontar = (adeudo*descuento_plan)/100 + (adeudo*descuento_puntos)/100

    adeudo = adeudo - precio_a_descontar;

    
    return adeudo;
}