
import java.text.DecimalFormat;
import java.util.*;

/**
 * Clase que representa un menú.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class Menu {
	private static int siguienteId = 1;

	private int id;
	private List<Plato> platos = new ArrayList<>();
	private InfoNutricional info;
	private List<Alergeno> alergenos = new ArrayList<>();

	/**
     * Constructor de la clase Menu.
     * @param plato Lista de platos que forman parte del menú.
     */
	public Menu(Plato... plato){
		double calorias = 0;
		double hidratosCarbono = 0;
		double grasaTotal = 0;
		double grasaSaturada = 0;
		double proteinas = 0;
		double azucares = 0;
		double fibra = 0;
		double sodio = 0;
		InfoNutricional info;
		List<Alergeno> a1 = new ArrayList<>();

		this.id = getSiguienteMenuId();
		this.platos.addAll(Arrays.asList(plato));

		for (Plato pla : this.platos) {
			info = pla.getInfo();
			calorias += info.getCalorias();
			hidratosCarbono += info.getHidratosCarbono();
			grasaTotal += info.getGrasaTotal();
			grasaSaturada += info.getGrasaSaturada();
			proteinas += info.getProteinas();
			azucares += info.getAzucares();
			fibra += info.getFibra();
			sodio += info.getSodio();

			a1 = pla.getAlergenos();

			if (!a1.isEmpty()) {
				for (Alergeno ale : a1) {
					if (!alergenos.contains(ale)) {
						alergenos.add(ale);
					}
				}
			}
		}

		this.info = new InfoNutricional(calorias, hidratosCarbono, grasaTotal, grasaSaturada, proteinas, azucares,
				fibra, sodio);

	}

	/**
     * Método para añadir un plato al menú.
     * @param p Plato a añadir.
     */
	public void addPlato(Plato p) {
		InfoNutricional informacion;
		List<Alergeno> a1 = new ArrayList<>();

		platos.add(p);

		informacion = p.getInfo();
		
		info.SumCalorias(informacion.getCalorias());
		info.SumHidratosCarbono(informacion.getHidratosCarbono());
		info.sumGrasaTotal(informacion.getGrasaTotal());
		info.SumGrasaSaturada(informacion.getGrasaSaturada());
		info.SumProteinas(informacion.getProteinas());
		info.SumAzucares(informacion.getAzucares());
		info.SumFibra(informacion.getFibra());
		info.SumSodio(informacion.getSodio());

		a1 = p.getAlergenos();

		if (!a1.isEmpty()) {
			for (Alergeno ale : a1) {
				if (!alergenos.contains(ale)) {
					alergenos.add(ale);
				}
			}
		}
	}

	/**
     * Método privado para obtener el siguiente ID del menú.
     * @return Siguiente ID del menú.
     */
	private static int getSiguienteMenuId() {
		return siguienteId++;
	}
	
	/**
     * Método para obtener la lista de platos del menú.
     * @return Lista de platos del menú.
     */
	public List<Plato> getPlatos(){
		return this.platos;
	}

	/**
     * Método que devuelve una representación en forma de cadena del menú.
     * @return Representación en forma de cadena del menú.
     */
    @Override
	public String toString() {
		String resultado = "";
		DecimalFormat formato = new DecimalFormat("#.##");

		resultado += " Menu " + this.id + "[";

		for (Plato plato : this.platos) {
			resultado += plato.getNombre() + ", ";
		}

		resultado = resultado.substring(0, (resultado.length() - 2));
		resultado += "]: INFORMACION NUTRICIONAL DEL MENU -> ";

		resultado += "Valor energetico: " + formato.format(this.info.getCalorias()) + " kcal, "
				+ "Hidratos de carbono: " + formato.format(this.info.getHidratosCarbono()) + " g, " + "Grasas: "
				+ formato.format(this.info.getGrasaTotal()) + " g, " + "Saturadas: "
				+ formato.format(this.info.getGrasaSaturada()) + " g, " + "Proteinas: "
				+ formato.format(this.info.getProteinas()) + " g, " + "Azucares: "
				+ formato.format(this.info.getAzucares()) + " g, " + "Fibra: " + formato.format(this.info.getFibra())
				+ " g, " + "Sodio: " + formato.format(this.info.getSodio()) + " mg.";

		if (!this.alergenos.isEmpty()) {
			resultado += " CONTIENE: ";

			for (Alergeno a : this.alergenos) {
				resultado += a.getNombre(a) + ", ";
			}

			resultado = resultado.substring(0, (resultado.length() - 2));
		}

		return resultado;
	}

}