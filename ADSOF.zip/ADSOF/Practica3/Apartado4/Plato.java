
import java.text.DecimalFormat;
import java.util.*;

/**
 * Clase que representa un plato.
 * Contiene información sobre los ingredientes, la información nutricional y los alérgenos del plato.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class Plato {
	private String nombre;
	private Map<Ingrediente, Double> ingredientes = new HashMap<>();
	private List<Plato> plato = new ArrayList<>();
	private InfoNutricional informacion = new InfoNutricional(0, 0, 0, 0, 0, 0, 0, 0);
	private List<Alergeno> alergenos = new ArrayList<>();

	/**
     * Constructor de la clase Plato.
     * @param n Nombre del plato.
     */
	Plato(String n) {
		nombre = n;
	}

	/**
     * Método para agregar un ingrediente al plato.
     * @param ing Ingrediente a agregar.
     * @param cantidad Cantidad del ingrediente.
     * @return true si se agregó el ingrediente correctamente, false si ya estaba presente.
     */
	public Boolean addIngrediente(Ingrediente ing, double cantidad) {

		InfoNutricional info;
		int cant;
		List<Alergeno> a1 = new ArrayList<>();

		if (this.ingredientes.containsKey(ing)) {
			return false;
		}

		info = ing.getInfo();

		cant = info.getCantidad();

		cantidad = cantidad / cant;

		this.ingredientes.put(ing, cantidad);

		informacion.SumCalorias((info.getCalorias() * cantidad));
		informacion.SumHidratosCarbono(info.getHidratosCarbono() * cantidad);
		informacion.sumGrasaTotal(info.getGrasaTotal() * cantidad);
		informacion.SumGrasaSaturada(info.getGrasaSaturada() * cantidad);
		informacion.SumProteinas(info.getProteinas() * cantidad);
		informacion.SumAzucares(info.getAzucares() * cantidad);
		informacion.SumFibra(info.getFibra() * cantidad);
		informacion.SumSodio(info.getSodio() * cantidad);

		a1 = ing.getAlergenos();

		if (!a1.isEmpty()) {
			for (Alergeno ale : a1) {
				if (!alergenos.contains(ale)) {
					alergenos.add(ale);
				}
			}
		}

		return true;
	}

	/**
     * Método para agregar un plato al plato actual.
     * @param p Plato a agregar.
     */
	public void addPlato(Plato p) {
		InfoNutricional info;
		List<Alergeno> a1 = new ArrayList<>();

		plato.add(p);

		info = p.getInfo();
		informacion.SumCalorias(info.getCalorias());
		informacion.SumHidratosCarbono(info.getHidratosCarbono());
		informacion.sumGrasaTotal(info.getGrasaTotal());
		informacion.SumGrasaSaturada(info.getGrasaSaturada());
		informacion.SumProteinas(info.getProteinas());
		informacion.SumAzucares(info.getAzucares());
		informacion.SumFibra(info.getFibra());
		informacion.SumSodio(info.getSodio());

		a1 = p.getAlergenos();

		if (!a1.isEmpty()) {
			for (Alergeno ale : a1) {
				if (!alergenos.contains(ale)) {
					alergenos.add(ale);
				}
			}
		}
	}

	/**
     * Método para obtener los alérgenos del plato.
     * @return Lista de alérgenos del plato.
     */
	public List<Alergeno> getAlergenos() {
		return this.alergenos;
	}

	/**
     * Método para obtener la información nutricional del plato.
     * @return Información nutricional del plato.
     */
	public InfoNutricional getInfo() {
		return this.informacion;
	}

	/**
     * Método para obtener el nombre del plato.
     * @return Nombre del plato.
     */
	public String getNombre() {
		return this.nombre;
	}
	
	/**
     * Método para obtener los ingredientes y sus cantidades del plato.
     * @return Mapa de ingredientes y sus cantidades.
     */
	public Map<Ingrediente, Double> getIngredientesCant(){
		return this.ingredientes;
	}

	/**
     * Método para obtener los ingredientes y sus cantidades del plato.
     * @return Mapa de ingredientes y sus cantidades.
     */
	public List<Plato> getPlatos(){
		return this.plato;
	}

	/**
     * Método toString que representa la información del plato.
     * @return Representación en forma de cadena del plato.
     */
	@Override
	public String toString() {
		String resultado = new String();

		DecimalFormat formato = new DecimalFormat("#.##");

		resultado += "[Plato] " + this.nombre + ": INFORMACION NUTRICIONAL DEL PLATO ->";

		resultado += "Valor energetico: " + formato.format(informacion.getCalorias()) + " kcal, "
				+ "Hidratos de carbono: " + formato.format(informacion.getHidratosCarbono()) + " g, " + "Grasas: "
				+ formato.format(informacion.getGrasaTotal()) + " g, " + "Saturadas: "
				+ formato.format(informacion.getGrasaSaturada()) + " g, " + "Proteinas: "
				+ formato.format(informacion.getProteinas()) + " g, " + "Azucares: "
				+ formato.format(informacion.getAzucares()) + " g, " + "Fibra: "
				+ formato.format(informacion.getFibra()) + " g, " + "Sodio: " + formato.format(informacion.getSodio())
				+ " mg.";

		if (!this.alergenos.isEmpty()) {
			resultado += " CONTIENE: ";

			for (Alergeno a : this.alergenos) {
				resultado += a.getNombre(a) + ", ";
			}

			resultado = resultado.substring(0, (resultado.length() - 2));
		}

		return resultado;
	}
}