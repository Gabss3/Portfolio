
/**
 * Enumeración que representa los diferentes tipos de alérgenos.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public enum Alergeno {
	GLUTEN("gluten"), LACTOSA("lactosa"), HUEVO("huevo"), FRUTOS_SECOS("frutos_secos");

	private final String nombre;

	Alergeno(String n) {
		nombre = n;
	}

	/**
     * Obtiene el nombre del alérgeno.
     * @param tipo Tipo de alérgeno.
     * @return Nombre del alérgeno.
     */
	public String getNombre(Alergeno tipo) {
		return this.nombre;
	}
}