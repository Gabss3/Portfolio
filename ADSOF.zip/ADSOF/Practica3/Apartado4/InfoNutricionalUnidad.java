/**
 * Clase que representa la información nutricional por unidad.
 * Extiende la clase InfoNutricional.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class InfoNutricionalUnidad extends InfoNutricional {
	/**
     * Constructor de la clase InfoNutricionalUnidad.
     * @param calorias Calorías por unidad.
     * @param hidratosCarbono Hidratos de carbono por unidad.
     * @param grasaTotal Grasa total por unidad.
     * @param grasaSaturada Grasa saturada por unidad.
     * @param proteinas Proteínas por unidad.
     * @param azucares Azúcares por unidad.
     * @param fibra Fibra por unidad.
     * @param sodio Sodio por unidad.
     */
	public InfoNutricionalUnidad(double calorias, double hidratosCarbono, double grasaTotal, double grasaSaturada,
			double proteinas, double azucares, double fibra, double sodio) {
		super(calorias, hidratosCarbono, grasaTotal, grasaSaturada, proteinas, azucares, fibra, sodio);
		super.setCantidad(1);
	}

	@Override
	public String toString() {
		return "INFORMACION NUTRICIONAL POR UNIDAD -> " + super.toString();
	}
}