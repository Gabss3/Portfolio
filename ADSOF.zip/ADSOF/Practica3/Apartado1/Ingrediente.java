import java.util.*;

public class Ingrediente{

    /**
    * Clase que representa un ingrediente.
    * Autores: Lia Lazaro y Gabriella Leano
    */
    private String nombre;
    private String tipoIngrediente;
    private InfoNutricional info;
    private List<Alergeno> alergenos =new ArrayList<>();

    /**
     * Constructor de la clase Ingrediente para tipos de ingrediente enumerados.
     * @param nombre Nombre del ingrediente.
     * @param tipoIngrediente Tipo de ingrediente.
     * @param info Información nutricional del ingrediente.
     */
    public Ingrediente(String nombre, TipoIngrediente tipoIngrediente, InfoNutricional info){
        this.nombre = nombre;
        this.tipoIngrediente = tipoIngrediente.getNombre(tipoIngrediente);
        this.info = info;
    }

     /**
     * Constructor de la clase Ingrediente para tipos de ingrediente en forma de cadena.
     * @param nombre Nombre del ingrediente.
     * @param tipoIngrediente Tipo de ingrediente en forma de cadena.
     * @param info Información nutricional del ingrediente.
     */
    public Ingrediente(String nombre, String tipoIngrediente, InfoNutricional info) {
        this.nombre = nombre;
        this.tipoIngrediente = tipoIngrediente;
        this.info = info;
    }
    
    /**
     * Método para agregar alérgenos al ingrediente.
     * @param alergenos Lista de alérgenos.
     * @return El mismo objeto Ingrediente con los alérgenos agregados.
     */
    public Ingrediente tieneAlergenos(Alergeno... alergenos){
        this.alergenos.addAll(Arrays.asList(alergenos));

        return this;
    }

    /**
     * Método que devuelve una representación en forma de cadena del ingrediente.
     * @return Representación en forma de cadena del ingrediente.
     */
    public String toString(){
        String result = "";
        result = String.format("["+ this.tipoIngrediente+ "] "+ this.nombre +": " +info); 
        if(!alergenos.isEmpty()){
            result += " CONTIENE: ";
            
            for(Alergeno a: this.alergenos){
                
                result+= a.getNombre(a) + ", ";
            }

           result = result.substring(0, (result.length()-2));
        }

        return result;
    }
}