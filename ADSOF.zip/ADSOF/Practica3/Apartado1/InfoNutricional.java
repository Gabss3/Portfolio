/**
 * Clase que representa la información nutricional de un alimento.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public abstract class InfoNutricional{
    private double calorias;
    private double hidratosCarbono;
    private double grasaTotal;
    private double grasaSaturada;
    private double proteinas;
    private double azucares;
    private double fibra;
    private double sodio;

    /**
     * Constructor de la clase InfoNutricional.
     * @param calorias          Cantidad de calorías.
     * @param hidratosCarbono   Cantidad de hidratos de carbono.
     * @param grasaTotal        Cantidad de grasa total.
     * @param grasaSaturada     Cantidad de grasa saturada.
     * @param proteinas         Cantidad de proteínas.
     * @param azucares          Cantidad de azúcares.
     * @param fibra             Cantidad de fibra.
     * @param sodio             Cantidad de sodio.
     */
    public InfoNutricional (double calorias, double hidratosCarbono, double grasaTotal, double grasaSaturada,double proteinas, double azucares, double fibra, double sodio){
        this.calorias = calorias;
        this.hidratosCarbono = hidratosCarbono;
        this.grasaTotal = grasaTotal;
        this.grasaSaturada = grasaSaturada;
        this.proteinas = proteinas;
        this.azucares = azucares;
        this.fibra = fibra;
        this.sodio = sodio;
    }

    /**
     * Representación en cadena de caracteres de la información nutricional.
     * @return Cadena de caracteres representando la información nutricional.
     */
    @Override
    public String toString(){
        return String.format("Valor energetico: " + calorias + " kcal, Hidratos de carbono: " + hidratosCarbono +" g, Grasas: " + grasaTotal + "g, Saturadas: " + grasaSaturada + " g, Proteinas: " + proteinas +" g, Azucares: "+ azucares +" g, Fibra: "+ fibra +" g, Sodio: "+ sodio + " mg.");
    }
}