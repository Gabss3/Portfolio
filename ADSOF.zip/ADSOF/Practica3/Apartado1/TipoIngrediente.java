
/**
 * Enumeración que representa los tipos de ingredientes.
 * Cada tipo de ingrediente tiene un nombre asociado.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public enum TipoIngrediente {
	CARNE("Carne"), PESCADO("Pescado"), FRUTA_VERDURA("Fruta/Verdura"), LEGUMBRE("Legumbre"), CEREAL("Cereal"),
	HUEVO("Huevo"), LACTEO("Lacteo"), SODIO("Sodio");

	private final String nombre;

	/**
     * Constructor de la enumeración TipoIngrediente.
     * @param n Nombre del tipo de ingrediente.
     */
	TipoIngrediente(String n) {
		nombre = n;
	}

	/**
     * Método para obtener el nombre del tipo de ingrediente.
     * @param tipo Tipo de ingrediente del cual se desea obtener el nombre.
     * @return Nombre del tipo de ingrediente.
     */
	public String getNombre(TipoIngrediente tipo) {
		return this.nombre;
	}
}