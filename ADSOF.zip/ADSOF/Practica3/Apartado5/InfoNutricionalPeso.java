
/**
 * Clase que representa la información nutricional por peso.
 * Extiende la clase InfoNutricional.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class InfoNutricionalPeso extends InfoNutricional{
    
    /**
     * Constructor de la clase InfoNutricionalPeso.
     * @param calorias Calorías por 100g.
     * @param hidratosCarbono Hidratos de carbono por 100g.
     * @param grasaTotal Grasa total por 100g.
     * @param grasaSaturada Grasa saturada por 100g.
     * @param proteinas Proteínas por 100g.
     * @param azucares Azúcares por 100g.
     * @param fibra Fibra por 100g.
     * @param sodio Sodio por 100g.
     */
    public InfoNutricionalPeso(double calorias, double hidratosCarbono, double grasaTotal, double grasaSaturada, double proteinas, double azucares, double fibra, double sodio) {
        super(calorias, hidratosCarbono, grasaTotal, grasaSaturada, proteinas, azucares, fibra, sodio);
        super.setCantidad(100);
    }
    
 
    @Override
    public String toString() {
    return "INFORMACION NUTRICIONAL POR 100g -> " + super.toString();
    }
}