
/**
 * Enumeración que representa los diferentes elementos nutricionales.
 * Autores: Lia Lazaro, Gabriella Leano
 */
public enum ElementoNutricional { 
	CALORIAS("calorias"), HIDRATOSCARBONO("hidratosCarbono"),
	GRASA_TOTAL("grasaTotal"),
	GRASA_SATURADA("grasaSaturada"),
	PROTEINAS("proteinas"),
	AZUCARES("azucares"),
	FIBRA("fibra"),
	SODIO("sodio");
	
	/**
     * Constructor de la enumeración.
     * @param n Nombre del elemento nutricional.
     */
	private final String nombre;
	ElementoNutricional(String n) {
		nombre = n;
	}

	/**
     * Método para obtener el nombre del elemento nutricional.
     * @param tipo Tipo de elemento nutricional.
     * @return Nombre del elemento nutricional.
     */
	public String getNombre(ElementoNutricional tipo) {
		return this.nombre;
	}
}
