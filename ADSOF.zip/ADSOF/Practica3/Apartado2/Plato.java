
import java.text.DecimalFormat;
import java.util.*;
import java.util.Map.Entry;

/**
 * Clase que representa un plato.
 * Contiene información sobre los ingredientes, la información nutricional y los alérgenos del plato.
 * Autores: Lia Lazaro y Gabriella Leano
 */
public class Plato{
    private String nombre;
    private Map<Ingrediente, Double> ingredientes = new HashMap<>(); 
    private List<Plato> plato = new ArrayList<>();

    /**
     * Constructor de la clase Plato.
     * @param n Nombre del plato.
     */
    Plato(String n){
        nombre=n;
    }

    /**
     * Método para agregar un ingrediente al plato.
     * @param ing Ingrediente a agregar.
     * @param cantidad Cantidad del ingrediente.
     * @return true si se agregó el ingrediente correctamente, false si ya estaba presente.
     */
    public Boolean addIngrediente(Ingrediente ing, double cantidad){

        InfoNutricional info;
        int cant;   
        
        if(this.ingredientes.containsKey(ing)){
            return false;
        }

        info = ing.getInfo();

        cant = info.getCantidad();

        cantidad = cantidad/cant;

        this.ingredientes.put(ing, cantidad);
        return true;
    }

    /**
     * Método para agregar un plato al plato actual.
     * @param p Plato a agregar.
     */
    public void addPlato(Plato p){
         plato.add(p);
    }
    
    /**
     * Método toString que representa la información del plato.
     * @return Representación en forma de cadena del plato.
     */
    public String toString(){
        String resultado = new String();
        Ingrediente ing;
        double cantidad=0;
        InfoNutricional info;
        List<Alergeno> a1 = new ArrayList<>();
        List<Alergeno> a2 = new ArrayList<>();
        double calorias=0;
        double hidratosCarbono=0;
        double grasaTotal=0;
        double grasaSaturada=0;
        double proteinas=0;
        double azucares=0;
        double fibra = 0;
        double sodio=0;

        if(!this.plato.isEmpty()){
            for(Plato plato : this.plato){

                for (Entry<Ingrediente, Double> entrada : plato.ingredientes.entrySet()) {
                    ing = entrada.getKey();
                    cantidad = entrada.getValue();
        
                    info = ing.getInfo();
             
                    calorias+= (info.getCalorias()*cantidad);
                    hidratosCarbono+= (info.getHidratosCarbono()*cantidad);
                    grasaTotal+= (info.getGrasaTotal()*cantidad);
                    grasaSaturada+= (info.getGrasaSaturada()*cantidad);
                    proteinas+= (info.getProteinas()*cantidad);
                    azucares+= (info.getAzucares()*cantidad);
                    fibra+= (info.getFibra()*cantidad);
                    sodio+= (info.getSodio()*cantidad);
                    
                    
                    a1 = ing.getAlergenos();
        
                    if(!a1.isEmpty()){
                        for(Alergeno ale : a1){
                            if(!a2.contains(ale)){
                                a2.add(ale);
                            }
                        }
                    }
                }     

            }

        }

            for (Entry<Ingrediente, Double> entrada : ingredientes.entrySet()) {
                ing = entrada.getKey();
                cantidad = entrada.getValue();

                info = ing.getInfo();
        
                calorias+= (info.getCalorias()*cantidad);
                hidratosCarbono+= (info.getHidratosCarbono()*cantidad);
                grasaTotal+= (info.getGrasaTotal()*cantidad);
                grasaSaturada+= (info.getGrasaSaturada()*cantidad);
                proteinas+= (info.getProteinas()*cantidad);
                azucares+= (info.getAzucares()*cantidad);
                fibra+= (info.getFibra()*cantidad);
                sodio+= (info.getSodio()*cantidad);
                
                
                a1 = ing.getAlergenos();

                if(!a1.isEmpty()){
                    for(Alergeno ale : a1){
                        if(!a2.contains(ale)){
                            a2.add(ale);
                        }
                    }
                }
            }
        
        
        DecimalFormat formato = new DecimalFormat("#.##");

        resultado+= "[Plato] " + this.nombre + ": INFORMACION NUTRICIONAL DEL PLATO ->";

        resultado+= "Valor energetico: " + formato.format(calorias) + " kcal, " +"Hidratos de carbono: " + formato.format(hidratosCarbono) + " g, " +"Grasas: " + formato.format(grasaTotal) + " g, " +"Saturadas: " + formato.format(grasaSaturada) + " g, " +"Proteinas: " + formato.format(proteinas) + " g, " + "Azucares: " + formato.format(azucares) + " g, " +"Fibra: " + formato.format(fibra) + " g, " +"Sodio: " + formato.format(sodio) + " mg.";
        
        if(!a2.isEmpty()){
            resultado += " CONTIENE: ";
            
            for(Alergeno a: a2){
                
                resultado+= a.getNombre(a) + ", ";
            }

           resultado = resultado.substring(0, (resultado.length()-2));
        }

        return resultado;
        }
}