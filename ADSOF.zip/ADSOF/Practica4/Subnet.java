import java.util.*;

public class Subnet {
	private static int siguienteId=0;
    private int id;
    private ArrayList<AbstractNode> nodos = new ArrayList<>();

    public Subnet(AbstractNode ... nodos) {
        this.id = getSiguienteId();
        this.nodos.addAll(Arrays.asList(nodos));
    }

    public int getId() {
        return id;
    }

    private static int getSiguienteId() {
        return siguienteId++;
    }

    public ArrayList<AbstractNode> getNodos() {
        return nodos;
    }

    public void agregarNodo(AbstractNode nodo) {
        nodos.add(nodo);
    }
    
    @Override
    public String toString() {
    	String resultado ="";
    	resultado += "Node network of "+ this.nodos.size()+ " nodes:";
    	for(AbstractNode n : this.nodos) {
    		if(n instanceof Node) {
    			resultado += "[ "+ ((Node)n).toString() +" ] ";
    		}
    		else {
    			resultado += "[ "+ ((MiningNode)n).toString()+ " ] ";
    		}
    	}
        return resultado;
    }
}
