import java.util.*;

public class BlockchainNetwork{
	private String nombre;
    private ArrayList<AbstractNode> nodos;
    private ArrayList<Subnet> subredes;

    public BlockchainNetwork(String nombre){
        this.nombre = nombre;
        this.nodos = new ArrayList<>();
        this.subredes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<AbstractNode> getNodos() {
        return nodos;
    }

    public ArrayList<Subnet> getSubredes() {
        return subredes;
    }

    public void connect(AbstractNode nodo) {
        nodos.add(nodo);
    }

    public void connect(Subnet subred) {
        subredes.add(subred);
    }
    
    public String toString(){
    	int contador=0;
    	String resultado = "";
    	
    	for(AbstractNode n : this.nodos) {
    		resultado+= this.nombre + " - new peer connected:";
    		if(n instanceof Node) {
    			resultado+= ((Node)n).toString() + "\n";
    		}
    		else {
    			resultado+= ((MiningNode)n).toString() + "\n";
    		}
    		contador++;
    	}
    	
    	for(Subnet s : this.subredes) {
    		resultado+= this.nombre + " - new peer connected:";
    		resultado+= s.toString() +"\n";
    		contador++;
    	}
    	
    	resultado+= this.nombre +" consists of "+ contador + " elements: \n";
    	
		for(AbstractNode n : this.nodos) {
    		
			if(n instanceof Node) {
    			resultado+= "* " + ((Node)n).toString() + "\n";
    		}
    		else {
    			resultado+= "* " + ((MiningNode)n).toString() + "\n";
    		}
    	}
    	
    	for(Subnet s : this.subredes) {
    		resultado+= "* " + s.toString() +"\n";
    	}
        
        return resultado;
    }
}