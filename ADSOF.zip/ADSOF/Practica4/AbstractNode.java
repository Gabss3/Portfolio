import java.util.*;

public abstract class AbstractNode {
	private static int siguienteId=000;
	private int id;
    private Wallet wallet;
    private ArrayList<Transaction> transacciones = new ArrayList<>();
    
    public AbstractNode(Wallet wallet) {
    	this.wallet = wallet;
    	this.id = getSiguienteId();
    }
    
    public Wallet getWallet() {
        return wallet;
    }

    public int getId(){
        return this.id;
    }

    public String getFormatedId(){
        return String.format("%03d", getId());
    }

    public List<Transaction> getTransacciones() {
        return transacciones;
    }

    public static int getSiguienteId() {
        return siguienteId++;
    }

    // Método para agregar una transacción al nodo
    public void agregarTransaccion(Transaction transaccion) {
        transacciones.add(transaccion);
    }

    public String toString(){
        String resultado = "";
        resultado = this.wallet.toString();
    	return resultado;
    }
}
