public class BlockConfig {
	public static String GENESIS_BLOCK = "0000000000000000000000000000000000000000000000000000000000000000";
	public static int DIFFICULTY = 1;
	public static int VERSION = 1;
}