import java.util.*;

public class Wallet{
	private String nombre;
	private String clave;
	private int balance;
	
	public Wallet(String nombre, String clave, int balance) {
		this.nombre = nombre;
		this.clave = clave;
		this.balance = balance;
	}	
	
	public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
    	String resultado ="";
    	resultado = "u: " + nombre + ", PK:" + clave + ", balance: " +balance+ " | ";
        return resultado;
    }   	
}
