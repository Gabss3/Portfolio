import java.util.*;

public class Transaction {
	String id;
	Wallet emisor;
	Wallet receptor;
	int valor;
	
	public Transaction(Wallet emisor, Wallet receptor, int valor)/*throws SaldoInsuficiente*/ {
        this.emisor = emisor;
        this.receptor = receptor;
        this.valor = valor;
        
        /*if(valor> emisor.getBalance()) {
        	new SaldoInsuficiente(emisor.getNombre(), emisor.getBalance());
        }*/
        
        receptor.setBalance(receptor.getBalance()+valor);
        emisor.setBalance(emisor.getBalance()-valor); 
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}

