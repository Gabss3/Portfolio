import java.util.*;

public class Node extends AbstractNode {
    
    public Node(Wallet wallet) {
    	super(wallet);
    }
    
    public String fullName() {
    	String resultado = "";
    	resultado = "@Node#"+ getFormatedId();
    	return resultado;
    }


    public String toString(){
        String resultado = "";
        resultado = super.toString();
        resultado += this.fullName();
        return resultado;
    }


}
