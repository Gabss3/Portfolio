import java.util.*;

public class MiningNode extends AbstractNode{
    private int potenciaComputacional; 

    public MiningNode(Wallet wallet, int potencia) {
    	super(wallet);
    	this.potenciaComputacional=potencia;
    }
    
    public String fullName() {
    	String resultado = "";
    	resultado = " @MiningNode#"+ getFormatedId();
    	return resultado;
    }
    
    public int getPotenciaComputacional() {
        return potenciaComputacional;
    }
    
    public void setPotenciaComputacional(int potencia) {
        this.potenciaComputacional = potencia;
    }

    public String toString(){
    	String resultado = "";
        resultado = super.toString();
        resultado += this.fullName();
        return resultado; 
    }
}
