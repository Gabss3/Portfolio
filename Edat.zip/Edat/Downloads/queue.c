#include <string.h>
#include <stdlib.h>
#include "queue.h"

#define MAX_QUEUE 100
struct _Queue{
void *data[MAX_QUEUE];
void **front;
void **rear;
};

Queue *queue_new(){
  Queue *q;
  int i;

  q = (Queue*)malloc(sizeof(Queue));

  for(i=0; i<MAX_QUEUE;i++){
    q->data[i] = NULL;
  }

  q->front = &(q->data[0]);
  q->rear = &(q->data[0]);

  return q;
}

void queue_free(Queue *q){

  if(!q){
    return;
  }
  free(q);
}

Bool queue_isEmpty(const Queue *q){

  if(!q){
    return TRUE;
  }

  if(q->front == q->rear){
      return TRUE;
  }
  else
    return FALSE;
}

Status queue_push(Queue *q, void *ele){

  if(!q || !ele){
    return ERROR;
  }

  *(q->rear) = ele;
  q->rear=  q->data + (q->rear + 1 - q->data) % MAX_QUEUE ;

  return OK;
}

void *queue_pop(Queue *q){

  void *ele;
  
  if(!q){
    return NULL;
  }

  ele = *(q->front);
  
  *(q->front) = NULL;
  q->front= q->data + (q->front + 1 - q->data) % MAX_QUEUE ;

  return ele;
}

void *queue_getFront(const Queue *q){

  void *ele;
  
  if(!q){
    return NULL;
  }

  ele = *(q->front);
  
  return ele;
}

void *queue_getBack(const Queue *q){

  void **ele;
  
  if(!q){
    return NULL;
  }

  if (q->rear == q->data) {
    ele = ((Queue *)q)->data + MAX_QUEUE - 1;
  } 
  
  else {
    ele = q ->rear - 1;
  }

  return ele;
}

size_t queue_size(const Queue *q){

  size_t size=0;
  
  if(!q){
    return -1;
  }

  if(q->front < q->rear){
    size = q->rear - q->front;
  }

  if(q->front > q->rear){
    size = MAX_QUEUE - (q->front - q->rear);
  }

  if(q->front > q->rear){
    size = 0;
  }

  return size; 
}

int queue_print(FILE *fp, const Queue *q, p_queue_ele_print f){

  int i, total=0, aux=0;
  
  if(!fp || !q || !f){
    return -1;
  }
  
  for(i=0; i<MAX_QUEUE; i++){
    if(q->data[i]!=NULL){
      
      aux = f(fp, q->data[i]);
    
      total +=aux;
    }
  }
  
  return total;
}
