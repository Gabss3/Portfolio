#include <stdio.h>
#include "graph.h"
#include "queue.h"
#include "file_utils.h"

int main(int argc, char const *argv[])
{
  Graph *g;
  FILE *f;
  int *arg2, *arg3;

  if(argc!=4){
    fprintf(stdout, "Error, se esperaban 4 argumentos.");
    return ERROR;
  }
  
  g = graph_init();

  if(!g){
    return ERROR;
  }
  
  f = fopen(argv[1], "r");
  if(!f){
    graph_free(g);
    return ERROR;
    }

  arg2 = str2int(argv[2]);
  arg3 = str2int(argv[3]);

  
  graph_readFromFile(f, g);

  fprintf(stdout,"Input Graph:\n");
  graph_print(stdout, g);

  fprintf(stdout, "\n-----DFS-----\n");
  fprintf(stdout, "From vertex id: %d\n", *arg2);
  fprintf(stdout, "To vertex id: %d\n", *arg3);
  fprintf(stdout, "Output:\n");

  graph_depthSearch(g, (long)*arg2, (long) *arg3);

  graph_free(g);
  fclose(f);


  g = graph_init();
  
  if(!g){
    return ERROR;
  }
  
  f = fopen(argv[1], "r");
  if(!f){
    graph_free(g);
    return ERROR;
    }

 graph_readFromFile(f, g);

 fprintf(stdout, "\n-----BFS-----\n"); 
 fprintf(stdout, "From vertex id: %d\n", *arg2);
 fprintf(stdout, "To vertex id: %d\n", *arg3);
 fprintf(stdout, "Output:\n");
   
  graph_breathSearch(g, (long)*arg2, (long)*arg3);

  fclose(f);
  graph_free(g);
  return 0;
} 