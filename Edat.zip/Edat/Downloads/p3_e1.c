#include <stdio.h>
#include <string.h>
#include "delivery.h"
#include "queue.h"
#include "types.h"
#include "vertex.h"


Delivery *build_delivery(FILE *pf) {

  int tam, i;
  char str[128], aux[128], name[128], product[128];
  Vertex *v;
  Delivery *del;

  if (!pf) {
    return NULL;
  }

  if(fscanf(pf, "%s %s", name, product)!=2){
  
    return NULL;
  }

  if(fscanf(pf, "%d", &tam)!=1){
    return NULL;
  }
  
  del = delivery_init(name, product);

  for (i = 0; i < tam; i++) {

   if(fscanf(pf, "%s %s", str, aux)!=2){
     return NULL;
   }

    strcat(str, " ");
    strcat(str, aux);

    v = vertex_initFromString(str);

    queue_push(delivery_getPlan(del), v);
  }

  return del;
}

int main(int argc, char const *argv[]) {
  Delivery *del;
  FILE *pf;
  size_t tam;
  int i;
  
  if (argc != 2) {
    fprintf(stdout, "Error, se espera un argumento.");
    return -1;
  }
  pf = fopen(argv[1], "r");
  if (!pf) {
    return -1;
  }
  
  del = build_delivery(pf);
  
  if(!del){
    fclose(pf);
    return -1;
  }
  
  fclose(pf);
  
  tam = (int)queue_size(delivery_getPlan(del));

  for(i=0; i<tam; i++){

    if(delivery_add(stdout, del, queue_pop(delivery_getPlan(del)), vertex_print)==ERROR){ 
      delivery_free(del);
      return -1;
    }
  }
    
  if (delivery_run_plan(stdout, del, vertex_print, vertex_free) == ERROR) {
    delivery_free(del);
    return -1;
  }

  delivery_free(del);
  return 0;
}