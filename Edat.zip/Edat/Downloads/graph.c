#include <string.h>
#include <stdlib.h>
#include "queue.h"
#include "graph.h"
#include "stack.h"

#define GRAPH_H
#define MAX_VTX 4096
#define TAG_LENGTH 64


#define MAX_VTX 4096
struct _Graph {
Vertex *vertices[MAX_VTX];
Bool connections[MAX_VTX][MAX_VTX];
int num_vertices;
int num_edges;
};

Graph * graph_init(){
  
  Graph *g;

  g = (Graph*)malloc(sizeof(Graph));
  if(g == NULL){
    return NULL;
  }
  
  g->num_edges = 0;
  g->num_vertices = 0;

  return g;
}

void graph_free(Graph *g){
  int i;
  
  if(!g){
    return;
  }

  /*It frees one by one the vertex of the graph*/
  for(i=0; i< g->num_vertices; i++){
    vertex_free(g->vertices[i]);
  }

  free(g);
}

Status graph_newVertex(Graph *g, char *desc){
  
  Vertex *v1;

  if (g==NULL || desc == NULL){
    return ERROR;
  }
  
  v1 = vertex_initFromString(desc);

  
  if(graph_contains(g, vertex_getId (v1))==TRUE){
    return ERROR;
  }

  vertex_setIndex(v1, g->num_vertices);
  
  g->vertices[g->num_vertices] = v1;
  g->num_vertices++;
  

  return OK;  
}

Status graph_newEdge(Graph *g, long orig, long dest){

  int i, j;

  if(!g || orig<0 || dest<0){
    return ERROR;
  }

  i = graph_contains(g, orig);
  j = graph_contains(g, dest);

  if(i == ERROR || j == ERROR){
    return ERROR;
  }

  g->connections[orig][dest]=TRUE;
  
  g->num_edges++;
  
  return OK;
}

Bool graph_contains(const Graph *g, long id){

  int i;

  if(!g || id<0){
    return FALSE;
  }

  for(i=0; i< g->num_vertices; i++){
    if(vertex_getId(g->vertices[i]) == id){
      return TRUE;
    }
  }

  return FALSE;
}


int graph_getNumberOfVertices(const Graph *g){
  
  if(!g){
    return -1;
  }

  return g->num_vertices;
}

int graph_getNumberOfEdges(const Graph *g){
  
  if(!g){
    return -1;
  }

  return g->num_edges;
}

Bool graph_connectionExists(const Graph *g, long orig, long dest){
  
  if(!g || orig<0 || dest<0){
    return FALSE;
  }

  if(g->connections[orig][dest]==TRUE){
    return TRUE;
  }
  
  return FALSE;
}

int graph_getNumberOfConnectionsFromId(const Graph *g, long id){
  
  int i, j;
  int k=0;
  
  if(!g|| id<0){
    return -1;
  }
  
  for(i=0; i<g->num_vertices; i++){
    /*Calling the fuunction connectionExists, it checks if the vertex given by the id has any conections with the rest of the vertex of the graph. If it does, the variable k gorws and it shows the nomber of connections.*/
    j = graph_connectionExists(g,id, vertex_getId(g->vertices[i]));
    if(j == TRUE){
      k++;
    }
  }
  return k;
}
  
long *graph_getConnectionsFromId(const Graph *g, long id){

  int num, i, j, k=0;
  long *array;
  
  if(g == NULL || id<0){
    return NULL;
  }

  num = graph_getNumberOfConnectionsFromId(g,id);

  array = (long*)malloc(num*sizeof(long));
  if(!array){
    return NULL;
  }

   for(i=0; i<g->num_vertices; i++){

    j = graph_connectionExists(g,id, vertex_getId(g->vertices[i]));
    if(j == TRUE){
      /*When there is a connection it adds it to the array that has been created*/
      array[k] =  vertex_getId(g->vertices[i]);
      k++;
    }
  }
  
  return array;
}

int graph_getNumberOfConnectionsFromTag(const Graph *g, char *tag){

  int i;
  long id1=-1;
  int k=0;
  
  if(!g|| !tag){
    return -1;
  }

  /*It gets the id of the vertex from the tag given in the function. With that the rest of the function is almost the same as graph_getNumberOfConnectionsFromId */
  for(i=0;i<g->num_vertices;i++){
    if(strcmp(tag, vertex_getTag(g->vertices[i]))==0){
      id1 = vertex_getId(g->vertices[i]);
    }
  }
  /*It checks that the id has been stablished.*/
  if(id1==-1){
    return -1;
  }

  for(i=0; i<g->num_vertices; i++){
    
    if(graph_connectionExists(g,id1, vertex_getId(g->vertices[i])) == TRUE){
      k++;
    }
  }
  return k;
}


long *graph_getConnectionsFromTag(const Graph *g, char *tag) {

  int num, i, j, k=0; 
  long *array, id1=-1;
  
  if(g == NULL || !tag){
    return NULL;
  }

  /*It gets the id of the vertex from the tag given in the function. With that the rest of the function is almost the same as graph_getConnectionsFromId */
  for(i=0;i<g->num_vertices;i++){
    if(strcmp(tag, vertex_getTag(g->vertices[i]))==0){
      id1 = vertex_getId(g->vertices[i]);
    }
  }

  if(id1==-1){
    return NULL;
  }

  num = graph_getNumberOfConnectionsFromId(g,id1);

  array = (long*)malloc(num*sizeof(long));

  if(!array){
    return NULL;
  }

   for(i=0; i<g->num_vertices; i++){

    j = graph_connectionExists(g,id1,  vertex_getId(g->vertices[i]));
    if(j == TRUE){
      array[k] =  vertex_getId(g->vertices[i]);
      k++;
    }
  return array;
}
  return array;
}


int graph_print (FILE *pf, const Graph *g){
 
  int i=0, k=0, num=0, total=0;
  /*the variables num and total counts the number of characters printed*/

  if(!pf||!g){
    return -1;
  }

  for(i = 0; i<g->num_vertices; i++){
   
   num  = fprintf(pf, "[%ld, %s, %d, %d]:",  vertex_getId(g->vertices[i]), vertex_getTag(g->vertices[i]), vertex_getState(g->vertices[i]), vertex_getIndex(g->vertices[i]));


    total+=num;

    for(k= num = 0; k<g->num_vertices; k++){
      
      if( graph_connectionExists(g, vertex_getId(g->vertices[i]), vertex_getId(g->vertices[k])) == TRUE){
     
          num = fprintf(pf, "[%ld, %s, %d, %d]", vertex_getId(g->vertices[k]), vertex_getTag(g->vertices[k]), vertex_getState(g->vertices[k]), vertex_getIndex(g->vertices[k]));
      
          total+=num;
         }
      } 
    fprintf(pf, "\n");
    }
    
    return total;  
}

Status graph_readFromFile (FILE *fin, Graph *g){

  int i, control;
  char str[TAG_LENGTH], tag[TAG_LENGTH];
  long id1, id2;

  if(!fin || !g){
    return ERROR;
  }

  control = fscanf(fin, "%d", &g->num_vertices);

  /*If there isn't any vertex it returns error because the graph doesn't exist.*/
  if(!control){
    return ERROR;
  }

  for(i=control=0; i<g->num_vertices;i++){

    control = fscanf(fin, "%s %s", str, tag);

    if(!control){
    return ERROR;
    }  

    /*It uses the library function strcat to save in the variable scr all the information about all of the garph's vertex.*/

    strcat(str, " ");
    strcat(str, tag);

    g->vertices[i] = vertex_initFromString(str);

    vertex_setIndex(g->vertices[i], i);
     
  } 

    while(fscanf(fin, "%ld %ld", &id1, &id2) == 2) 
    
    graph_newEdge(g, id1, id2);
  
  
  return OK;
}

/* START [Private_functions] */
int _graph_findVertexByTag(const Graph *, char *tag);
Status _graph_insertEdgeFromIndices(Graph *g, const long origIx, const
long destIx);
int _graph_getNumConnections(const Graph *g, int ix);
long *_graph_getConnections(const Graph *g, int ix);
void _graph_setVertexState (Graph *g, Label l);
Vertex *graph_getVertex_fromIndex(Graph *g, int ix);
int graph_getVertexIndex_fromId(Graph *g, long id);

int _graph_findVertexbyTag(const Graph *g, char *tag){

  int i, index;

if(!g || !tag){
  return -1;
}

  for(i=0; i<g->num_vertices; i++){

    if(strcmp(vertex_getTag(g->vertices[i]), tag)==0){

      index = vertex_getIndex(g->vertices[i]);

      return index;
    }
  }
  return -1;
}


Status _graph_insertEdgeFromIndices(Graph *g, const long origIx, const long destIx){
  
  int i;
  long orig_id=0, dest_id=0;
  
  if(!g|| origIx<0||destIx<0){
    return ERROR;
  }

  for(i=0; i<g->num_vertices;i++){

    if( vertex_getIndex(g->vertices[i]) == origIx){

      orig_id= vertex_getId(g->vertices[i]);
      
    }
     if( vertex_getIndex(g->vertices[i]) == destIx){

      dest_id= vertex_getId(g->vertices[i]);
      
    }
  }

  g->connections[orig_id][dest_id]=TRUE;
  
  g->num_edges++;
  
  return OK;
}


int _graph_getNumConnections(const Graph *g, int ix){

  int i, num_conections=0;
  Bool aux;
  long id=0;

  if(!g || ix<0){
    return -1;
  }

  for(i=0; i<g->num_vertices; i++){

    if(vertex_getIndex(g->vertices[i]) == ix){

      id = vertex_getId(g->vertices[i]);
      
    }
  }
  
  for(i=0; i<g->num_vertices; i++){

    aux = graph_connectionExists(g, id, vertex_getId(g->vertices[i]));

    if(aux == TRUE){
      num_conections++;
    }  
  }

 return num_conections; 
}

long *_graph_getConnections(const Graph *g, int ix){
  int num, i, j, k=0;
  long *array, ix_id=0;
  
  if(!g|| ix<0){
    return NULL;
  }
  
  ix_id = vertex_getId(g->vertices[ix]);

  num = _graph_getNumConnections(g, ix);

  array = (long*)malloc(num*sizeof(long));

  if(!array){
    return NULL;
  }

   for(i=0; i<num; i++){

    j = graph_connectionExists(g,ix_id, vertex_getId(g->vertices[i]));
    if(j == TRUE){
      /*When there is a connection it adds it to the array that has been created*/
      array[k] = (long)vertex_getIndex(g->vertices[i]);
      k++;
    }
  }
  
  return array;
}

int graph_getVertexIndex_fromId(Graph *g, long id){

  int i, index=0;
  if(!g || id<0){
    return -1;
  }

  for(i=0; i< g->num_vertices; i++){

    if(vertex_getId(g->vertices[i]) == id){

      index = vertex_getIndex(g->vertices[i]);
    }
  }
 return index; 
}

Vertex *graph_getVertex_fromIndex(Graph *g, int ix){

  int i;
  
  if(!g || ix<0){
    return NULL;
  }

  for(i=0; i<g->num_vertices; i++){

    if(i == ix){
      return g->vertices[i];
    }
  }
return NULL; 
}


void _graph_setVertexState (Graph *g, Label l){
  int i; 
  
  if(!g|| l!=0|| l!=1){
    return;
  }

  for(i=0; i<g->num_vertices; i++){
    vertex_setState(g->vertices[i], l);
  }

  return;
}
/* END [Private_functions] */

Status graph_depthSearch (Graph *g, long from_id, long to_id){
  
  Stack *s;
  long *array_id, from_ix, to_ix;
  int num_connections, i, j;
  Vertex *v;

  if(!g || from_id<0 || to_id<0){
    return ERROR;
  }

  s = stack_init();
  if(!s){
    return ERROR;
  }

  from_ix = graph_getVertexIndex_fromId(g, from_id);
  to_ix = graph_getVertexIndex_fromId(g, to_id);

  stack_push(s, g->vertices[from_ix]);

  while(stack_isEmpty(s) == FALSE){

    v = stack_pop(s);

    if(vertex_cmp(v, g->vertices[to_ix])==0){
        vertex_setState(g->vertices[to_ix], BLACK);
        vertex_print(stdout, g->vertices[to_ix]);
        fprintf(stdout, "\n");
        free(s);
        return OK;
    }

    for(i=0; i< g->num_vertices; i++){

      if(vertex_cmp(v, g->vertices[i])==0){
        
        if(vertex_getState(g->vertices[i])==WHITE){
          vertex_setState(g->vertices[i], BLACK);
          vertex_print(stdout, g->vertices[i]);
          fprintf(stdout, "\n");
        }

        num_connections = graph_getNumberOfConnectionsFromId(g, vertex_getId(g->vertices[i]));
        
        array_id = graph_getConnectionsFromId(g, vertex_getId(g->vertices[i]));

        for(j=0; j<num_connections; j++){
          
          if(vertex_getState(g->vertices[graph_getVertexIndex_fromId(g, array_id[j])]) == WHITE){
            stack_push(s, g->vertices[graph_getVertexIndex_fromId(g, array_id[j])]); 
          }  
        }
      }
    }
  }
  free(s);
  return OK;
}

Status graph_breathSearch (Graph *g, long from_id, long to_id){
  Queue *q;
  long *array_id, from_ix, to_ix;
  int num_connections, i, j;
  Vertex *v;
  
  if(!g || from_id<0 || to_id<0){
    return ERROR;
  }
  
  q = queue_new();
  if(!q){
    return ERROR;
  }

  from_ix = graph_getVertexIndex_fromId(g, from_id);
  to_ix = graph_getVertexIndex_fromId(g, to_id);

  queue_push(q, g->vertices[from_ix]);

  while(queue_isEmpty(q) == FALSE){

    v = queue_pop(q);

    if(vertex_cmp(v, g->vertices[to_ix])==0){
        vertex_setState(g->vertices[to_ix], BLACK);
        vertex_print(stdout, g->vertices[to_ix]);
        fprintf(stdout, "\n");
        free(q);
        return OK;
    }

    for(i=0; i< g->num_vertices; i++){

      if(vertex_cmp(v, g->vertices[i])==0){
        
        if(vertex_getState(g->vertices[i])==WHITE){
          vertex_setState(g->vertices[i], BLACK);
          vertex_print(stdout, g->vertices[i]);
          fprintf(stdout, "\n");
        }

        num_connections = graph_getNumberOfConnectionsFromId(g, vertex_getId(g->vertices[i]));
        
        array_id = graph_getConnectionsFromId(g, vertex_getId(g->vertices[i]));

        for(j=0; j<num_connections; j++){
          
          if(vertex_getState(g->vertices[graph_getVertexIndex_fromId(g, array_id[j])]) == WHITE){
            queue_push(q, g->vertices[graph_getVertexIndex_fromId(g, array_id[j])]); 
          }  
        }
      }
    }
  }
  free(q);
  return OK;
}

