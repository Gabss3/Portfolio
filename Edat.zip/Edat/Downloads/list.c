
#include <stdio.h>
#include <stdlib.h>
#include "list.h"

typedef struct _NodeList {
  void *data;
  struct _NodeList *next;
} NodeList;

struct _List {
  NodeList *last;
};

List *list_new() {
  List *l;

  l = (List *)malloc(sizeof(List));
  if (!l) {
    return NULL;
  }
  l->last = NULL;

  return l;
}

Bool list_isEmpty(const List *pl) {
  if (!pl || pl->last == NULL) {
    return TRUE;
  }
  return FALSE;
}

Status list_pushFront(List *pl, void *e) {
  NodeList *aux;

  if (!pl || !e) {
    return ERROR;
  }

  aux = (NodeList *)malloc(sizeof(NodeList));
  if (!aux) {
    return ERROR;
  }
  aux->data = (void *)e;

  if (list_isEmpty(pl) == TRUE) {
    aux->next = aux;
    pl->last = aux;
  } else {
    aux->next = pl->last->next;
    pl->last->next = aux;
  }
  return OK;
}

Status list_pushBack(List *pl, void *e) {
  NodeList *aux;

  if (!pl || !e) {
    return ERROR;
  }

  aux = (NodeList *)malloc(sizeof(NodeList));
  if (!aux) {
    return ERROR;
  }
  aux->data = (void *)e;

  if (list_isEmpty(pl) == TRUE) {
    aux->next = aux;
    pl->last = aux;
  } else {
    aux->next = pl->last->next;
    pl->last->next = aux;
    pl->last = aux;
  }

  return OK;
}

size_t list_size(const List *pl) {
  NodeList *pn = NULL;
  size_t size = 0;

  if (pl == NULL) {
    return -1;
  }

  if(list_isEmpty(pl)==TRUE){
    return size;
  }

  pn = pl->last->next;
  while (pn != pl->last) {
    pn = pn->next;
    size++;
  }
  size++;
  return size;
}

Status list_pushInOrder(List *pl, void *e, P_ele_cmp f, int order) {
  
  NodeList *aux, *n, *previous;

  if (!pl || !e || !f) {
    return ERROR;
  }
  
  n = (NodeList *)malloc(sizeof(NodeList));
  if (!n) {
    return ERROR;
  }

  n->data = e;

  if(list_isEmpty(pl)==TRUE){
    pl->last= n;
    n->next= n;
    return OK;
  }

  if (order == 1) {
    
    aux = pl->last->next;
    previous = pl->last;
    
    while (aux != pl->last) {

      if (f(e, aux->data) < 0){
        n->next = aux;
        previous->next = n;
        break;
      }
      previous = aux;
      aux = aux->next;
    }

    if(aux == pl->last){
      
      if(f(e, aux->data)<0){
        n->next = aux;
        previous->next = n;
        return OK;
      }
      else{
      n->next = aux->next;
      aux->next = n;
      pl->last = n;
      } 
    }
  }
  
  if (order == -1) {

    aux = pl->last->next;
    previous = pl->last;
    
    while (aux != pl->last) {

      if (f(e, aux->data) > 0){
        n->next = aux;
        previous->next = n;
        break;
      }
      previous = aux;
      aux = aux->next;
    }

    if(aux == pl->last){
      
      if(f(e, aux->data)>0){
        n->next = aux;
        previous->next = n;
        return OK;
      }
       else{
      n->next = aux->next;
      aux->next = n;
      pl->last = n;
    } 
      
    }

  }
  return OK;
}

int list_print(FILE *fp, const List *pl, P_ele_print f) {
  int total = 0, i, size;
  NodeList *n;

  if (!fp || !pl || !f) {
    return -1;
  }

  size = list_size(pl);

  n = pl->last->next;

  for (i = 0; i < size; i++) {

    total += f(fp, n->data);
    printf(" ");
    n = n->next;
  }

  return total;
}

void list_free(List *pl) {
  if (!pl) {
    return;
  }

  while (list_isEmpty(pl) == FALSE) {
    list_popFront(pl);
  }
  free(pl);
}

void *list_popFront(List *pl) {

  NodeList *pn = NULL;
  void *pe = NULL;

  if (pl == NULL || list_isEmpty(pl) == TRUE) {
    return NULL;
  }
  pn = pl->last->next;
  pe = pn->data;

  if (pl->last->next == pl->last) {
    pl->last = NULL;
  } else {
    pl->last->next = pn->next;
  }
  free(pn);
  return pe;
}

void *list_popBack(List *pl) {

  NodeList *pn = NULL;
  void *pe = NULL;

  if (pl == NULL || list_isEmpty(pl) == TRUE) {
    return NULL;
  }

  if (pl->last->next == pl->last) {
    pe = pl->last->data;
    free(pl->last);
    pl->last = NULL;
    return pe;
  }

  pn = pl->last;
  while (pn->next != pl->last) {
    pn = pn->next;
  }
  pe = pl->last->data;
  pn->next = pl->last->next;
  free(pl->last);
  pl->last = pn;
  return pe;
}
