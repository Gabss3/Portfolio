#include "file_utils.h"
#include "list.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[]) {
  
  List *list, *order_list;
  FILE *fp;
  int i = 0, num, argv2, warning_control;
  float *grade;
  void *elem;

  if(argc != 3){
    fprintf(stdout, "Error, se esperaban 3 argumentos.");
    return ERROR;
  }

  argv2 = atoi(argv[2]);

  if(argv2!=1 && argv2!=-1){
    fprintf(stdout, "Error, el tercer argumento debe ser 1 o -1.");
    return ERROR;
  }

  list = list_new();
  if (!list) {
    return ERROR;
  }

  fp = fopen(argv[1], "r");
  if (!fp) {
    list_free(list);
    return ERROR;
  }
  
  if(fscanf(fp, "%d", &num)!=1);{
    flcose(fp);
    free_list(list);
    return ERROR;
  }

  fprintf(stdout, "SIZE: %d\n", num);

  grade = (float *)malloc(num * sizeof(float));

  for (i = 0; i < num; i++) {

    if(fscanf(fp, " %f ", &grade[i])!=1);

    if (i % 2 == 0) {
      list_pushBack(list, &grade[i]);
    }

    if (i % 2 != 0) {
      list_pushFront(list, &grade[i]);
    }
  }

  warning_control = list_print(stdout, list, float_print);

  fprintf(stdout, "\n");
  
  fprintf(stdout, "\nFinished inserting. Now we extract from the beggining and insert in order: \n");

  order_list = list_new();
  if (!order_list) {
    fclose(fp);
    free(grade);
    list_free(list);
    return ERROR;
  }
  
  for (i = 0; i < num / 2; i++) {
    
    elem = (void *)list_popFront(list);

    if(!elem){
      fclose(fp);
      free(grade);
      list_free(list);
      list_free(order_list);
    return ERROR;
    }

    float_print(stdout, elem);
    fprintf(stdout, " ");
    list_pushInOrder(order_list, elem, float_cmp, argv2);
  }
  
  fprintf(stdout, "\nNow we extract from the end and insert in order:\n");

  while (list_isEmpty(list) == FALSE) {
    
    elem = (void *)list_popBack(list);

    if(!elem){
      fclose(fp);
      free(grade);
      list_free(list);
      list_free(order_list);
    return ERROR;
    }

    float_print(stdout, elem);
    fprintf(stdout, " ");
    list_pushInOrder(order_list, elem, float_cmp, argv2);
  }

  num = list_size(order_list);

  fprintf(stdout, "\nSIZE:%d\n", num);

  list_print(stdout, order_list, float_print);

  fclose(fp);
  list_free(list);
  list_free(order_list);
  free(grade);

  return OK;
}
