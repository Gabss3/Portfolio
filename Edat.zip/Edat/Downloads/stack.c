#include "stack.h"
#include "types.h"
#include "file_utils.h"
#include <stdio.h>
#include <stdlib.h>

#define INIT_CAPACITY 2 // init stack capacity
#define FCT_CAPACITY 2  // multiply the stack capacity
struct _Stack {
  void **item;  /*!<Static array of elements*/
  int top;      /*!<index of the top element in the stack*/
  int capacity; /*!<xcapacity of the stack*/
};

Stack *stack_init() {
  Stack *s = NULL;

  s = (Stack *)malloc(sizeof(Stack));
  if (!s) {
    return NULL;
  }

  s->item = (void **)malloc(INIT_CAPACITY * sizeof(void *));
  if (!s->item) {
    free(s);
    return NULL;
  }

  s->capacity = INIT_CAPACITY;
  s->top = 0;
  return s;
}

void stack_free(Stack *s) {
  if (!s) {
    return;
  }

  free(s->item);
  free(s);
  return;
}

Status stack_push(Stack *s, const void *ele) {
  if (s == NULL || ele == NULL ) {
    return ERROR;
  }

  s->capacity = (s->capacity)*FCT_CAPACITY;
 s->item =(void **)realloc(s->item, (s->capacity)*sizeof(void*));
  if (!s->item) {
    return ERROR;
  }
  
  s->top++;
  s->item[s->top] = (void *)ele;

  return OK;
}

void *stack_pop(Stack *s) {
  void *ele = NULL;

  if (!s || stack_isEmpty(s) == TRUE) {
    return NULL;
  }

  ele = s->item[s->top];
  s->item[s->top] = NULL;
  s->top--;

  return ele;
}

void *stack_top(const Stack *s) {

  if (!s || stack_isEmpty(s)==TRUE) {
    return NULL;
  }

  return s->item[s->top];
}

Bool stack_isEmpty(const Stack *s) {

  if (!s) {
    return TRUE;
  }

  if (s->top == -1) {
    return TRUE;
  }

  return FALSE;
}

size_t stack_size(const Stack *s) {

  if (!s) {
    return -1;
  }

  return (size_t)s->top + 1;
}

/*Imprime la pila en un dispositivo y devuelve el número de caracteres
 * impresos*/
int stack_print(FILE *fp, const Stack *s, P_stack_ele_print f) {
  int i = 0, j = 0;

  if (!s || !fp || !f) {
    return -1;
  }

  fprintf(stdout, " SIZE: %d\n", s->top);
  
  for (j = s->top; j>=0; j--) {
    i = f(fp, s->item[j]);
    fprintf(stdout, "\n");

  }

  if (i < 0) {
    return -1;
  }

  return i;
}