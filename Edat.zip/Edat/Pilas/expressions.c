#include "expressions.h"
#include "stack.h"
#include "types.h"
#include <ctype.h> // for isdigit()
#include <stdio.h>
#include <stdlib.h>

#define OPERATORS "+-*/%"

// is char c an operator?
Bool isOperator(char c) {
  char *oper = OPERATORS;
  char *pc;

  // exclude the char '\0' as operator
  if (c == '\0')
    return FALSE;

  // search for c in operators
  pc = strchr(oper, c);

  if (!pc)
    return FALSE;
  return TRUE;
}

// is char c an operand?
// accepts anything that is not an operator
Bool isOperand(char c) {
  Bool b;
  b = (isOperator(c) == TRUE) ? FALSE : TRUE;
  return b;
}

// is char c a digit
Bool isIntOperand(char c) { return isdigit(c) ? TRUE : FALSE; }

// evaluate expresion with operator oper
int evaluate(int arg1, int arg2, char oper) {
  int p = 0;

  switch (oper) {
  case '+':
    p = arg1 + arg2;
    break;
  case '-':
    p = arg1 - arg2;
    break;
  case '*':
    p = arg1 * arg2;
    break;
  case '/':
    p = arg1 / arg2;
    break;
  default:
    printf("Invalid operator");
  }

  return p;
}

Bool balancedParens(char *str)
{
  Stack *s;
  int i;

  if (!str)
  {
    return FALSE;
  }

  s = stack_init();

  if (!s)
  {
    return FALSE;
  }

  for (i = 0; str[i] != '\0'; i++)
  {
    if (str[i] == '(')
    {
      stack_push(s, &str[i]);
    }
    if (str[i] == ')')
    {

      if (stack_isEmpty(s) == FALSE)
      {
        stack_pop(s);
      }
      else if (stack_isEmpty(s) == TRUE)
      {
        stack_free(s);
        return FALSE;
      }
    }
  }

  if (stack_isEmpty(s) == FALSE)
  {
    stack_free(s);
    return FALSE;
  }

  stack_free(s);

  return TRUE;
}

Status evalPostfix(char *expr, int *result)
{
    Status st = OK;
    Stack *s = stack_init();
    int i = 0, j = 0, k =0;
    int res = 0;
    int *arg1 = NULL, *arg2 = NULL, *r= NULL;
    int *aux[strlen(expr)], *p_res[strlen(expr)];


    if (!expr || !s) return ERROR;

    i = 0;
    while (expr[i ] != '\0'&& st == OK){    
        
        if (isIntOperand(expr[i])){
            aux[j] = int_init(expr[i] - '0');
            st =  stack_push(s, aux[j] );
            j++;
        }

 
        if (isOperator(expr[i])){
            arg2 = (int*)stack_pop(s);
            if (!arg2 || stack_isEmpty(s) == TRUE){
                st = ERROR;
            }
            
            if (st == OK){
                arg1 = (int*)stack_pop(s);

                if (!arg1){
                    st = ERROR;
                }

            res = evaluate(*arg1, *arg2, expr[i]);
            p_res[k] =  int_init(res);
           
            st = stack_push(s, p_res[k] );
            k++;
            }
        }   
        i++;
    }


    
    r = (int*) stack_pop(s);
    
    if (!r){
      st = ERROR;
    } 


    if (stack_isEmpty(s) == FALSE && st == OK){
        st = ERROR;
    }

    stack_free(s);


    for (i = 0; i < j; i++)
        int_free(aux[i]);

    for (i = 0; i < k; i++)
        int_free(p_res[i]);
    

    
    if (st == OK){
        *result = res;
    }
    return st;
}