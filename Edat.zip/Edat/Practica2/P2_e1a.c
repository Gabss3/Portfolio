#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "file_utils.h"

/**
 * @brief: Merges two stacks
 *
 * @param sin1, first input stack
 * @param sin2, second input stack
 * @param sout, result stack
 * @return The function returns OK or ERROR
**/

Status mergeStacks (Stack *sin1, Stack *sin2, Stack *sout){

  void *e;
  Stack *ps;

  if(!sin1 || !sin2){
    return ERROR;
  }

  ps = stack_init();

  while(stack_isEmpty(sin1)==FALSE || stack_isEmpty(sin2)==FALSE){

    if(float_cmp(stack_top(sin1), stack_top(sin2))>0){

      e = stack_pop(sin1);
      
    }
    else{
      e = stack_pop(sin2);
    }

    stack_push(sout, e);
  }

  if(stack_isEmpty(sin1)==TRUE){

    ps = sin2; 
  }
    
  else{
        ps = sin1;
  }

  while(stack_isEmpty(ps)==FALSE){

    e = stack_pop(ps);
    stack_push(sout,e);
  }

  free(ps);
  return OK;
}


int main(int argc, char const *argv[]){

  Stack *s1, *s2, *sout;
  FILE *f1, *f2;
  int tam1, tam2, i;
  float *nota1, *nota2;

  if(argc>3|| argc<2){
    fprintf(stdout, "Error, se esperan dos argumentos.");
    return ERROR;
  }

  s1 = stack_init();
  if(!s1){
    return ERROR;
  };

  s2 = stack_init();
  if(!s2){
    stack_free(s1);
    return ERROR;
  };

  sout = stack_init();
  if(!sout){
    stack_free(s1);
    stack_free(s2);
    return ERROR;
  };
  
  
  f1=fopen(argv[1], "r");
  if(!f1){
    return ERROR;
  }
  
  if(fscanf(f1, "%d", &tam1)!=1){
   return ERROR;
  }
  
  nota1 = (float*)malloc(tam1*sizeof(float));
  if(!nota1){
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    return ERROR;
  }
  
 for(i=0; i<tam1; i++){
   if(fscanf(f1, "%f", &nota1[i])!=1){
     return ERROR;
   }

    stack_push(s1, &nota1[i]);

  }
  fclose(f1);

  f2=fopen(argv[2], "r");
  if(!f2){
    return ERROR;
  }
  
  if(fscanf(f2, "%d", &tam2)!=1){
    return ERROR;
  }
  
  nota2 = (float*)malloc(tam2*sizeof(float));
  if(!nota2){
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    free(nota1);
    return ERROR;
  }

  for(i=0; i<tam2; i++){
    if(fscanf(f2, "%f", &nota2[i])!=1){
    
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    free(nota1);
      return ERROR;
    }
    
    if(stack_push(s2, &nota2[i])==ERROR){
    
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    free(nota1);
      return ERROR;
    } 
  }
  fclose(f2);

  stack_print(stdout, s1, float_print);

  stack_print(stdout, s2, float_print);

  if(mergeStacks (s1, s2, sout)==ERROR){
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    free(nota1);
    free(nota2);
    return ERROR;
  };

  stack_print(stdout, sout, float_print);

  free(nota1);
  free(nota2);
  stack_free(s1);
  stack_free(s2);
  stack_free(sout);

  return OK; 
}
