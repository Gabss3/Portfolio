#include <stdio.h>
#include <string.h>
#include "stack.h"
#include "file_utils.h"
#include "vertex.h"
#define MAX 60


/**
 * @brief: Merges two stacks
 *
 * @param sin1, first input stack
 * @param sin2, second input stack
 * @param sout, result stack
 * @return The function returns OK or ERROR
**/
Status mergeStacks (Stack *sin1, Stack *sin2, Stack *sout, int (*P)(const void *c1, const void *c2)){

  void *e;
  Stack *ps;

  if(!sin1 || !sin2){
    return ERROR;
  }

  while(stack_isEmpty(sin1)==FALSE && stack_isEmpty(sin2)==FALSE){

    if(P(stack_top(sin1),stack_top(sin2))>0){

      e = stack_pop(sin1);
      
    }
    else{
      e = stack_pop(sin2);
    }

    stack_push(sout, e);
  }

  if(stack_isEmpty(sin1)==TRUE){

    ps = sin2; 
  }
    
  else{
    ps = sin1;
  }

  while(stack_isEmpty(ps)==FALSE){

    e = stack_pop(ps);
    stack_push(sout,e);
  }

  return OK;
}

int main(int argc, char const *argv[]){

  FILE *p1, *p2;
  Stack *s1, *s2, *sout;
  int num, i;
  char str[MAX], tag[MAX];
  Vertex *v;

  if(argc>3|| argc<2){
    fprintf(stdout, "Error, se esperan dos argumentos.");
    return ERROR;
  }

  s1=stack_init();
    if(!s1){
      return ERROR;
    };
    
  s2=stack_init();
    if(!s2){
      stack_free(s1);
      return ERROR;
    };

  sout=stack_init();
    if(!sout){
      stack_free(s1);
      stack_free(s2);
      return ERROR;
    };

  p1 = fopen(argv[1], "r");

  if(!p1){
  stack_free(s1);
  stack_free(s2);
  stack_free(sout);
  return ERROR;
  }

  if(fscanf(p1, "%d", &num)!=1){
      stack_free(s1);
      stack_free(s2);
      stack_free(sout);
    return ERROR;
  }

  for(i=0;i<num;i++){

    if(fscanf(p1, "%s %s", str, tag)==0){
      stack_free(s1);
      stack_free(s2);
      stack_free(sout);
      return ERROR;
    }
    strcat(str, " ");
    strcat(str, tag);

    v = vertex_initFromString(str);
  
    if (!v){
      stack_free(s1);
      stack_free(s2);
      stack_free(sout);
      return ERROR;
    }
    
    stack_push(s1, v);

    vertex_free(v);
  }

  fclose(p1);

   p2 = fopen(argv[2], "r");

  if(!p2){
  stack_free(s1);
  stack_free(s2);
  stack_free(sout);
  return ERROR;
  }
 
  if(fscanf(p2, "%d", &num)!=1){
    stack_free(s1);
    stack_free(s2);
    stack_free(sout);
    return ERROR;
  }

  for(i=0;i<num;i++){

    if(fscanf(p2, "%s %s", str, tag)==0){
      stack_free(s1);
      stack_free(s2);
      stack_free(sout);
      return ERROR;
    }

    strcat(str, " ");
    strcat(str, tag);

    v = vertex_initFromString(str);
  
    if (!v){
      stack_free(s1);
      stack_free(s2);
      stack_free(sout);
      return ERROR;
    } 
      
    stack_push(s2, v);

    vertex_free(v);
  }

  fclose(p2);

  stack_print(stdout, s1, vertex_print);
  
  stack_print(stdout, s2, vertex_print);

  mergeStacks (s1, s2, sout, vertex_cmp);

  stack_print(stdout, sout, vertex_print);
  
  stack_free(s1);
  stack_free(s2);
  stack_free(sout);
  
  return OK;
}

