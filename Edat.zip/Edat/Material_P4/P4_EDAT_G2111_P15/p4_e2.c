#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bstree.h"
#include "file_utils.h"
#include "search_queue.h"
#include "types.h"

#define MAX_STR 1000

int str_cmp(const void *e1, const void *e2){
  return strcmp(e1, e2);
}

int main(int argc, char const *argv[]) {
  FILE *fe = NULL, *fs = NULL;
  char *ele = NULL;
  long tam = 0;
  char cadena[MAX_STR];
  SearchQueue *q = NULL;

  if (argc != 3) {
    fprintf(stdout, "Usage: ./p4_e2 <input file> <output file>");
    return ERROR;
  }

  q = search_queue_new(string_print, str_cmp);
  if (!q) {
    fprintf(stdout, "Error creating the queue.");
    return ERROR;
  }

  fe = fopen(argv[1], "r");
  if (!fe) {
    search_queue_free(q);
    fprintf(stdout, "Error opening file");
    return ERROR;
  }

  fs = fopen(argv[2], "w");
  if (!fs) {
    search_queue_free(q);
    fclose(fe);
    fprintf(stdout, "Error opening file");
    return ERROR;
  }

  while (fgets(cadena, MAX_STR, fe) != NULL) {
    tam = strlen(cadena);
    ele = (char*)malloc((tam + 1)*sizeof(char));
    if(!ele){
      fclose(fs);
      fclose(fe);
      search_queue_free(q);
      return ERROR;
    }
    strcpy(ele, cadena);
    ele[tam] = 0;
    search_queue_push(q, ele);
  }

  while (search_queue_isEmpty(q) != TRUE) {
    ele = (char *)search_queue_pop(q);
    string_print(fs, ele);
    free(ele);
    ele=NULL;
  }

  fclose(fs);
  fclose(fe);
  search_queue_free(q);

  return OK;
}