#include "vertex.h"
#include <string.h>
#include <stdlib.h>


#define TAG_LENGTH 64
struct _Vertex {
  long id;
  char tag[TAG_LENGTH];
  Label state;

  int index;
};


/*----------------------------------------------------------------------------------------*/
/*
Private function:
*/
Status vertex_setField (Vertex *v, char *key, char *value);

Status vertex_setField (Vertex *v, char *key, char *value) {
  if (!key || !value) return ERROR;

  if (strcmp(key, "id") == 0) {
    return vertex_setId(v, atol(value));
  } else if (strcmp(key, "tag") == 0) {
    return vertex_setTag(v, value);
  } else if (strcmp(key, "state") == 0) {
    return vertex_setState(v, (Label)atoi(value));
  }

  return ERROR;
}

/*----------------------------------------------------------------------------------------*/
Vertex *vertex_initFromString(char *descr){
  char buffer[1024];
  char *token;
  char *key;
  char *value;
  char *p;
  Vertex *v;

  /* Check args: */
  if (!descr) return NULL;

  /* Allocate memory for vertex: */
  v = vertex_init();
  if (!v) return NULL;

  /* Read and tokenize description: */
  sprintf(buffer, "%s", descr);
  token = strtok(buffer, " \t\n");
  while (token) {
    p = strchr(token, ':');
    if (!p) continue;

    *p = '\0';
    key = token;
    value = p+1;

    vertex_setField(v, key, value);

    token = strtok(NULL, " \t\n");
  }

  return v;
}

/**  rest of the functions in vertex.h **/
Vertex * vertex_init (){

  Vertex *v;
  v = (Vertex*)malloc(sizeof(Vertex));
  if(v==NULL){
    return 0;
  }

  v->id=0;
  strcpy(v->tag, "");
  v->state= WHITE;
  v->index=0;

  return v;
  
}

void vertex_free (void * v){
  free(v);
}

long vertex_getId (const Vertex * v){
   if(!v){
    return -1;
  }
  return v->id;
}


const char* vertex_getTag (const Vertex * v){
   if(!v){
    return NULL;
  }
  return v->tag;
}


Label vertex_getState (const Vertex * v){
  if(!v){
    return ERROR_VERTEX;
  }
  return v->state;
}

Status vertex_setId (Vertex * v, const long id){
   v->id = id;
  if(v==NULL || id<0){
    return ERROR;
  }
  else
    return OK;
}

Status vertex_setTag (Vertex * v, const char * tag){
  strcpy(v->tag, tag);

  if(v==NULL || tag==NULL){
    return ERROR;
  }
  else
    return OK;
}

Status vertex_setState (Vertex * v, const Label state){
  v->state= state;
  if(v==NULL || state==2){
    return ERROR;
  }
  else
    return OK;
  
}

int vertex_getIndex(const Vertex *v){
  if(!v){
    return -1;
  }
  return v->index;
}

Status vertex_setIndex(Vertex *v, const int index){
  v->index=index;
  if(!v||index<0){
    return ERROR;
  }

  return OK;
}

int vertex_cmp (const void * v1, const void * v2){

  int i;
  /*It initializes two vertex and assign them to the valirables the function gives.*/
  Vertex *a = (Vertex*)v1;
  Vertex *b = (Vertex*)v2;

  if(v1 == NULL || v2 == NULL){
    return 0;
  }
 
  if(a->id == b->id){
   i = strcmp(a->tag, b->tag);
    return i;
  }
  else if (a->id < b->id)
    return -1;
  else 
    return 1;
  
}

void * vertex_copy (const void * src){
  Vertex *v;
  Vertex *a = (Vertex*)src;
  
  v = (Vertex*)malloc(sizeof(Vertex));
  if(v==NULL){
    return NULL;
  }
  
  v->id = a->id;
  strcpy(v->tag, a->tag);
  v->state = a->state;
  v->index=a->index;
  
  return v;
}

int vertex_print (FILE * pf, const void * v){

  int i;
  Vertex *a = (Vertex*)v;

  if( pf == NULL || v == NULL){
    return -1;
  }

  i = fprintf(pf, "[%ld, %s, %d, %d]", a->id, a->tag, a->state, a->index);
  
  return i;
}