#include <stdio.h>
#include <stdlib.h>

#include "bstree.h"
#include "search_queue.h"

struct _SearchQueue {
  BSTree *data;
};

SearchQueue *search_queue_new(P_ele_print print_ele, P_ele_cmp cmp_ele) {
  SearchQueue *q = NULL;

  if (!print_ele || !cmp_ele) {
    return NULL;
  }

  q = malloc(sizeof(SearchQueue));
  if (!q) {
    return NULL;
  }

  q->data = tree_init(print_ele, cmp_ele);
  if (!q->data) {
    free(q);
    return NULL;
  }

  return q;
}

void search_queue_free(SearchQueue *q) {
  if (!q) {
    return;
  }

  tree_destroy(q->data);
  free(q);
}

Bool search_queue_isEmpty(const SearchQueue *q) {

  if (!q) {
    return TRUE;
  }

  return tree_isEmpty(q->data);
}

Status search_queue_push(SearchQueue *q, void *ele) {
  if (!q || !ele || !tree_insert(q->data, ele)) {
    return ERROR;
  }

  return OK;
}

void *search_queue_pop(SearchQueue *q) {
  void *elem = NULL;
  if (!q) {
    return NULL;
  }
  
  elem = tree_find_min(q->data);
  if (!elem) {
    return NULL;
  }
  
  if(!tree_remove(q->data, elem)){
    return NULL;
  }

  return elem;
}

void *search_queue_getFront(const SearchQueue *q) {
  void *elem = NULL;
  if (!q || !q->data) {
    return NULL;
  }

  elem = tree_find_min(q->data);
  if (!elem) {
    return NULL;
  }

  return elem;
}

void *search_queue_getBack(const SearchQueue *q) {
  void *elem = NULL;

  if (!q || !q->data) {
    return NULL;
  }

  elem = tree_find_max(q->data);
  if (!elem) {
    return NULL;
  }

  return elem;
}

size_t search_queue_size(const SearchQueue *q) {
  size_t size = 0;

  if (!q) {
    return -1;
  }

  size = tree_size(q->data);

  return size;
}

int search_queue_print(FILE *fp, const SearchQueue *q) {
  int tam = 0;

  if (!q || !q->data || !fp) {
    return -1;
  }

  tam = tree_inOrder(fp, q->data);

  return tam;
}
