#include "list_exercises.h"
#include "elements.h"
#include "list.h"
#include "types.h"

void list_delete(List *pl, const void *elem, elem_cmp_fn compare) {
    Node *pn, *aux;

    if(!pl||!elem||!compare||list_isEmpty(pl)==TRUE){
        return;
    }

    pn = pl->first;
    aux = pn->next;

    if(compare(elem, pn->info)==0){
        pl->first= pn->next;
        free(pn);
        return;
    }


    while(pn->next!=NULL){
        
        if(compare(elem, pn->next->info)==0){

            pn->next = aux->next;
            aux->next = NULL;
            free(aux);
            return;
        }
        pn = aux;
        aux = aux->next;    
    }
}

List *list_copy(List *pl) {
    List *lst;
    Node *node_copy, *node_last = NULL, *node_aux;
    
    if(!pl){
        return NULL;
    }

    lst = list_new();

    if(!lst){
        return NULL;
    }

    node_aux = pl->first;

    while(node_aux !=NULL){

        node_copy = node_new();
        
        if(!node_copy){
            list_free(lst);
            return NULL;
        }

        node_copy->info = node_aux->info;
        node_copy->next = NULL;

        if (node_last == NULL){
            lst->first = node_copy;
        }

        else {
            node_last->next = node_copy;
        }

        node_last = node_copy;
        node_aux = node_aux->next;    
    }

    /*node_last->next = NULL;*/

    return lst;
 }
